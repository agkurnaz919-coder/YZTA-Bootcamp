"""Prepare missing model/data artifacts for the unified application."""

from __future__ import annotations

import argparse
import pickle
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from applications.finanomaly.src.config import (
    HYBRID_MODEL_PATH as FINANOMALY_MODEL_FILE,
    MODEL_PATH as FINANOMALY_IFOREST_MODEL_FILE,
    PROCESSED_EXPENSES_PATH as FINANOMALY_PROCESSED_FILE,
    RAW_EXPENSES_PATH as FINANOMALY_DATA_FILE,
    SCORED_EXPENSES_PATH as FINANOMALY_SCORED_FILE,
)
from applications.finanomaly.src.model.service import load_model_bundle
from applications.finanomaly.src.model.train_iforest import run_file_pipeline
from applications.kredibilite_xai.src.config import (
    MODEL_FILE as CREDIT_MODEL_FILE,
    RAW_DATA_FILE as CREDIT_DATA_FILE,
)
from applications.kredibilite_xai.src.data.generate_data import generate
from applications.kredibilite_xai.src.model.optimize_threshold import (
    optimize_threshold,
)
from applications.kredibilite_xai.src.model.train import train

CHURN_DIR = ROOT / "applications" / "churnlens"
CHURN_DATA_FILE = CHURN_DIR / "churn_data.csv"
CHURN_MODEL_FILE = CHURN_DIR / "xgboost_churn.pkl"
CHURN_FEATURES = [
    "Abonelik_Suresi_Ay",
    "Aylik_Giris_Sayisi",
    "Aktif_Kullanici_Sayisi",
    "Destek_Bileti_Sayisi",
    "Aylik_Ucret_Euro",
]
CHURN_TARGET = "Churn_Etti_Mi"


def clean_churn_data(frame: pd.DataFrame) -> pd.DataFrame:
    cleaned = frame.copy()
    for column in CHURN_FEATURES:
        cleaned[column] = pd.to_numeric(cleaned[column], errors="coerce")
        cleaned[column] = cleaned[column].fillna(cleaned[column].median())
    cleaned[CHURN_TARGET] = pd.to_numeric(
        cleaned[CHURN_TARGET], errors="coerce"
    ).fillna(0).astype(int)
    return cleaned


def bootstrap_credit_model(force: bool = False) -> str:
    if not CREDIT_DATA_FILE.exists():
        generate()
    if force or not CREDIT_MODEL_FILE.exists():
        train()
        optimize_threshold()
        return "trained"
    return "present"


def bootstrap_finanomaly_model(force: bool = False) -> str:
    """Create the ignored FinAnomaly artifact and replace invalid copies."""
    if FINANOMALY_MODEL_FILE.exists() and not force:
        try:
            load_model_bundle(FINANOMALY_MODEL_FILE)
        except Exception:  # A stale pickle must not break another machine.
            pass
        else:
            return "present"

    run_file_pipeline(
        input_path=FINANOMALY_DATA_FILE,
        processed_path=FINANOMALY_PROCESSED_FILE,
        scored_path=FINANOMALY_SCORED_FILE,
        model_path=FINANOMALY_MODEL_FILE,
        iforest_model_path=FINANOMALY_IFOREST_MODEL_FILE,
        comparison_path=None,
    )
    return "trained"


def bootstrap_churn_model(force: bool = False) -> str:
    if CHURN_MODEL_FILE.exists() and not force:
        return "present"
    data = clean_churn_data(pd.read_csv(CHURN_DATA_FILE))
    X = data[CHURN_FEATURES]
    y = data[CHURN_TARGET]
    X_train, _, y_train, _ = train_test_split(
        X,
        y,
        test_size=0.2,
        random_state=42,
        stratify=y,
    )
    model = Pipeline(
        [
            ("scaler", StandardScaler()),
            (
                "clf",
                XGBClassifier(
                    n_estimators=300,
                    max_depth=6,
                    learning_rate=0.05,
                    subsample=0.85,
                    colsample_bytree=0.85,
                    eval_metric="logloss",
                    random_state=42,
                    n_jobs=-1,
                ),
            ),
        ]
    )
    model.fit(X_train, y_train)
    with CHURN_MODEL_FILE.open("wb") as handle:
        pickle.dump(model, handle)
    return "trained"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--force",
        action="store_true",
        help="Retrain generated models even when artifacts already exist.",
    )
    args = parser.parse_args()
    finanomaly_status = bootstrap_finanomaly_model(force=args.force)
    credit_status = bootstrap_credit_model(force=args.force)
    churn_status = bootstrap_churn_model(force=args.force)
    print(f"FinAnomaly model: {finanomaly_status}")
    print(f"Kredibilite XAI model: {credit_status}")
    print(f"ChurnLens model: {churn_status}")


if __name__ == "__main__":
    main()
