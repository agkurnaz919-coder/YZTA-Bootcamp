"""Unified Streamlit entry point for the three bootcamp projects."""

import importlib.util
import sys
from pathlib import Path

import streamlit as st


ROOT = Path(__file__).resolve().parent
LOGO_PATH = ROOT / "assets" / "financial_copilot_logo.png"
EMBLEM_PATH = ROOT / "assets" / "financial_copilot_emblem_transparent.png"

st.set_page_config(
    page_title="Financial Copilot",
    page_icon=str(EMBLEM_PATH),
    layout="wide",
    initial_sidebar_state="expanded",
)

st.logo(
    str(LOGO_PATH),
    size="large",
    icon_image=str(EMBLEM_PATH),
)

required_modules = {
    "numpy": "NumPy",
    "pandas": "pandas",
    "sklearn": "scikit-learn",
    "xgboost": "XGBoost",
    "shap": "SHAP",
    "plotly": "Plotly",
    "openpyxl": "openpyxl",
}
missing_modules = [
    package
    for module, package in required_modules.items()
    if importlib.util.find_spec(module) is None
]
if missing_modules:
    st.error(
        "Uygulama yanlış Python ortamıyla başlatıldı. Eksik paketler: "
        + ", ".join(missing_modules)
    )
    st.code(f"cd {ROOT}\n./run.sh", language="bash")
    st.caption(f"Aktif Python: {sys.executable}")
    st.stop()

navigation = st.navigation(
    {
        "Platform": [
            st.Page(
                ROOT / "pages" / "home.py",
                title="Ana Sayfa",
                icon=":material/home:",
                default=True,
            ),
        ],
        "Risk Çözümleri": [
            st.Page(
                ROOT / "applications" / "finanomaly" / "src" / "ui" / "app.py",
                title="FinAnomaly",
                icon=":material/receipt_long:",
                url_path="finanomaly",
            ),
            st.Page(
                ROOT / "applications" / "kredibilite_xai" / "src" / "ui" / "app.py",
                title="Kredibilite XAI",
                icon=":material/account_balance:",
                url_path="kredibilite-xai",
            ),
            st.Page(
                ROOT / "applications" / "churnlens" / "app.py",
                title="ChurnLens",
                icon=":material/group_remove:",
                url_path="churnlens",
            ),
        ],
    }
)

navigation.run()
