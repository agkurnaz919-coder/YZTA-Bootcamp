from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP_PATH = ROOT / "applications" / "finanomaly" / "src" / "ui" / "app.py"
THEME_PATH = ROOT / "applications" / "ui_theme.py"


def test_metric_cards_use_shared_minimal_theme():
    source = APP_PATH.read_text(encoding="utf-8")
    theme = THEME_PATH.read_text(encoding="utf-8")

    assert "from applications.ui_theme import" in source
    assert "apply_theme()" in source
    assert '[data-testid="stMetricLabel"] *' in theme
    assert '[data-testid="stMetricValue"] *' in theme
    assert "background: var(--ri-surface) !important" in theme
    assert "box-shadow: none !important" in theme
    assert "linear-gradient" not in source
