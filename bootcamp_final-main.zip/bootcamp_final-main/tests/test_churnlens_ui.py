import re
from pathlib import Path

from streamlit.testing.v1 import AppTest


ROOT = Path(__file__).resolve().parents[1]
APP_PATH = ROOT / "applications" / "churnlens" / "app.py"
LLM_PATH = ROOT / "applications" / "churnlens" / "llm_explainer.py"
EMOJI_PATTERN = re.compile(
    "[\U0001F000-\U0001FAFF\u2600-\u27BF\u2B00-\u2BFF\uFE0F]"
)


def test_churnlens_interface_contains_no_emoji_or_gauge():
    source = APP_PATH.read_text(encoding="utf-8")
    llm_source = LLM_PATH.read_text(encoding="utf-8")
    assert not EMOJI_PATTERN.search(source + llm_source)
    assert "build_gauge" not in source
    assert 'mode="gauge' not in source


def test_churnlens_explains_the_customer_risk():
    app = AppTest.from_file(str(APP_PATH), default_timeout=60).run()
    assert not app.exception
    rendered = "\n".join(str(element.value) for element in app.markdown)
    expected_sections = [
        "Genel Risk Değerlendirmesi",
        "Bu Sonucun Temel Nedenleri",
        "Müşteri Metrikleri ve Sağlıklı Referans",
        "Destek yükü sağlıklı seviyenin üzerinde",
    ]
    for section in expected_sections:
        assert section in rendered
