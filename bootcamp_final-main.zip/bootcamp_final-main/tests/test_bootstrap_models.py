from pathlib import Path

from scripts import bootstrap_models


def test_bootstrap_trains_finanomaly_when_artifact_is_missing(
    tmp_path: Path,
    monkeypatch,
):
    model_path = tmp_path / "hybrid.pkl"
    calls = []
    monkeypatch.setattr(bootstrap_models, "FINANOMALY_MODEL_FILE", model_path)
    monkeypatch.setattr(
        bootstrap_models,
        "run_file_pipeline",
        lambda **kwargs: calls.append(kwargs),
    )

    assert bootstrap_models.bootstrap_finanomaly_model() == "trained"
    assert len(calls) == 1
    assert calls[0]["model_path"] == model_path
    assert calls[0]["comparison_path"] is None


def test_bootstrap_keeps_a_valid_finanomaly_artifact(tmp_path: Path, monkeypatch):
    model_path = tmp_path / "hybrid.pkl"
    model_path.write_bytes(b"placeholder")
    monkeypatch.setattr(bootstrap_models, "FINANOMALY_MODEL_FILE", model_path)
    monkeypatch.setattr(bootstrap_models, "load_model_bundle", lambda path: {})

    def unexpected_training(**kwargs):
        raise AssertionError("valid artifact should not be retrained")

    monkeypatch.setattr(bootstrap_models, "run_file_pipeline", unexpected_training)

    assert bootstrap_models.bootstrap_finanomaly_model() == "present"


def test_bootstrap_replaces_an_incompatible_finanomaly_artifact(
    tmp_path: Path,
    monkeypatch,
):
    model_path = tmp_path / "hybrid.pkl"
    model_path.write_bytes(b"not a pickle")
    calls = []
    monkeypatch.setattr(bootstrap_models, "FINANOMALY_MODEL_FILE", model_path)

    def incompatible_bundle(path):
        raise ModuleNotFoundError("legacy module")

    monkeypatch.setattr(bootstrap_models, "load_model_bundle", incompatible_bundle)
    monkeypatch.setattr(
        bootstrap_models,
        "run_file_pipeline",
        lambda **kwargs: calls.append(kwargs),
    )

    assert bootstrap_models.bootstrap_finanomaly_model() == "trained"
    assert len(calls) == 1


def test_credit_page_bootstraps_artifacts_missing_from_clean_checkout(
    tmp_path: Path,
    monkeypatch,
):
    from applications.kredibilite_xai.src.ui import app as credit_app

    model_path = tmp_path / "models" / "xgboost_credit.pkl"
    data_path = tmp_path / "data" / "german_credit.csv"
    calls = []
    monkeypatch.setattr(credit_app, "MODEL_FILE", model_path)
    monkeypatch.setattr(credit_app, "RAW_DATA_FILE", data_path)
    monkeypatch.setattr(
        bootstrap_models,
        "bootstrap_credit_model",
        lambda: calls.append("bootstrapped"),
    )

    credit_app.ensure_credit_artifacts()
    assert calls == ["bootstrapped"]

    model_path.parent.mkdir(parents=True)
    data_path.parent.mkdir(parents=True)
    model_path.touch()
    data_path.touch()

    credit_app.ensure_credit_artifacts()
    assert calls == ["bootstrapped"]
