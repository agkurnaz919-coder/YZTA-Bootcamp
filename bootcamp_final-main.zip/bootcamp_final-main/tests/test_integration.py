from pathlib import Path

from streamlit.testing.v1 import AppTest


ROOT = Path(__file__).resolve().parents[1]


def test_all_three_feature_apps_are_present():
    expected = [
        ROOT / "applications" / "finanomaly" / "src" / "ui" / "app.py",
        ROOT / "applications" / "kredibilite_xai" / "src" / "ui" / "app.py",
        ROOT / "applications" / "churnlens" / "app.py",
    ]
    assert all(path.is_file() for path in expected)
    assert (ROOT / "run.sh").is_file()


def test_feature_artifacts_are_isolated():
    from applications.finanomaly.src.config import BASE_DIR as anomaly_dir
    from applications.kredibilite_xai.src.config import ROOT_DIR as credit_dir

    assert anomaly_dir == ROOT / "applications" / "finanomaly"
    assert credit_dir == ROOT / "applications" / "kredibilite_xai"
    assert anomaly_dir != credit_dir


def test_navigation_references_every_feature():
    source = (ROOT / "app.py").read_text(encoding="utf-8")
    assert "applications\" / \"finanomaly" in source
    assert "applications\" / \"kredibilite_xai" in source
    assert "applications\" / \"churnlens" in source


def test_financial_copilot_brand_is_applied_consistently():
    app_source = (ROOT / "app.py").read_text(encoding="utf-8")
    home_source = (ROOT / "pages" / "home.py").read_text(encoding="utf-8")
    theme_source = (ROOT / "applications" / "ui_theme.py").read_text(
        encoding="utf-8"
    )

    assert 'page_title="Financial Copilot"' in app_source
    assert "st.logo(" in app_source
    assert "financial_copilot_logo.png" in app_source
    assert "financial_copilot_emblem_transparent.png" in app_source
    assert "Financial Copilot" in home_source
    assert '[data-testid="stSidebarLogo"]' in theme_source
    assert "width: 12.75rem !important" in theme_source
    assert (ROOT / "assets" / "financial_copilot_logo.png").is_file()
    assert (ROOT / "assets" / "financial_copilot_emblem_transparent.png").is_file()


def test_feature_pages_share_the_same_minimal_theme():
    pages = [
        ROOT / "applications" / "finanomaly" / "src" / "ui" / "app.py",
        ROOT / "applications" / "kredibilite_xai" / "src" / "ui" / "app.py",
        ROOT / "applications" / "churnlens" / "app.py",
    ]
    for page in pages:
        source = page.read_text(encoding="utf-8")
        assert "from applications.ui_theme import" in source
        assert "apply_theme()" in source

    config = (ROOT / ".streamlit" / "config.toml").read_text(encoding="utf-8")
    assert 'base = "light"' in config
    assert 'primaryColor = "#176B5B"' in config
    assert 'backgroundColor = "#D4DED9"' in config
    assert 'secondaryBackgroundColor = "#C7D4CD"' in config


def test_unified_entrypoint_renders():
    app = AppTest.from_file(str(ROOT / "app.py"), default_timeout=30).run()
    assert not app.exception
    feature_pages = [
        "applications/finanomaly/src/ui/app.py",
        "applications/kredibilite_xai/src/ui/app.py",
        "applications/churnlens/app.py",
    ]
    for page in feature_pages:
        app.switch_page(page).run()
        assert not app.exception


def test_home_page_has_actionable_responsive_content():
    app = AppTest.from_file(str(ROOT / "app.py"), default_timeout=30).run()
    assert not app.exception

    hero_html = next(
        item.value
        for item in app.markdown
        if '<section class="ri-home-hero"' in item.value
    )
    assert hero_html.count('class="ri-console-row"') == 3
    assert 'href="#solutions-title"' in hero_html
    assert 'href="#workflow-title"' in hero_html

    landing_html = next(
        item.value
        for item in app.markdown
        if '<div class="ri-solution-grid">' in item.value
    )
    assert landing_html.count('class="ri-solution-card"') == 3
    assert landing_html.count('<article class="ri-platform-stage') == 4
    assert landing_html.count('class="ri-workflow-step"') == 3
    assert landing_html.count('class="ri-role-card"') == 3
    assert landing_html.count('class="ri-trust-item"') == 3
    for route in ("./finanomaly", "./kredibilite-xai", "./churnlens"):
        assert f'href="{route}"' in landing_html
    assert 'target="_blank"' not in landing_html
    assert 'rel="noopener noreferrer"' not in landing_html

    theme_source = (ROOT / "applications" / "ui_theme.py").read_text(
        encoding="utf-8"
    )
    assert ".ri-solution-grid" in theme_source
    assert "align-items: stretch" in theme_source
    assert "@media (prefers-reduced-motion: reduce)" in theme_source
    assert app.info[0].value.startswith("Yukarıdaki kartlardan")
