"""Threshold optimizasyonu — train.py sonrası çalıştır."""

import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
sys.path.append(str(Path(__file__).resolve().parent.parent.parent.parent.parent))

import joblib
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.metrics import (
    confusion_matrix,
    f1_score,
    precision_recall_curve,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import StratifiedKFold, train_test_split

from applications.kredibilite_xai.src.config import (
    DATA_PROCESSED,
    MODELS_DIR,
    RANDOM_STATE,
    TARGET_COL,
    TEST_SIZE,
)


def optimize_threshold() -> dict:
    df = pd.read_csv(DATA_PROCESSED / "credit_processed.csv")
    feature_cols = [column for column in df.columns if column != TARGET_COL]
    X, y = df[feature_cols], df[TARGET_COL]
    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=TEST_SIZE,
        random_state=RANDOM_STATE,
        stratify=y,
    )

    model_path = MODELS_DIR / "xgboost_credit.pkl"
    bundle = joblib.load(model_path)
    probabilities = bundle["model"].predict_proba(X_test)[:, 1]
    precision, recall, thresholds = precision_recall_curve(y_test, probabilities)
    f1_scores = (
        2
        * precision[:-1]
        * recall[:-1]
        / (precision[:-1] + recall[:-1] + 1e-9)
    )
    best_threshold = float(thresholds[np.argmax(f1_scores)])
    best_f1 = float(f1_scores.max())
    default_f1 = f1_score(y_test, (probabilities >= 0.5).astype(int))
    fpr, tpr, _ = roc_curve(y_test, probabilities)
    auc = roc_auc_score(y_test, probabilities)
    confusion = confusion_matrix(
        y_test, (probabilities >= best_threshold).astype(int)
    )

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    cv_f1_scores = []
    for train_indices, validation_indices in cv.split(X_train, y_train):
        fold_model = clone(bundle["model"])
        fold_model.fit(
            X_train.iloc[train_indices],
            y_train.iloc[train_indices],
        )
        fold_probabilities = fold_model.predict_proba(
            X_train.iloc[validation_indices]
        )[:, 1]
        cv_f1_scores.append(
            f1_score(
                y_train.iloc[validation_indices],
                (fold_probabilities >= best_threshold).astype(int),
            )
        )
    cv_f1_mean = float(np.mean(cv_f1_scores))

    bundle.update(
        {
            "optimal_threshold": best_threshold,
            "metrics": {
                **bundle["metrics"],
                "f1": best_f1,
                "f1_old": default_f1,
                "cv_f1": cv_f1_mean,
            },
            "roc": {"fpr": fpr.tolist(), "tpr": tpr.tolist(), "auc": float(auc)},
            "cm": confusion.tolist(),
            "feature_importance": dict(
                zip(
                    feature_cols,
                    map(float, bundle["model"].feature_importances_),
                )
            ),
        }
    )
    joblib.dump(bundle, model_path)
    print(
        f"✅ Threshold optimize edildi: {best_threshold:.3f} | "
        f"F1: {default_f1:.3f} → {best_f1:.3f} | "
        f"CV F1: {cv_f1_mean:.3f} | AUC: {auc:.3f}"
    )
    return bundle


if __name__ == "__main__":
    optimize_threshold()
