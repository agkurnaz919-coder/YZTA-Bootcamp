"""
src/model/train.py
──────────────────
XGBoost kredi risk modeli eğitimi.
→ Cross-validation + test seti değerlendirmesi
→ models/xgboost_credit.pkl olarak kaydeder
"""

import pandas as pd
import joblib
from pathlib import Path
import sys

from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.metrics import (
    roc_auc_score, f1_score, classification_report,
    confusion_matrix, accuracy_score
)
from xgboost import XGBClassifier

sys.path.append(str(Path(__file__).resolve().parent.parent.parent.parent.parent))
from applications.kredibilite_xai.src.config import (
    DATA_PROCESSED, MODELS_DIR, TARGET_COL,
    XGB_PARAMS, RANDOM_STATE, TEST_SIZE
)
from applications.kredibilite_xai.src.data.preprocess import preprocess, NUMERIC_COLS, CATEGORICAL_COLS


def load_processed() -> tuple[pd.DataFrame, list]:
    path = DATA_PROCESSED / "credit_processed.csv"
    if not path.exists():
        print("⚙️  İşlenmiş veri bulunamadı, preprocess çalıştırılıyor...")
        _, df_enc, feature_cols = preprocess(save=True)
        return df_enc, feature_cols

    df = pd.read_csv(path)
    feature_cols = [c for c in df.columns if c != TARGET_COL]
    print(f"📂 İşlenmiş veri yüklendi: {df.shape}")
    return df, feature_cols


def train():
    # ── Veri yükle ────────────────────────────────────────────────────────
    df, feature_cols = load_processed()

    X = df[feature_cols]
    y = df[TARGET_COL]

    # ── Train / Test bölme ────────────────────────────────────────────────
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE,
        random_state=RANDOM_STATE, stratify=y
    )
    print(f"\n📐 Train: {X_train.shape} | Test: {X_test.shape}")
    print(f"   Train hedef: {y_train.value_counts().to_dict()}")
    print(f"   Test hedef:  {y_test.value_counts().to_dict()}")

    # ── Model ─────────────────────────────────────────────────────────────
    params = {k: v for k, v in XGB_PARAMS.items() if k != "use_label_encoder"}
    model = XGBClassifier(**params, verbosity=0)

    # ── Cross-validation ──────────────────────────────────────────────────
    print("\n🔄 5-Fold Cross-Validation...")
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    cv_auc = cross_val_score(model, X_train, y_train, cv=cv,
                             scoring="roc_auc", n_jobs=1)
    cv_f1  = cross_val_score(model, X_train, y_train, cv=cv,
                             scoring="f1", n_jobs=1)

    print(f"   CV ROC-AUC : {cv_auc.mean():.4f} ± {cv_auc.std():.4f}")
    print(f"   CV F1      : {cv_f1.mean():.4f}  ± {cv_f1.std():.4f}")

    # ── Nihai eğitim ──────────────────────────────────────────────────────
    model.fit(X_train, y_train,
              eval_set=[(X_test, y_test)],
              verbose=False)

    # ── Test değerlendirme ────────────────────────────────────────────────
    y_pred      = model.predict(X_test)
    y_pred_prob = model.predict_proba(X_test)[:, 1]

    auc = roc_auc_score(y_test, y_pred_prob)
    f1  = f1_score(y_test, y_pred)
    acc = accuracy_score(y_test, y_pred)

    print("\n📈 Test Seti Sonuçları:")
    print(f"   ROC-AUC  : {auc:.4f}")
    print(f"   F1 Score : {f1:.4f}")
    print(f"   Accuracy : {acc:.4f}")
    print(f"\n{classification_report(y_test, y_pred, target_names=['Düşük Risk','Yüksek Risk'])}")

    cm = confusion_matrix(y_test, y_pred)
    print(f"Confusion Matrix:\n{cm}")

    # ── Özellik önemi (Top 10) ────────────────────────────────────────────
    importance = pd.Series(
        model.feature_importances_, index=feature_cols
    ).sort_values(ascending=False)

    print("\n🔑 En Önemli 10 Özellik:")
    for feat, imp in importance.head(10).items():
        bar = "█" * int(imp * 100)
        print(f"   {feat:<45} {imp:.4f} {bar}")

    # ── Kaydet ────────────────────────────────────────────────────────────
    MODELS_DIR.mkdir(exist_ok=True)
    model_path = MODELS_DIR / "xgboost_credit.pkl"

    # Model ile birlikte meta bilgisi de sakla
    bundle = {
        "model"        : model,
        "feature_cols" : feature_cols,
        "numeric_cols" : NUMERIC_COLS,
        "categorical_cols": CATEGORICAL_COLS,
        "metrics"      : {"auc": auc, "f1": f1, "accuracy": acc},
        "cv_auc_mean"  : cv_auc.mean(),
    }
    joblib.dump(bundle, model_path)
    print(f"\n💾 Model kaydedildi → {model_path}")

    return model, feature_cols, bundle


if __name__ == "__main__":
    train()
