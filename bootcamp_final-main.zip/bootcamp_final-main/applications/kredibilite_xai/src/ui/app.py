"""Kredibilite XAI Streamlit interface."""
import sys, warnings, tempfile, os, html, hashlib, re
from pathlib import Path
warnings.filterwarnings("ignore")
sys.path.append(str(Path(__file__).resolve().parent.parent.parent.parent.parent))

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go

from applications.ui_theme import (
    ACCENT as SHARED_ACCENT,
    ACCENT_TINT as SHARED_ACCENT_TINT,
    BORDER as SHARED_BORDER,
    BORDER_STRONG as SHARED_BORDER_STRONG,
    CANVAS,
    DANGER,
    DANGER_TINT,
    SIDEBAR,
    SUCCESS,
    SUCCESS_TINT,
    SURFACE as SHARED_SURFACE,
    SURFACE_MUTED,
    TEXT as SHARED_TEXT,
    TEXT_MUTED as SHARED_TEXT_MUTED,
    WARNING,
    WARNING_TINT,
    apply_theme,
    page_header,
    style_plotly,
)
from applications.kredibilite_xai.src.config import (
    MODEL_FILE,
    RAW_DATA_FILE,
    TARGET_COL,
)
from applications.kredibilite_xai.src.data.preprocess import preprocess, encode
from applications.kredibilite_xai.src.xai.shap_explainer import load_explainer, explain_instance, plot_waterfall, top_factors, _pretty
from applications.kredibilite_xai.src.xai.dice_explainer import (
    build_dice,
    generate_cfs,
    format_action_cards,
    fallback_action_cards,
)
from applications.kredibilite_xai.src.xai.llm_explainer import explain_in_turkish, check_ollama_status

AHMET_BEY = {
    "kredi_suresi":36,"kredi_tutari":12000,"taksit_orani":4,"ikamet_suresi":2,
    "yas":38,"mevcut_kredi":2,"bakmakla_yukulmu":1,"vadesiz_hesap":"<0€",
    "kredi_gecmisi":"gecikmeli_ödeme","kredi_amaci":"iş","birikim_hesabi":"<100€",
    "istihdam":"1-4 yıl","medeni_durum":"erkek_bekar","diger_taraflar":"yok",
    "mulk_varligi":"mülk_yok","diger_odeme":"mağaza","konut":"kiracı",
    "is_niteligi":"nitelikli","telefon":"hayır","yabanci_isci":"hayır",
}

# Shared palette aliases keep the existing component helpers compact.
BG = CANVAS
BG_2 = SIDEBAR
SURFACE = SHARED_SURFACE
SURFACE_2 = SURFACE_MUTED
BORDER = SHARED_BORDER
BORDER_STR = SHARED_BORDER_STRONG
TEXT = SHARED_TEXT
TEXT_MUTED = SHARED_TEXT_MUTED
ACCENT = SHARED_ACCENT
ACCENT_2 = SHARED_ACCENT
ACCENT_TINT = SHARED_ACCENT_TINT
BRICK = DANGER
BRICK_TINT = DANGER_TINT
GOLD = WARNING
GOLD_TINT = WARNING_TINT
SAGE = SUCCESS
SAGE_TINT = SUCCESS_TINT
GRAD = ACCENT

# Plotly'nin figure_factory / colorscale ayrıştırıcısı rgba() alfa kanalını
# int() ile parse etmeye çalışıp hata veriyor (bkz. ValueError: '.14') —
# bu yüzden grafik renk skalalarında SADECE opak hex tonlar kullanılıyor.
ACCENT_TINT_HEX = "#DCEDE8"
GOLD_TINT_HEX = "#F8E5C7"

# Geriye dönük uyum: eski değişken adları yeni paletle eşleniyor
INK, INK_2, PAPER, LINE, TEAL, TEAL_TINT = (
    BG_2,
    SURFACE_2,
    BG,
    BORDER,
    ACCENT,
    ACCENT_TINT,
)

apply_theme()
st.markdown(f"""
<style>
.panel{{background:{SURFACE};border:1px solid {BORDER};border-radius:10px}}
.eyebrow{{font-size:.68rem;font-weight:700;letter-spacing:.08em;
text-transform:uppercase;color:{TEXT_MUTED}}}
.display{{font-family:inherit}}
</style>
""", unsafe_allow_html=True)


def ensure_credit_artifacts() -> None:
    """Prepare ignored demo data/model files in a fresh deployment."""
    if MODEL_FILE.is_file() and RAW_DATA_FILE.is_file():
        return

    # Import lazily so normal launches with existing artifacts stay fast and
    # the cloud-only bootstrap dependencies are loaded only when required.
    from scripts.bootstrap_models import bootstrap_credit_model

    bootstrap_credit_model()


@st.cache_resource(show_spinner=False)
def get_model():
    ensure_credit_artifacts()
    return load_explainer()

@st.cache_resource(show_spinner=False)
def get_data():
    ensure_credit_artifacts()
    return preprocess(save=False)

def build_dice_fresh(bundle, df_raw):
    exp, _ = build_dice(df_raw, bundle)
    return exp

def to_enc(inputs, feature_cols):
    df_raw = pd.DataFrame([{**inputs, TARGET_COL: 0}])
    df_enc = encode(df_raw.copy())
    for col in feature_cols:
        if col not in df_enc.columns: df_enc[col] = 0
    return df_raw, df_enc[feature_cols].astype(float)

def dossier_id(inputs: dict) -> str:
    """Profile özgü, deterministik bir 'dosya numarası' üretir (kozmetik)."""
    digest = hashlib.sha1(repr(sorted(inputs.items())).encode()).hexdigest()
    return f"KRD-{int(digest[:4], 16) % 9000 + 1000}"

def section(title):
    st.markdown(f"""<div class="eyebrow" style="margin:18px 0 10px">{title}</div>""",
                unsafe_allow_html=True)

def esc(value) -> str:
    return html.escape(str(value), quote=True)


def sidebar():
    st.sidebar.markdown(f"""
    <div style="display:flex;align-items:center;gap:10px;padding:6px 0 18px;
                border-bottom:1px solid {BORDER};margin-bottom:6px">
      <div style="width:34px;height:34px;border-radius:9px;background:{GRAD};
                  display:flex;align-items:center;justify-content:center;
                  flex-shrink:0">
        <span style="font-weight:700;color:#FFFFFF;font-size:1.05rem">K</span>
      </div>
      <div>
        <div class="display" style="font-size:1.15rem;font-weight:600;color:{TEXT};
                    letter-spacing:-.01em;line-height:1.15">Kredibilite XAI</div>
        <div class="eyebrow" style="color:{TEXT_MUTED};margin-top:3px">
          KOBİ Kredi Risk Motoru
        </div>
      </div>
    </div>""", unsafe_allow_html=True)

    st.sidebar.markdown("### Kredi Talebi")
    kredi_tutari  = st.sidebar.slider("Kredi Tutarı (€)", 500, 18000, 6800, 100)
    kredi_suresi  = st.sidebar.select_slider("Vade (ay)", [6,12,18,24,36,48,60], 24)
    taksit_orani  = st.sidebar.select_slider("Taksit Yükümlülüğü (%)", [1,2,3,4], 4)
    kredi_amaci   = st.sidebar.selectbox("Kredi Amacı",
        ["iş","araba","mobilya","elektronik","beyazeşya","tamirat","eğitim","yeniden_finansman","tatil","diğer"])

    st.sidebar.markdown("### Hesap Durumu")
    vadesiz_hesap  = st.sidebar.selectbox("Vadesiz Hesap",  ["<0€","0-200€",">200€","hesap_yok"])
    birikim_hesabi = st.sidebar.selectbox("Birikim Hesabı", ["<100€","100-500€","500-1000€",">1000€","bilgi_yok"])

    st.sidebar.markdown("### Kredi Geçmişi")
    kredi_gecmisi = st.sidebar.selectbox("Geçmiş Durum",
        ["mevcut_sorunsuz","tüm_borçlar_ödenmiş","sorunsuz_ödeme","gecikmeli_ödeme","kritik_hesap"])

    st.sidebar.markdown("### Kişisel Bilgiler")
    yas         = st.sidebar.slider("Yaş", 18, 75, 35)
    istihdam    = st.sidebar.selectbox("İstihdam", ["işsiz","<1 yıl","1-4 yıl","4-7 yıl","≥7 yıl"], 2)
    is_niteligi = st.sidebar.selectbox("İş Niteliği",
        ["vasıfsız_kayıtsız","vasıfsız_kayıtlı","nitelikli","yönetici_uzman"], 2)
    konut       = st.sidebar.selectbox("Konut", ["kiracı","ücretsiz","ev sahibi"], 2)
    medeni_durum= st.sidebar.selectbox("Medeni Durum",
        ["erkek_bekar","erkek_evli","kadın_bekar_boşanmış","erkek_boşanmış"])

    st.sidebar.markdown("### Varlık & Risk")
    mulk_varligi     = st.sidebar.selectbox("Mülk", ["gayrimenkul","hayat_sigortası","araba","mülk_yok"])
    diger_taraflar   = st.sidebar.selectbox("Kefil / Ortak", ["yok","kefil","ortak_borçlu"])
    diger_odeme      = st.sidebar.selectbox("Diğer Ödeme", ["yok","banka","mağaza"])
    ikamet_suresi    = st.sidebar.select_slider("İkamet (yıl)", [1,2,3,4], 2)
    mevcut_kredi     = st.sidebar.select_slider("Mevcut Kredi", [1,2,3,4], 1)
    bakmakla_yukulmu = st.sidebar.select_slider("Bakmakla Yükümlü", [1,2], 1)
    telefon          = st.sidebar.selectbox("Telefon", ["evet","hayır"])
    yabanci_isci     = st.sidebar.selectbox("Yabancı İşçi", ["hayır","evet"])

    st.sidebar.markdown("---")
    st.sidebar.button("Analizi Çalıştır", width='stretch', type="primary", key="run_btn")
    st.sidebar.button("Demo — Tekstilci Ahmet Bey", width='stretch', key="demo_btn")

    if st.session_state.get("demo_btn"):
        st.sidebar.markdown(f"""
        <div style="margin-top:8px;padding:10px 14px;background:{SURFACE_2};
                    border-radius:8px;border:1px solid {BORDER}">
          <div class="eyebrow" style="color:{ACCENT_2};margin-bottom:3px">Demo Profili Aktif</div>
          <div style="font-size:.73rem;color:{TEXT_MUTED};line-height:1.5">
            Tekstilci Ahmet Bey<br>12.000€ · 36 ay · Yüksek Risk
          </div>
        </div>""", unsafe_allow_html=True)

    return dict(kredi_suresi=kredi_suresi, kredi_tutari=kredi_tutari,
                taksit_orani=taksit_orani, ikamet_suresi=ikamet_suresi,
                yas=yas, mevcut_kredi=mevcut_kredi, bakmakla_yukulmu=bakmakla_yukulmu,
                vadesiz_hesap=vadesiz_hesap, kredi_gecmisi=kredi_gecmisi,
                kredi_amaci=kredi_amaci, birikim_hesabi=birikim_hesabi,
                istihdam=istihdam, medeni_durum=medeni_durum,
                diger_taraflar=diger_taraflar, mulk_varligi=mulk_varligi,
                diger_odeme=diger_odeme, konut=konut, is_niteligi=is_niteligi,
                telefon=telefon, yabanci_isci=yabanci_isci)


def risk_seal(prob, inputs):
    """Render a compact, accessible risk summary."""
    pct = int(prob * 100)
    if prob >= 0.65:
        color, tint, lbl, verdict = BRICK, BRICK_TINT, "YÜKSEK RİSK", "Başvuru mevcut profille yüksek riskte"
    elif prob >= 0.40:
        color, tint, lbl, verdict = GOLD, GOLD_TINT, "ORTA RİSK", "Ek belge veya güvence istenebilir"
    else:
        color, tint, lbl, verdict = SAGE, SAGE_TINT, "DÜŞÜK RİSK", "Başvuru olumlu değerlendirilebilir"

    did = dossier_id(inputs)
    st.markdown(f"""
<div style="padding:20px;background:{SURFACE};border:1px solid {BORDER};border-radius:10px">
<div class="eyebrow" style="margin-bottom:14px">Vaka no · {did}</div>
<div style="display:flex;align-items:end;justify-content:space-between;gap:12px">
<div style="font-weight:650;font-size:2.45rem;color:{TEXT};line-height:1">%{pct}</div>
<div class="eyebrow" style="color:{color};padding-bottom:4px">{lbl}</div>
</div>
<div style="height:7px;margin:18px 0 12px;background:{SURFACE_2};border-radius:4px;overflow:hidden">
<div style="height:100%;width:{pct}%;background:{color};border-radius:4px"></div>
</div>
<div style="padding:9px 11px;background:{tint};border-radius:7px;
font-size:.8rem;color:{color};line-height:1.45">{verdict}</div>
</div>""", unsafe_allow_html=True)



def shap_row(label, val, max_abs):
    pos   = val > 0
    c     = BRICK if pos else SAGE
    bg    = BRICK_TINT if pos else SAGE_TINT
    w     = int(min(abs(val)/max_abs, 1)*130)
    arrow = "▲" if pos else "▼"
    sign  = f"+{val:.3f}" if pos else f"{val:.3f}"
    dir_  = "Riski Artırıyor" if pos else "Riski Azaltıyor"

    st.markdown(f"""
<div style="display:flex;align-items:center;gap:11px;padding:8px 13px;
margin-bottom:5px;background:{SURFACE};border-radius:8px;
border:1px solid {LINE}">
<div style="width:28px;height:28px;border-radius:6px;background:{bg};
display:flex;align-items:center;justify-content:center;
font-size:.8rem;color:{c};flex-shrink:0">{arrow}</div>
<div style="flex:1;font-size:.82rem;color:{TEXT};font-weight:500">{label}</div>
<div style="width:130px;height:6px;background:#EEF0E8;
border-radius:3px;overflow:hidden;flex-shrink:0">
<div style="width:{w}px;height:6px;background:{c};border-radius:3px"></div>
</div>
<div style="width:64px;text-align:right;font-family:'JetBrains Mono',monospace;
font-size:.76rem;font-weight:600;color:{c};flex-shrink:0">{sign}</div>
<div style="width:105px;font-size:.7rem;color:{TEXT_MUTED};
text-align:right;flex-shrink:0">{dir_}</div>
</div>""", unsafe_allow_html=True)


def dice_card(card, current_prob=None):
    status = str(card.get("sonuç", card.get("sonuc", "")))
    actions = card.get("actions", [])
    approved = "Düşük Risk" in status or "Dusuk Risk" in status
    color = SAGE if approved else GOLD
    tint  = SAGE_TINT if approved else GOLD_TINT
    no    = card.get('cf_no', '')

    # Durum metninden hedef risk yüzdesini çıkar (örn. "...Tahmini risk %28")
    m = re.search(r"%(\d+)", status)
    target_pct = int(m.group(1)) if m else None
    cur_pct = int(current_prob * 100) if current_prob is not None else None
    delta_html = ""
    if target_pct is not None and cur_pct is not None:
        delta = max(cur_pct - target_pct, 0)
        delta_html = (
            f'<div style="display:flex;align-items:baseline;gap:8px;margin-top:10px">'
            f'<span style="font-family:\'JetBrains Mono\',monospace;font-size:1.5rem;font-weight:700;color:{color}">%{target_pct}</span>'
            f'<span style="font-size:.72rem;color:{TEXT_MUTED};text-decoration:line-through">%{cur_pct}</span>'
            f'<span style="font-size:.72rem;font-weight:700;color:{color}">-{delta} puan</span>'
            f'</div>'
        )

    # NOT: Streamlit'in markdown ayrıştırıcısı 4+ boşluk girintili satırları
    # "kod bloğu" sayıp HTML'i olduğu gibi metin olarak basar — bu yüzden
    # tüm HTML tek satırda, girintisiz üretiliyor.
    card_html = (
        f'<div style="background:{SURFACE};border:1px solid {color}40;border-top:3px solid {color};'
        f'border-radius:10px;padding:20px 20px 16px">'
        f'<div style="display:flex;align-items:center;gap:10px">'
        f'<div style="width:30px;height:30px;border-radius:8px;background:{tint};'
        f'display:flex;align-items:center;justify-content:center;flex-shrink:0">'
        f'<span style="font-family:\'JetBrains Mono\',monospace;font-weight:700;color:{color};font-size:.85rem">{no}</span>'
        f'</div>'
        f'<div style="flex:1">'
        f'<div style="font-weight:700;font-size:.92rem;color:{TEXT}">Senaryo {no}</div>'
        f'<div class="eyebrow" style="color:{color};margin-top:1px">{esc(status)}</div>'
        f'</div></div>{delta_html}</div>'
    )
    st.markdown(card_html, unsafe_allow_html=True)

    if not actions:
        st.caption("Bu senaryoda değişiklik gerekmemektedir.")
        return

    st.markdown("<div style='height:10px'></div>", unsafe_allow_html=True)
    for i, action in enumerate(actions, 1):
        alan = str(action.get("alan", ""))
        mevcut = str(action.get("mevcut", ""))
        hedef = str(action.get("hedef", ""))
        aciklama = str(action.get("açıklama", action.get("aciklama", "")))

        step_html = (
            f'<div style="background:{SURFACE_2};border:1px solid {BORDER};border-radius:10px;'
            f'padding:13px 15px;margin-bottom:9px">'
            f'<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">'
            f'<span style="width:19px;height:19px;border-radius:5px;background:{tint};color:{color};'
            f'font-size:.68rem;font-weight:700;display:flex;align-items:center;justify-content:center;'
            f'flex-shrink:0">{i}</span>'
            f'<span style="font-weight:700;font-size:.83rem;color:{TEXT}">{esc(alan)}</span>'
            f'</div>'
            f'<div style="display:flex;align-items:center;gap:10px;margin-bottom:9px;flex-wrap:wrap">'
            f'<span style="font-family:\'JetBrains Mono\',monospace;font-size:.78rem;color:{TEXT_MUTED};'
            f'background:{BG};border:1px solid {BORDER};border-radius:6px;padding:3px 9px">{esc(mevcut)}</span>'
            f'<span style="color:{color};font-weight:700">→</span>'
            f'<span style="font-family:\'JetBrains Mono\',monospace;font-size:.78rem;color:{color};'
            f'font-weight:600;background:{tint};border-radius:6px;padding:3px 9px">{esc(hedef)}</span>'
            f'</div>'
            f'<div style="font-size:.79rem;color:{TEXT_MUTED};line-height:1.55">{esc(aciklama)}</div>'
            f'</div>'
        )
        st.markdown(step_html, unsafe_allow_html=True)



def welcome(metrics):
    st.markdown(
        page_header(
            "Kredi risk değerlendirmesi",
            "Kredibilite XAI",
            (
                "KOBİ kredi başvuruları için şeffaf skor, gerekçeli karar ve "
                "uygulanabilir aksiyon senaryoları."
            ),
            meta="XGBoost · SHAP · Karşı-olgusal analiz",
        ),
        unsafe_allow_html=True,
    )

    c1,c2,c3,c4 = st.columns(4)
    c1.metric("Eğitim Örnekleri", "1.000 KOBİ")
    c2.metric("ROC-AUC", f"{metrics['auc']:.3f}")
    c3.metric("F1 (Optimize)", f"{metrics.get('f1',0):.3f}")
    c4.metric("Accuracy", f"%{metrics['accuracy']*100:.1f}")

    st.markdown("<br>", unsafe_allow_html=True)
    cols = st.columns(3)
    items = [
        ("01","Başvuru Profili","Finansal bilgileri sol panelden tek formda yönetin.", TEAL),
        ("02","Karar Gerekçesi","Skoru etkileyen başlıca faktörleri SHAP ile görün.", GOLD),
        ("03","Aksiyon Reçetesi","Onaya yaklaşan alternatif senaryoları inceleyin.", SAGE),
    ]
    for col,(ic,title,desc,accent) in zip(cols,items):
        col.markdown(f"""
        <div style="background:{SURFACE};border-radius:8px;padding:20px;
                    border:1px solid {LINE}">
          <div class="eyebrow" style="color:{accent};margin-bottom:10px">{ic}</div>
          <div style="font-size:.88rem;font-weight:700;color:{TEXT};margin-bottom:5px">{title}</div>
          <div style="font-size:.78rem;color:{TEXT_MUTED};line-height:1.6">{desc}</div>
        </div>""", unsafe_allow_html=True)
    st.markdown("<br>", unsafe_allow_html=True)
    st.info("Sol panelden profili doldurup **Analizi Çalıştır** butonunu kullanabilirsiniz. Demo akışı için Tekstilci Ahmet Bey profili hazır.")


def main():
    inputs = sidebar()
    if st.session_state.get("demo_btn"):
        inputs = AHMET_BEY

    with st.spinner("Yükleniyor…"):
        try:
            bundle, shap_exp = get_model()
            df_raw_full, _, _ = get_data()
        except FileNotFoundError as e:
            st.error(str(e)); st.code("python src/model/train.py"); st.stop()

    model        = bundle["model"]
    feature_cols = bundle["feature_cols"]
    metrics      = bundle["metrics"]
    opt_thr      = bundle.get("optimal_threshold", 0.5)

    if not (st.session_state.get("run_btn") or st.session_state.get("demo_btn")):
        welcome(metrics); return

    df_raw, df_enc = to_enc(inputs, feature_cols)
    prob     = float(model.predict_proba(df_enc)[:, 1][0])

    is_demo = st.session_state.get("demo_btn", False)
    badge   = f'<span style="background:{GOLD_TINT};color:{GOLD};padding:3px 12px;border-radius:999px;font-size:.72rem;font-weight:700;margin-left:8px">Demo — Tekstilci Ahmet Bey</span>' if is_demo else ""

    st.markdown(f"""
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
<div>
<h2 class="display" style="margin:0;font-size:1.5rem;font-weight:600;color:{TEXT};letter-spacing:-.01em">
Kredi Risk Analizi</h2>
<p style="margin:3px 0 0;color:{TEXT_MUTED};font-size:.8rem">
XGBoost + SHAP · Karar Eşiği {opt_thr:.3f}</p>
</div>{badge}
</div>
<span style="background:{TEAL_TINT};color:{TEAL};padding:3px 12px;
border-radius:999px;font-size:.72rem;font-weight:700">XAI Destekli</span>
</div>""", unsafe_allow_html=True)

    col_r, col_p = st.columns([1, 1.8], gap="large")
    with col_r:
        risk_seal(prob, inputs)
    with col_p:
        section("Başvuru Özeti")
        r1,r2,r3,r4 = st.columns(4)
        r1.metric("Tutar",  f"{inputs['kredi_tutari']:,}€")
        r2.metric("Vade",   f"{inputs['kredi_suresi']} ay")
        r3.metric("Yaş",    inputs['yas'])
        r4.metric("Taksit", f"%{inputs['taksit_orani']}")
        st.markdown("<br>", unsafe_allow_html=True)
        details = [
            ("Vadesiz Hesap",inputs['vadesiz_hesap']),
            ("Kredi Geçmişi",inputs['kredi_gecmisi']),
            ("Birikim",inputs['birikim_hesabi']),
            ("İstihdam",inputs['istihdam']),
            ("Mülk",inputs['mulk_varligi']),
            ("Amaç",inputs['kredi_amaci']),
        ]
        dc = st.columns(3)
        for i,(k,v) in enumerate(details):
            with dc[i%3]:
                st.markdown(f"""
<div style="padding:8px 12px;background:{SURFACE};border-radius:8px;
border:1px solid {LINE};margin-bottom:7px">
<div style="font-size:.62rem;color:{TEXT_MUTED};font-weight:700;
text-transform:uppercase;letter-spacing:.07em">{k}</div>
<div style="font-size:.83rem;font-weight:700;color:{TEXT};margin-top:2px">{esc(v)}</div>
</div>""", unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    tab_shap, tab_dice, tab_llm, tab_csv, tab_model = st.tabs([
        "Skorun Nedenleri",
        "Aksiyon Reçetesi",
        "AI Açıklama",
        "Toplu Analiz",
        "Model Bilgisi",
    ])

    # ── SHAP ────────────────────────────────────────────────────────────
    with tab_shap:
        st.markdown("<br>", unsafe_allow_html=True)
        with st.spinner("SHAP hesaplanıyor…"):
            shap_res = explain_instance(df_enc, shap_exp, feature_cols)
            factors  = top_factors(shap_res, feature_cols, n=8)

        cl, cr = st.columns([1, 1.2], gap="large")
        with cl:
            section("En Etkili Faktörler")
            mx = max(abs(f["shap"]) for f in factors) or 1
            for f in factors:
                shap_row(f["label"], f["shap"], mx)
        with cr:
            section("Waterfall Grafiği")
            with st.spinner("Grafik üretiliyor…"):
                with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
                    plot_waterfall(shap_res, df_enc, feature_cols,
                                   save_path=tmp.name, risk_prob=prob)
                    st.image(tmp.name, width='stretch')
                os.unlink(tmp.name)

        st.markdown("<br>", unsafe_allow_html=True)
        if prob >= opt_thr:
            st.error("Bu profil yüksek risk taşıyor. **Aksiyon Reçetesi** sekmesine geçerek öneri senaryolarına bakın.")
        else:
            st.success("Bu profil düşük risk kategorisinde. Başvuru olumlu değerlendirilebilir.")

    # ── AKSİYON REÇETESİ ─────────────────────────────────────────────────
    with tab_dice:
        st.markdown("<br>", unsafe_allow_html=True)
        if prob < 0.35:
            st.success("✅ Bu profil zaten düşük riskli — aksiyon reçetesi gerekmemektedir.")
        else:
            st.info(
                f"Mevcut risk %{int(prob * 100)}. Aşağıdaki 3 senaryo, farklı yollarla düşük riske "
                "geçişi gösterir — her biri bağımsız bir alternatiftir, hepsini birden uygulamanız "
                "gerekmez. Yaş, medeni durum ve benzeri değiştirilemez alanlar dışlanmıştır."
            )

            instance = pd.DataFrame([{**inputs, TARGET_COL: 1}])
            with st.spinner("Aksiyon reçeteleri hesaplanıyor…"):
                try:
                    dice_exp  = build_dice_fresh(bundle, df_raw_full)
                    cf_result = generate_cfs(dice_exp, instance, desired_class=0)
                    cards     = format_action_cards(cf_result, instance)
                except Exception:
                    cards = []

            if not cards:
                cards = fallback_action_cards(instance)

            section(f"{len(cards)} Alternatif Senaryo")
            cols = st.columns(len(cards)) if cards else []
            for col, card in zip(cols, cards):
                with col:
                    dice_card(card, current_prob=prob)

            st.caption("Öneriler istatistiksel modele dayanır. Kesin karar yetkili kurum tarafından verilir.")

    # ── LLM ─────────────────────────────────────────────────────────────
    with tab_llm:
        st.markdown("<br>", unsafe_allow_html=True)
        status = check_ollama_status()
        ok_ollama = status["available"] and status["model_ready"]
        dot_c = SAGE if ok_ollama else GOLD
        dot_t = "Ollama Aktif — llama3.2" if ok_ollama else status["message"]
        dot_bg = SAGE_TINT if ok_ollama else GOLD_TINT

        st.markdown(f"""
<div style="display:inline-flex;align-items:center;gap:7px;padding:5px 13px;
background:{dot_bg};border-radius:999px;margin-bottom:16px">
<div style="width:7px;height:7px;border-radius:50%;background:{dot_c}"></div>
<span style="font-size:.71rem;font-weight:700;color:{dot_c}">{dot_t}</span>
</div>""", unsafe_allow_html=True)

        with st.spinner("AI açıklama üretiliyor…"):
            try:
                shap_r2  = explain_instance(df_enc, shap_exp, feature_cols)
                factors2 = top_factors(shap_r2, feature_cols, n=5)
                dice_e2  = build_dice_fresh(bundle, df_raw_full)
                instance2 = pd.DataFrame([{**inputs, TARGET_COL: 1}])
                cf2      = generate_cfs(dice_e2, instance2, desired_class=0)
                cards2   = format_action_cards(cf2, instance2)
            except Exception:
                factors2=[]; cards2=[]
            text, is_llm = explain_in_turkish(prob, factors2, cards2)

        src_bg = SAGE_TINT if is_llm else GOLD_TINT
        src_fg = SAGE if is_llm else GOLD
        src_lb = "🤖 Ollama · llama3.2" if is_llm else "📝 Statik Açıklama"

        st.markdown(f"""
<div style="background:{SURFACE};border-radius:8px;border:1px solid {LINE};
padding:24px 28px;margin-bottom:16px">
<div style="display:flex;justify-content:space-between;
align-items:center;margin-bottom:14px">
<div class="eyebrow">AI Kredi Değerlendirmesi</div>
<span style="background:{src_bg};color:{src_fg};padding:3px 11px;
border-radius:999px;font-size:.7rem;font-weight:700">{src_lb}</span>
</div>
<div style="font-size:.98rem;line-height:1.8;color:{TEXT};
border-left:3px solid {TEAL};padding-left:14px">{esc(text)}</div>
</div>""", unsafe_allow_html=True)

        if not ok_ollama:
            with st.expander("📦 Ollama Nasıl Kurulur?"):
                st.markdown("""
**1.** `https://ollama.com/download` → Windows installer
```bash
ollama pull llama3.2
ollama serve
pip install ollama
```
Uygulamayı yeniden başlatın → AI sekmesi aktif olacak.
                """)

    # ── CSV ─────────────────────────────────────────────────────────────
    with tab_csv:
        st.markdown("<br>", unsafe_allow_html=True)
        section("Toplu KOBİ Analizi — CSV Yükleme")
        required = list(AHMET_BEY.keys())
        sample_df = pd.DataFrame([
            AHMET_BEY,
            {**AHMET_BEY,"kredi_tutari":4000,"kredi_suresi":12,
             "vadesiz_hesap":">200€","kredi_gecmisi":"mevcut_sorunsuz",
             "birikim_hesabi":">1000€","istihdam":"≥7 yıl",
             "mulk_varligi":"gayrimenkul","konut":"ev sahibi"},
        ])
        st.download_button("⬇️  Örnek CSV'yi İndir",
            data=sample_df.to_csv(index=False).encode("utf-8"),
            file_name="ornek_kobi_profilleri.csv", mime="text/csv")
        st.markdown("<br>", unsafe_allow_html=True)
        uploaded = st.file_uploader("CSV dosyasını yükleyin", type=["csv"])
        if uploaded:
            try:
                df_up   = pd.read_csv(uploaded)
                missing = [c for c in required if c not in df_up.columns]
                if missing:
                    st.error(f"⚠️ Eksik kolonlar: {', '.join(missing)}")
                else:
                    st.success(f"✅ {len(df_up)} satır yüklendi")
                    results=[]; prog=st.progress(0)
                    for i, row in df_up.iterrows():
                        inp = {k: row[k] for k in required}
                        try:
                            dr = encode(pd.DataFrame([{**inp, TARGET_COL:0}]))
                            for col in feature_cols:
                                if col not in dr.columns: dr[col]=0
                            p = float(model.predict_proba(dr[feature_cols].astype(float))[:,1][0])
                            lv = "🔴 Yüksek" if p>=0.65 else "🟠 Orta" if p>=0.40 else "🟢 Düşük"
                            results.append({"Satır":i+1,"Kredi Tutarı":f"{int(inp['kredi_tutari']):,}€",
                                "Kredi Geçmişi":inp["kredi_gecmisi"],
                                "Risk %":f"%{int(p*100)}","Risk Seviyesi":lv,
                                "Karar":"❌ Reddedilir" if p>=opt_thr else "✅ Onaylanır"})
                        except Exception as e:
                            results.append({"Satır":i+1,"Kredi Tutarı":"—",
                                "Kredi Geçmişi":"—","Risk %":"Hata",
                                "Risk Seviyesi":f"⚠️ {str(e)[:30]}","Karar":"—"})
                        prog.progress((i+1)/len(df_up))
                    res_df = pd.DataFrame(results)
                    st.dataframe(res_df, width='stretch', hide_index=True)
                    st.download_button("⬇️  Sonuçları İndir",
                        data=res_df.to_csv(index=False).encode("utf-8"),
                        file_name="analiz_sonuclari.csv", mime="text/csv")
                    tot=len(results); red=sum(1 for r in results if "Reddedilir" in r["Karar"]); ok=tot-red
                    st.markdown("<br>", unsafe_allow_html=True)
                    c1,c2,c3=st.columns(3)
                    c1.metric("Toplam",tot)
                    c2.metric("Onaylanabilir",ok,delta=f"%{int(ok/tot*100)}")
                    c3.metric("Reddedilir",red,delta=f"-%{int(red/tot*100)}",delta_color="inverse")
            except Exception as e:
                st.error(f"CSV okuma hatası: {e}")

    # ── MODEL BİLGİSİ ────────────────────────────────────────────────────
    with tab_model:
        st.markdown("<br>", unsafe_allow_html=True)
        f1n=metrics.get("f1",0); f1o=metrics.get("f1_old",0)
        auc_v=metrics.get("auc",0); acc_v=metrics.get("accuracy",0)
        cv_f1_v=metrics.get("cv_f1")

        section("Model Performans Metrikleri")
        m1,m2,m3,m4,m5 = st.columns(5)
        m1.metric("ROC-AUC",          f"{auc_v:.3f}")
        m2.metric("F1 (Optimize)",    f"{f1n:.3f}", delta=f"+{f1n-f1o:.3f}")
        m3.metric("Accuracy",         f"%{acc_v*100:.1f}")
        m4.metric("Optimal Threshold",f"{opt_thr:.3f}")
        m5.metric("Eğitim Verisi",    "1.000 örnek")
        if cv_f1_v is not None:
            st.caption(f"5-fold çapraz doğrulama F1 (optimal eşikte): {cv_f1_v:.3f}")

        st.markdown("<br>", unsafe_allow_html=True)
        col_roc, col_cm = st.columns(2, gap="large")

        with col_roc:
            section("ROC Eğrisi")
            roc = bundle.get("roc", {})
            if roc:
                fig = go.Figure()
                fig.add_trace(go.Scatter(x=roc["fpr"], y=roc["tpr"], mode="lines",
                    name=f"AUC={roc['auc']:.3f}", line=dict(color=TEAL, width=2.5)))
                fig.add_trace(go.Scatter(x=[0,1], y=[0,1], mode="lines", showlegend=False,
                    line=dict(color=LINE, dash="dash", width=1.5)))
                fig.update_layout(plot_bgcolor=SURFACE, paper_bgcolor=SURFACE, height=270,
                    font=dict(family="Inter", size=11, color=TEXT),
                    margin=dict(l=40,r=20,t=10,b=40), legend=dict(x=0.6,y=0.1),
                    xaxis=dict(title="FPR", gridcolor=BORDER),
                    yaxis=dict(title="TPR", gridcolor=BORDER))
                style_plotly(fig, height=270)
                st.plotly_chart(fig, width='stretch')

        with col_cm:
            section("Confusion Matrix")
            cm_d = bundle.get("cm", [[0,0],[0,0]])
            if cm_d:
                import plotly.figure_factory as ff
                arr = np.array(cm_d)
                ann = [[f"{['TN','FP'][j]}<br>{arr[i,j]}" for j in range(2)] for i in range(2)]
                fcm = ff.create_annotated_heatmap(z=arr,
                    x=["Tahmin: Düşük Risk","Tahmin: Yüksek Risk"],
                    y=["Gerçek: Düşük Risk","Gerçek: Yüksek Risk"],
                    annotation_text=ann,
                    colorscale=[[0,ACCENT_TINT_HEX],[1,TEAL]], showscale=False)
                fcm.update_layout(plot_bgcolor=SURFACE, paper_bgcolor=SURFACE, height=270,
                    font=dict(family="Inter", size=11, color=TEXT),
                    margin=dict(l=10,r=10,t=10,b=10))
                style_plotly(fcm, height=270)
                st.plotly_chart(fcm, width='stretch')

        st.markdown("<br>", unsafe_allow_html=True)
        section("Özellik Önem Skoru (Top 15)")
        fi = bundle.get("feature_importance", {})
        if fi:
            top15  = sorted(fi.items(), key=lambda x:x[1], reverse=True)[:15]
            lbls   = [_pretty(k) for k,_ in top15]
            vals   = [v for _,v in top15]
            ffi = go.Figure(go.Bar(
                x=vals[::-1], y=lbls[::-1], orientation="h",
                marker=dict(
                    color=vals[::-1],
                    colorscale=[[0,GOLD_TINT_HEX],[0.5,GOLD],[1,TEAL]],
                    showscale=False),
                text=[f"{v:.4f}" for v in vals[::-1]],
                textposition="outside",
                textfont=dict(size=11, color=TEXT, family="JetBrains Mono"),
            ))
            ffi.update_layout(
                plot_bgcolor=SURFACE, paper_bgcolor=SURFACE, height=420,
                font=dict(family="Inter", size=11, color=TEXT),
                margin=dict(l=10, r=80, t=10, b=10),
                xaxis=dict(title="Önem Skoru", gridcolor=BORDER,
                           tickfont=dict(color=TEXT)),
                yaxis=dict(tickfont=dict(size=10, color=TEXT)),
            )
            style_plotly(ffi, height=420)
            st.plotly_chart(ffi, width='stretch')

        st.markdown(f"""
<div style="padding:14px 18px;background:{TEAL_TINT};border-radius:8px;
border:1px solid {LINE};margin-top:4px">
<div style="font-size:.8rem;font-weight:700;color:{TEXT};margin-bottom:4px">
Threshold Optimizasyonu</div>
<div style="font-size:.76rem;color:{TEXT_MUTED};line-height:1.7">
Varsayılan 0.5 yerine <strong>F1-max threshold {opt_thr:.3f}</strong> kullanılmaktadır.
F1 skoru <strong>{f1o:.3f} → {f1n:.3f}</strong> seviyesine taşınmıştır.
</div>
</div>""", unsafe_allow_html=True)


if __name__ == "__main__":
    main()
