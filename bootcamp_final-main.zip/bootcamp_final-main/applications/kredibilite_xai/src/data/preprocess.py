"""
src/data/preprocess.py
──────────────────────
Ham veriyi (data/raw/german_credit.csv) alır,
encode eder ve data/processed/credit_processed.csv olarak kaydeder.

Ayrıca CATEGORICAL_COLS ve NUMERIC_COLS listelerini dışa aktarır
→ model ve XAI modülleri bu listeleri import eder.
"""

import pandas as pd
from pathlib import Path
import sys

sys.path.append(str(Path(__file__).resolve().parent.parent.parent.parent.parent))
from applications.kredibilite_xai.src.config import DATA_RAW, DATA_PROCESSED, TARGET_COL

# ── Kolon grupları ────────────────────────────────────────────────────────
CATEGORICAL_COLS = [
    "vadesiz_hesap", "kredi_gecmisi", "kredi_amaci", "birikim_hesabi",
    "istihdam", "medeni_durum", "diger_taraflar", "mulk_varligi",
    "diger_odeme", "konut", "is_niteligi", "telefon", "yabanci_isci",
]

NUMERIC_COLS = [
    "kredi_suresi", "kredi_tutari", "taksit_orani",
    "ikamet_suresi", "yas", "mevcut_kredi", "bakmakla_yukulmu",
]

ALL_FEATURES = NUMERIC_COLS + CATEGORICAL_COLS


def load_raw() -> pd.DataFrame:
    path = DATA_RAW / "german_credit.csv"
    if not path.exists():
        raise FileNotFoundError(
            f"Ham veri bulunamadı: {path}\n"
            "Önce `python src/data/generate_data.py` çalıştırın."
        )
    df = pd.read_csv(path)
    print(f"📂 Ham veri yüklendi: {df.shape}")
    return df


def check_missing(df: pd.DataFrame) -> pd.DataFrame:
    missing = df.isnull().sum()
    if missing.any():
        print(f"⚠️  Eksik değer bulundu:\n{missing[missing > 0]}")
        # Sayısal → medyan, kategorik → mod
        for col in NUMERIC_COLS:
            if df[col].isnull().any():
                df[col] = df[col].fillna(df[col].median())
        for col in CATEGORICAL_COLS:
            if df[col].isnull().any():
                df[col] = df[col].fillna(df[col].mode()[0])
    else:
        print("✅ Eksik değer yok.")
    return df


def sanitize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """XGBoost'un kabul etmediği [, ], < karakterlerini kolon isimlerinden temizler."""
    df.columns = (
        df.columns
        .str.replace("[", "_", regex=False)
        .str.replace("]", "_", regex=False)
        .str.replace("<", "lt", regex=False)
        .str.replace(">", "gt", regex=False)
        .str.replace(" ", "_", regex=False)
    )
    return df


def encode(df: pd.DataFrame) -> pd.DataFrame:
    """Kategorik kolonları one-hot encode eder."""
    df_enc = pd.get_dummies(df, columns=CATEGORICAL_COLS, drop_first=False)
    df_enc = sanitize_columns(df_enc)
    return df_enc


def get_encoded_feature_cols(df_enc: pd.DataFrame) -> list:
    """Encode edilmiş tüm özellik kolonlarını döner (hedef hariç)."""
    return [c for c in df_enc.columns if c != TARGET_COL]


def preprocess(save: bool = True) -> tuple[pd.DataFrame, pd.DataFrame, list]:
    """
    Returns
    -------
    df_raw      : ham DataFrame (orijinal kategorik değerlerle)
    df_enc      : one-hot encode edilmiş DataFrame
    feature_cols: encode edilmiş özellik kolon listesi
    """
    df_raw = load_raw()
    df_raw = check_missing(df_raw)

    # Temel istatistik özeti
    print("\n📊 Hedef dağılımı:")
    print(df_raw[TARGET_COL].value_counts().rename({0: "Düşük Risk", 1: "Yüksek Risk"}).to_string())
    print("\n   Sayısal özellik özeti:")
    print(df_raw[NUMERIC_COLS].describe().loc[["mean","std","min","max"]].round(1).to_string())

    df_enc = encode(df_raw)
    feature_cols = get_encoded_feature_cols(df_enc)

    print(f"\n✅ Encode sonrası boyut: {df_enc.shape}")
    print(f"   Özellik sayısı: {len(feature_cols)}")

    if save:
        out = DATA_PROCESSED / "credit_processed.csv"
        df_enc.to_csv(out, index=False)
        print(f"💾 Kaydedildi → {out}")

    return df_raw, df_enc, feature_cols


if __name__ == "__main__":
    preprocess()
