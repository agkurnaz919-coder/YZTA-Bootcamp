"""
src/data/generate_data.py
─────────────────────────
UCI German Credit dataseti yapısına birebir uyan,
Türkçe KOBİ profiline göre özelleştirilmiş sentetik veri üreteci.

1000 örnek üretir → data/raw/german_credit.csv
"""

import numpy as np
import pandas as pd
from pathlib import Path
import sys

sys.path.append(str(Path(__file__).resolve().parent.parent.parent.parent.parent))
from applications.kredibilite_xai.src.config import DATA_RAW, RANDOM_STATE

np.random.seed(RANDOM_STATE)
N = 1000


def generate():
    # ── Temel özellikler ───────────────────────────────────────────────────
    yas             = np.random.randint(22, 68, N)
    kredi_suresi    = np.random.choice([6,12,18,24,36,48,60], N,
                                       p=[0.05,0.15,0.15,0.25,0.20,0.12,0.08])
    kredi_tutari    = np.random.randint(500, 18000, N)
    taksit_orani    = np.random.choice([1,2,3,4], N, p=[0.1,0.2,0.4,0.3])

    istihdam        = np.random.choice(
        ["işsiz", "<1 yıl", "1-4 yıl", "4-7 yıl", "≥7 yıl"], N,
        p=[0.05, 0.15, 0.30, 0.30, 0.20]
    )
    konut           = np.random.choice(["kiracı","ücretsiz","ev sahibi"], N,
                                       p=[0.18,0.11,0.71])
    is_niteligi     = np.random.choice(
        ["vasıfsız_kayıtsız","vasıfsız_kayıtlı","nitelikli","yönetici_uzman"], N,
        p=[0.04, 0.20, 0.55, 0.21]
    )
    kredi_amaci     = np.random.choice(
        ["araba","mobilya","elektronik","beyazeşya","tamirat",
         "eğitim","yeniden_finansman","iş","tatil","diğer"], N,
        p=[0.23,0.18,0.10,0.09,0.08,0.05,0.10,0.09,0.03,0.05]
    )
    kredi_gecmisi   = np.random.choice(
        ["sorunsuz_ödeme","tüm_borçlar_ödenmiş","mevcut_sorunsuz",
         "gecikmeli_ödeme","kritik_hesap"], N,
        p=[0.04, 0.05, 0.53, 0.22, 0.16]
    )
    vadesiz_hesap   = np.random.choice(
        ["<0€","0-200€",">200€","hesap_yok"], N,
        p=[0.27, 0.27, 0.10, 0.36]
    )
    birikim_hesabi  = np.random.choice(
        ["<100€","100-500€","500-1000€",">1000€","bilgi_yok"], N,
        p=[0.60, 0.10, 0.06, 0.06, 0.18]
    )
    diger_taraflar  = np.random.choice(["yok","kefil","ortak_borçlu"], N,
                                       p=[0.91, 0.05, 0.04])
    mulk_varligi    = np.random.choice(
        ["gayrimenkul","hayat_sigortası","araba","mülk_yok"], N,
        p=[0.28, 0.23, 0.23, 0.26]
    )
    diger_odeme     = np.random.choice(["banka","mağaza","yok"], N,
                                       p=[0.14, 0.10, 0.76])
    telefon         = np.random.choice(["evet","hayır"], N, p=[0.60, 0.40])
    yabanci_isci    = np.random.choice(["evet","hayır"], N, p=[0.04, 0.96])
    medeni_durum    = np.random.choice(
        ["erkek_bekar","erkek_evli","kadın_bekar_boşanmış","erkek_boşanmış"], N,
        p=[0.31, 0.44, 0.16, 0.09]
    )
    ikamet_suresi   = np.random.choice([1,2,3,4], N, p=[0.12, 0.31, 0.28, 0.29])
    mevcut_kredi    = np.random.choice([1,2,3,4], N, p=[0.47, 0.33, 0.16, 0.04])
    bakmakla_yukulmu= np.random.choice([1,2], N, p=[0.85, 0.15])

    # ── Risk skoru hesaplama (kural tabanlı, gerçekçi) ─────────────────────
    risk_puan = np.zeros(N)

    # Vadesiz hesap
    risk_puan += np.where(vadesiz_hesap == "<0€",        0.25, 0)
    risk_puan += np.where(vadesiz_hesap == "0-200€",     0.10, 0)
    risk_puan += np.where(vadesiz_hesap == "hesap_yok",  0.05, 0)
    risk_puan += np.where(vadesiz_hesap == ">200€",     -0.15, 0)

    # Kredi geçmişi
    risk_puan += np.where(kredi_gecmisi == "kritik_hesap",    0.35, 0)
    risk_puan += np.where(kredi_gecmisi == "gecikmeli_ödeme", 0.20, 0)
    risk_puan += np.where(kredi_gecmisi == "sorunsuz_ödeme", -0.10, 0)

    # Birikim
    risk_puan += np.where(birikim_hesabi == "<100€",   0.20, 0)
    risk_puan += np.where(birikim_hesabi == ">1000€", -0.15, 0)

    # İstihdam
    risk_puan += np.where(istihdam == "işsiz",   0.20, 0)
    risk_puan += np.where(istihdam == "<1 yıl",  0.10, 0)
    risk_puan += np.where(istihdam == "≥7 yıl", -0.10, 0)

    # Kredi tutarı / süre
    risk_puan += (kredi_tutari / 18000) * 0.20
    risk_puan += (kredi_suresi / 60)   * 0.15

    # Taksit oranı
    risk_puan += np.where(taksit_orani >= 3, 0.10, 0)

    # Yaş
    risk_puan += np.where(yas < 25,  0.10, 0)
    risk_puan += np.where(yas > 50, -0.05, 0)

    # Mülk
    risk_puan += np.where(mulk_varligi == "mülk_yok", 0.10, 0)
    risk_puan += np.where(mulk_varligi == "gayrimenkul", -0.10, 0)

    # Gürültü ekle
    risk_puan += np.random.normal(0, 0.08, N)

    # 0-1 arasına normalize et
    risk_puan = (risk_puan - risk_puan.min()) / (risk_puan.max() - risk_puan.min())

    # Hedef: 1 = yüksek risk (kötü), 0 = düşük risk (iyi)
    # Gerçek oranlara yakın: %30 yüksek risk
    esik = np.percentile(risk_puan, 70)
    kredi_riski = (risk_puan >= esik).astype(int)

    # ── DataFrame ──────────────────────────────────────────────────────────
    df = pd.DataFrame({
        "vadesiz_hesap"    : vadesiz_hesap,
        "kredi_suresi"     : kredi_suresi,
        "kredi_gecmisi"    : kredi_gecmisi,
        "kredi_amaci"      : kredi_amaci,
        "kredi_tutari"     : kredi_tutari,
        "birikim_hesabi"   : birikim_hesabi,
        "istihdam"         : istihdam,
        "taksit_orani"     : taksit_orani,
        "medeni_durum"     : medeni_durum,
        "diger_taraflar"   : diger_taraflar,
        "ikamet_suresi"    : ikamet_suresi,
        "mulk_varligi"     : mulk_varligi,
        "yas"              : yas,
        "diger_odeme"      : diger_odeme,
        "konut"            : konut,
        "mevcut_kredi"     : mevcut_kredi,
        "is_niteligi"      : is_niteligi,
        "bakmakla_yukulmu" : bakmakla_yukulmu,
        "telefon"          : telefon,
        "yabanci_isci"     : yabanci_isci,
        "kredi_riski"      : kredi_riski,   # hedef
    })

    out_path = DATA_RAW / "german_credit.csv"
    df.to_csv(out_path, index=False)

    print(f"✅ Veri üretildi → {out_path}")
    print(f"   Satır: {len(df)} | Kolon: {len(df.columns)}")
    print(f"   Hedef dağılımı:\n{df['kredi_riski'].value_counts().to_string()}")
    print(f"   Düşük Risk (0): {(df['kredi_riski']==0).mean():.1%} | "
          f"Yüksek Risk (1): {(df['kredi_riski']==1).mean():.1%}")
    return df


if __name__ == "__main__":
    generate()
