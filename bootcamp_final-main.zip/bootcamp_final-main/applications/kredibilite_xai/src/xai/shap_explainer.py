"""
src/xai/shap_explainer.py
─────────────────────────
SHAP TreeExplainer ile kredi kararı açıklamaları üretir.

Fonksiyonlar:
  load_explainer()     → model bundle + SHAP explainer
  explain_instance()   → tek örnek için SHAP değerleri
  plot_waterfall()     → waterfall grafiği (PNG veya inline)
  plot_beeswarm()      → beeswarm / summary grafiği
  top_factors()        → insan okunabilir Türkçe açıklama listesi
"""

import joblib
import shap
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")          # GUI olmayan ortamda çalışsın
import matplotlib.pyplot as plt
from pathlib import Path
import sys

sys.path.append(str(Path(__file__).resolve().parent.parent.parent.parent.parent))
from applications.kredibilite_xai.src.config import MODELS_DIR

# ── Türkçe kolon görüntü isimleri (encode edilmiş kolonlar için) ──────────
def _pretty(col: str) -> str:
    """
    Encode edilmiş kolon ismini okunabilir Türkçe etikete çevirir.
    Örn: 'vadesiz_hesap_lt0_' → 'Vadesiz Hesap: < 0€'
    """
    # Önce prefix → kategori adı eşleşmesi
    CAT_PREFIXES = {
        "vadesiz_hesap_"    : "Vadesiz Hesap",
        "kredi_gecmisi_"    : "Kredi Geçmişi",
        "kredi_amaci_"      : "Kredi Amacı",
        "birikim_hesabi_"   : "Birikim Hesabı",
        "istihdam_"         : "İstihdam",
        "medeni_durum_"     : "Medeni Durum",
        "diger_taraflar_"   : "Diğer Taraflar",
        "mulk_varligi_"     : "Mülk Varlığı",
        "diger_odeme_"      : "Diğer Ödeme",
        "konut_"            : "Konut",
        "is_niteligi_"      : "İş Niteliği",
        "telefon_"          : "Telefon",
        "yabanci_isci_"     : "Yabancı İşçi",
    }

    # Sayısal kolonlar
    NUMERIC_LABELS = {
        "kredi_suresi"    : "Kredi Süresi (ay)",
        "kredi_tutari"    : "Kredi Tutarı (€)",
        "taksit_orani"    : "Taksit Oranı (%)",
        "ikamet_suresi"   : "İkamet Süresi (yıl)",
        "yas"             : "Yaş",
        "mevcut_kredi"    : "Mevcut Kredi Sayısı",
        "bakmakla_yukulmu": "Bakmakla Yükümlü",
    }

    # Değer parçası temizleme haritası — anahtarlar HAM (encode edilmemiş)
    # kategori değerleridir. Encode edilmiş kolon suffix'iyle karşılaştırmak
    # için aşağıda _sanitize_value() ile AYNI dönüşümden geçirilirler, böylece
    # "sanitize_columns()" ile bu harita hep senkron kalır (önceki sürümde
    # ">200€" anahtarı "gt200€" suffix'iyle asla eşleşmiyordu — bkz. sanitize
    # adımındaki "<"→"lt", ">"→"gt" dönüşümü).
    RAW_VALUE_LABELS = {
        # vadesiz hesap / birikim
        "<0€": "< 0€", "0-200€": "0–200€", ">200€": "> 200€", "hesap_yok": "Hesap Yok",
        "<100€": "< 100€", "100-500€": "100–500€", "500-1000€": "500–1000€",
        ">1000€": "> 1000€", "bilgi_yok": "Bilgi Yok",
        # kredi geçmişi
        "kritik_hesap": "Kritik Hesap", "gecikmeli_ödeme": "Gecikmeli Ödeme",
        "mevcut_sorunsuz": "Mevcut / Sorunsuz", "sorunsuz_ödeme": "Sorunsuz Ödeme",
        "tüm_borçlar_ödenmiş": "Tüm Borçlar Ödenmiş",
        # istihdam
        "<1 yıl": "< 1 Yıl", "1-4 yıl": "1–4 Yıl", "4-7 yıl": "4–7 Yıl",
        "≥7 yıl": "≥ 7 Yıl", "işsiz": "İşsiz",
        # mülk
        "gayrimenkul": "Gayrimenkul", "hayat_sigortası": "Hayat Sigortası", "mülk_yok": "Mülk Yok",
        # konut
        "ev sahibi": "Ev Sahibi", "ücretsiz": "Ücretsiz", "kiracı": "Kiracı",
        # iş niteliği
        "vasıfsız_kayıtsız": "Vasıfsız / Kayıtsız", "vasıfsız_kayıtlı": "Vasıfsız / Kayıtlı",
        "nitelikli": "Nitelikli", "yönetici_uzman": "Yönetici / Uzman",
        # medeni durum
        "erkek_bekar": "Erkek / Bekar", "erkek_evli": "Erkek / Evli",
        "kadın_bekar_boşanmış": "Kadın / Bekar-Boşanmış", "erkek_boşanmış": "Erkek / Boşanmış",
        # diğerleri
        "kefil": "Kefil", "ortak_borçlu": "Ortak Borçlu", "evet": "Evet",
        "hayır": "Hayır", "yok": "Yok", "banka": "Banka", "mağaza": "Mağaza",
        # kredi amacı
        "araba": "Araba", "mobilya": "Mobilya", "elektronik": "Elektronik",
        "beyazeşya": "Beyaz Eşya", "tamirat": "Tamirat", "eğitim": "Eğitim",
        "yeniden_finansman": "Yeniden Finansman", "iş": "İş", "tatil": "Tatil", "diğer": "Diğer",
    }

    def _sanitize_value(v: str) -> str:
        """preprocess.sanitize_columns() ile birebir aynı dönüşüm."""
        return (v.replace("[", "_").replace("]", "_")
                  .replace("<", "lt").replace(">", "gt")
                  .replace(" ", "_"))

    VALUE_MAP = {_sanitize_value(raw): label for raw, label in RAW_VALUE_LABELS.items()}

    # Sayısal kolon ise direk döndür
    if col in NUMERIC_LABELS:
        return NUMERIC_LABELS[col]

    # Kategorik prefix ara
    for prefix, cat_label in CAT_PREFIXES.items():
        if col.startswith(prefix):
            suffix = col[len(prefix):]
            clean = VALUE_MAP.get(suffix, suffix.replace("_", " "))
            return f"{cat_label}: {clean}"

    # Hiçbiri değilse: basit temizlik
    return col.replace("_", " ").title()


# ── Yükleyici ─────────────────────────────────────────────────────────────
def load_explainer():
    """
    Returns: (bundle, explainer)
      bundle   : joblib'den gelen dict (model, feature_cols, metrics…)
      explainer: shap.TreeExplainer
    """
    model_path = MODELS_DIR / "xgboost_credit.pkl"
    if not model_path.exists():
        raise FileNotFoundError(
            f"Model bulunamadı: {model_path}\n"
            "Önce `python src/model/train.py` çalıştırın."
        )
    bundle   = joblib.load(model_path)
    model    = bundle["model"]
    explainer = shap.TreeExplainer(model)
    return bundle, explainer


# ── Tek örnek açıklama ────────────────────────────────────────────────────
def explain_instance(instance: pd.DataFrame, explainer, feature_cols: list):
    """
    instance     : 1 satırlık DataFrame (feature_cols kolonları)
    Returns: shap.Explanation objesi
    """
    shap_values = explainer(instance[feature_cols])
    return shap_values


# ── Waterfall grafiği ─────────────────────────────────────────────────────
def plot_waterfall(shap_exp, instance: pd.DataFrame,
                   feature_cols: list, save_path=None,
                   risk_prob: float = None):
    """
    Tek örnek için waterfall grafiği.
    save_path verilirse PNG kaydeder, yoksa plt.show() çağırır.
    """
    vals    = shap_exp.values[0]         # (n_features,)
    base    = shap_exp.base_values[0]

    # Türkçe etiketler ve değerler
    labels  = [_pretty(c) for c in feature_cols]
    data_vals = instance[feature_cols].values[0]

    # En yüksek |SHAP| değerine sahip 12 özellik
    top_idx = np.argsort(np.abs(vals))[::-1][:12]
    top_vals   = vals[top_idx]
    top_labels = [f"{labels[i]}\n= {data_vals[i]}" for i in top_idx]

    fig, ax = plt.subplots(figsize=(10, 6))
    colors  = ["#d73027" if v > 0 else "#4575b4" for v in top_vals]
    bars    = ax.barh(range(len(top_vals)), top_vals[::-1],
                      color=colors[::-1], edgecolor="white", height=0.65)

    ax.set_yticks(range(len(top_vals)))
    ax.set_yticklabels(top_labels[::-1], fontsize=9)
    ax.axvline(0, color="black", linewidth=0.8)
    ax.set_xlabel("SHAP Değeri  (→ Riski Artırır  |  ← Riski Azaltır)", fontsize=10)

    title = "Kredi Kararı Açıklaması — SHAP Waterfall"
    if risk_prob is not None:
        title += f"\nRisk Olasılığı: %{risk_prob*100:.0f}"
    ax.set_title(title, fontsize=12, fontweight="bold", pad=14)

    # Değer etiketleri
    for bar, val in zip(bars, top_vals[::-1]):
        ax.text(val + (0.003 if val >= 0 else -0.003),
                bar.get_y() + bar.get_height() / 2,
                f"{val:+.3f}", va="center",
                ha="left" if val >= 0 else "right", fontsize=8)

    # Sağ üst köşe: baz değer
    ax.text(0.98, 0.02, f"Baz değer: {base:.3f}", transform=ax.transAxes,
            ha="right", va="bottom", fontsize=8, color="gray")

    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"💾 Waterfall grafiği kaydedildi → {save_path}")
        plt.close()
    else:
        plt.show()

    return fig


# ── Beeswarm grafiği ──────────────────────────────────────────────────────
def plot_beeswarm(explainer, X: pd.DataFrame, feature_cols: list,
                  save_path=None, max_display: int = 15):
    """
    Tüm veri seti üzerinde özet beeswarm / summary grafiği.
    """
    shap_vals = explainer.shap_values(X[feature_cols])
    labels    = [_pretty(c) for c in feature_cols]

    fig, ax = plt.subplots(figsize=(10, 7))
    shap.summary_plot(
        shap_vals, X[feature_cols],
        feature_names=labels,
        max_display=max_display,
        show=False, plot_type="dot"
    )
    plt.title("Kredi Riski — Genel Özellik Önemi (SHAP Beeswarm)",
              fontsize=12, fontweight="bold")
    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"💾 Beeswarm grafiği kaydedildi → {save_path}")
        plt.close()
    else:
        plt.show()

    return fig


# ── İnsan okunabilir açıklama ─────────────────────────────────────────────
def top_factors(shap_exp, feature_cols: list, n: int = 5) -> list[dict]:
    """
    En etkili N faktörü Türkçe açıklamayla döner.

    Returns: [{"özellik": ..., "etki": "artırıyor/azaltıyor",
               "shap": float, "label": str}, ...]
    """
    vals   = shap_exp.values[0]
    labels = [_pretty(c) for c in feature_cols]

    top_idx = np.argsort(np.abs(vals))[::-1][:n]
    result  = []
    for i in top_idx:
        result.append({
            "özellik" : feature_cols[i],
            "label"   : labels[i],
            "shap"    : float(vals[i]),
            "etki"    : "riski artırıyor" if vals[i] > 0 else "riski azaltıyor",
        })
    return result


# ── CLI test ─────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import pandas as pd
    from applications.kredibilite_xai.src.config import DATA_PROCESSED
    from pathlib import Path

    print("🔄 Model ve açıklayıcı yükleniyor...")
    bundle, explainer = load_explainer()
    model        = bundle["model"]
    feature_cols = bundle["feature_cols"]

    # İşlenmiş veriyi yükle
    df_enc = pd.read_csv(DATA_PROCESSED / "credit_processed.csv")
    X = df_enc[feature_cols]

    # Demo: ilk 3 örneği dene, yüksek riskli birini seç
    probs = model.predict_proba(X)[:, 1]
    high_risk_idx = probs.argsort()[::-1][0]   # en yüksek riskli
    low_risk_idx  = probs.argsort()[0]          # en düşük riskli

    for label, idx in [("YÜKSEK RİSKLİ", high_risk_idx),
                        ("DÜŞÜK RİSKLİ",  low_risk_idx)]:
        instance = X.iloc[[idx]]
        prob     = probs[idx]
        print(f"\n{'─'*55}")
        print(f"📌 Örnek: {label}  |  Risk Olasılığı: %{prob*100:.1f}")

        shap_exp = explain_instance(instance, explainer, feature_cols)

        factors = top_factors(shap_exp, feature_cols, n=5)
        print("\n🔍 En Etkili 5 Faktör:")
        for f in factors:
            arrow = "🔴" if f["etki"] == "riski artırıyor" else "🟢"
            print(f"  {arrow} {f['label']:<45} SHAP={f['shap']:+.4f}  ({f['etki']})")

        # Grafik kaydet
        out_dir = Path("docs")
        out_dir.mkdir(exist_ok=True)
        plot_waterfall(shap_exp, instance, feature_cols,
                       save_path=out_dir / f"waterfall_{label.lower().replace(' ','_')}.png",
                       risk_prob=prob)

    # Beeswarm (tüm veri)
    print("\n📊 Beeswarm grafiği üretiliyor (tüm veri)...")
    plot_beeswarm(explainer, X, feature_cols,
                  save_path=Path("docs") / "beeswarm_summary.png")

    print("\n✅ SHAP modülü başarıyla test edildi.")
