"""
src/xai/dice_explainer.py

Model tabanli aksiyon recetesi motoru.

Bu modul dice-ml'e bagimli degildir. Kullanici profilinden uygulanabilir
degisiklik adaylari uretir, her adayi egitilmis XGBoost modeliyle tekrar
skorlar ve riski en cok dusuren 3 senaryoyu dondurur.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from pathlib import Path
import sys

import joblib
import numpy as np
import pandas as pd

sys.path.append(str(Path(__file__).resolve().parent.parent.parent.parent.parent))
from applications.kredibilite_xai.src.config import MODELS_DIR, TARGET_COL, DICE_NUM_CF
from applications.kredibilite_xai.src.data.preprocess import NUMERIC_COLS, CATEGORICAL_COLS, encode, preprocess


FIELD_LABELS = {
    "kredi_suresi": "Kredi Suresi (ay)",
    "kredi_tutari": "Kredi Tutari (EUR)",
    "taksit_orani": "Taksit Orani (%)",
    "ikamet_suresi": "Ikamet Suresi (yil)",
    "yas": "Yas",
    "mevcut_kredi": "Mevcut Kredi Sayisi",
    "bakmakla_yukulmu": "Bakmakla Yukumlu",
    "vadesiz_hesap": "Vadesiz Hesap Durumu",
    "kredi_gecmisi": "Kredi Gecmisi",
    "kredi_amaci": "Kredi Amaci",
    "birikim_hesabi": "Birikim Hesabi",
    "istihdam": "Istihdam Suresi",
    "medeni_durum": "Medeni Durum",
    "diger_taraflar": "Kefil / Ortak",
    "mulk_varligi": "Mulk Varligi",
    "diger_odeme": "Diger Odeme Plani",
    "konut": "Konut Durumu",
    "is_niteligi": "Is Niteligi",
    "telefon": "Telefon",
    "yabanci_isci": "Yabanci Isci",
}

IMMUTABLE = {"yas", "medeni_durum", "yabanci_isci", "is_niteligi"}

TARGET_VALUES = {
    "vadesiz_hesap": [">200€", "0-200€", "hesap_yok"],
    "birikim_hesabi": [">1000€", "500-1000€", "100-500€"],
    "kredi_gecmisi": ["mevcut_sorunsuz", "sorunsuz_ödeme", "tüm_borçlar_ödenmiş"],
    "diger_taraflar": ["kefil", "ortak_borçlu"],
    "diger_odeme": ["yok", "banka"],
    "konut": ["ev sahibi"],
    "mulk_varligi": ["gayrimenkul", "hayat_sigortası", "araba"],
    "telefon": ["evet"],
}

NUMERIC_STRATEGIES = {
    "kredi_tutari": [0.85, 0.75, 0.65],
    "kredi_suresi": [12, 24],
    "taksit_orani": [1, 2],
    "mevcut_kredi": [1],
}


@dataclass
class RecipeEngine:
    model: object
    feature_cols: list[str]
    threshold: float
    categories: dict[str, list[str]]
    ranges: dict[str, tuple[float, float]]


@dataclass
class Candidate:
    profile: dict
    actions: list[tuple[str, object, object]]
    risk: float
    approved: bool


def build_dice(df_raw: pd.DataFrame, bundle: dict):
    """Arayuzle uyumlu kalmak icin eski build_dice imzasini korur."""
    engine = RecipeEngine(
        model=bundle["model"],
        feature_cols=bundle["feature_cols"],
        threshold=float(bundle.get("optimal_threshold", 0.5)),
        categories={
            col: sorted(df_raw[col].dropna().astype(str).unique().tolist())
            for col in CATEGORICAL_COLS
        },
        ranges={
            col: (float(df_raw[col].min()), float(df_raw[col].max()))
            for col in NUMERIC_COLS
        },
    )
    return engine, df_raw


def generate_cfs(
    exp: RecipeEngine,
    instance_raw: pd.DataFrame,
    n_cf: int | None = None,
    desired_class: int = 0,
) -> list[Candidate]:
    """Riski dusuren karsi senaryolari model skoruyla uretir."""
    del desired_class
    n_cf = n_cf or DICE_NUM_CF
    base = _normalize_profile(exp, instance_raw.drop(columns=[TARGET_COL], errors="ignore").iloc[0].to_dict())
    base_risk = _predict_risk(exp, base)
    atomic = _atomic_actions(exp, base)

    candidate_profiles: list[tuple[dict, list[tuple[str, object, object]]]] = []
    seen: set[tuple] = set()

    for size in (1, 2, 3):
        for action_group in combinations(atomic, size):
            profile = base.copy()
            actions = []
            for col, target in action_group:
                current = profile.get(col)
                if str(current) == str(target):
                    continue
                profile[col] = target
                actions.append((col, current, target))

            if not actions:
                continue

            key = tuple(sorted((col, str(target)) for col, _, target in actions))
            if key in seen:
                continue
            seen.add(key)
            candidate_profiles.append((profile, actions))

    if not candidate_profiles:
        return []

    risks = _predict_risks(exp, [profile for profile, _ in candidate_profiles])
    candidates = []
    for (profile, actions), risk in zip(candidate_profiles, risks):
        if risk >= base_risk - 0.005:
            continue
        candidates.append(
            Candidate(
                profile=profile,
                actions=actions,
                risk=float(risk),
                approved=float(risk) < exp.threshold,
            )
        )

    candidates.sort(key=lambda c: (not c.approved, len(c.actions), c.risk))
    return candidates[:n_cf]


def format_action_cards(cf_result, instance_raw: pd.DataFrame) -> list[dict]:
    """Aday senaryolari Streamlit kartlarina uygun sozluklere cevirir."""
    cards = []
    if not cf_result:
        return []

    for index, candidate in enumerate(cf_result, start=1):
        actions = []
        for col, current, target in candidate.actions:
            actions.append(
                {
                    "alan": FIELD_LABELS.get(col, col),
                    "mevcut": _format_value(col, current),
                    "hedef": _format_value(col, target),
                    "aciklama": _action_text(col, current, target),
                    "açıklama": _action_text(col, current, target),
                }
            )

        status = (
            f"Dusuk Risk - Tahmini risk %{candidate.risk * 100:.0f}"
            if candidate.approved
            else f"Riski Azaltir - Tahmini risk %{candidate.risk * 100:.0f}"
        )
        cards.append({"cf_no": index, "actions": actions, "sonuc": status, "sonuç": status})

    return cards


def fallback_action_cards(instance_raw: pd.DataFrame, n_cf: int = 3) -> list[dict]:
    """Model aday uretmezse yine temiz ve okunabilir kart dondurur."""
    row = instance_raw.drop(columns=[TARGET_COL], errors="ignore").iloc[0].to_dict()
    plans = [
        [("vadesiz_hesap", ">200€"), ("birikim_hesabi", ">1000€"), ("taksit_orani", 1)],
        [("kredi_tutari", max(500, float(row.get("kredi_tutari", 500)) * 0.75)), ("diger_taraflar", "kefil")],
        [("kredi_gecmisi", "mevcut_sorunsuz"), ("diger_odeme", "yok"), ("konut", "ev sahibi")],
    ]

    cards = []
    for index, plan in enumerate(plans[:n_cf], start=1):
        actions = []
        for col, target in plan:
            current = row.get(col)
            if current is None or str(current) == str(target):
                continue
            actions.append(
                {
                    "alan": FIELD_LABELS.get(col, col),
                    "mevcut": _format_value(col, current),
                    "hedef": _format_value(col, target),
                    "aciklama": _action_text(col, current, target),
                    "açıklama": _action_text(col, current, target),
                }
            )
        cards.append({"cf_no": index, "actions": actions, "sonuc": "Oneri Senaryosu", "sonuç": "Oneri Senaryosu"})
    return cards


def _normalize_profile(engine: RecipeEngine, profile: dict) -> dict:
    normalized = profile.copy()
    for col, (lo, hi) in engine.ranges.items():
        value = pd.to_numeric(normalized.get(col), errors="coerce")
        if pd.isna(value):
            value = lo
        normalized[col] = float(np.clip(value, lo, hi))

    for col, valid_values in engine.categories.items():
        value = str(normalized.get(col, valid_values[0]))
        if value not in valid_values:
            normalized[col] = valid_values[0]
    return normalized


def _predict_risk(engine: RecipeEngine, profile: dict) -> float:
    return float(_predict_risks(engine, [profile])[0])


def _predict_risks(engine: RecipeEngine, profiles: list[dict]) -> np.ndarray:
    df = pd.DataFrame([{**profile, TARGET_COL: 0} for profile in profiles])
    encoded = encode(df)
    for col in engine.feature_cols:
        if col not in encoded.columns:
            encoded[col] = 0
    X = encoded[engine.feature_cols].astype(float)
    return engine.model.predict_proba(X)[:, 1]


def _atomic_actions(engine: RecipeEngine, base: dict) -> list[tuple[str, object]]:
    actions: list[tuple[str, object]] = []

    for col, values in TARGET_VALUES.items():
        if col in IMMUTABLE or col not in base:
            continue
        valid_values = set(engine.categories.get(col, []))
        for value in values:
            if value in valid_values and str(base.get(col)) != str(value):
                actions.append((col, value))

    amount = float(base.get("kredi_tutari", 0))
    lo_amount, hi_amount = engine.ranges.get("kredi_tutari", (500, 18000))
    for factor in NUMERIC_STRATEGIES["kredi_tutari"]:
        target = float(np.clip(round(amount * factor / 100) * 100, lo_amount, hi_amount))
        if target < amount:
            actions.append(("kredi_tutari", target))

    duration = float(base.get("kredi_suresi", 0))
    lo_duration, hi_duration = engine.ranges.get("kredi_suresi", (6, 60))
    for add_months in NUMERIC_STRATEGIES["kredi_suresi"]:
        target = float(np.clip(duration + add_months, lo_duration, hi_duration))
        if target != duration:
            actions.append(("kredi_suresi", target))

    installment = float(base.get("taksit_orani", 4))
    for target in NUMERIC_STRATEGIES["taksit_orani"]:
        if target < installment:
            actions.append(("taksit_orani", target))

    credit_count = float(base.get("mevcut_kredi", 1))
    if credit_count > 1:
        actions.append(("mevcut_kredi", 1))

    return actions


def _format_value(col: str, value) -> str:
    if col in NUMERIC_COLS:
        number = float(value)
        if col == "kredi_tutari":
            return f"{number:,.0f} EUR"
        return f"{number:.0f}"
    return str(value)


def _action_text(col: str, current, target) -> str:
    label = FIELD_LABELS.get(col, col)

    if col == "kredi_tutari":
        return f"Kredi talebini {_format_value(col, current)} seviyesinden {_format_value(col, target)} seviyesine indirin."
    if col == "kredi_suresi":
        return f"Vadeyi {_format_value(col, current)} aydan {_format_value(col, target)} aya cekerek aylik odeme baskisini dusurun."
    if col == "taksit_orani":
        return f"Taksit yukumlulugu oranini %{_format_value(col, current)} seviyesinden %{_format_value(col, target)} seviyesine dusurun."
    if col == "mevcut_kredi":
        return "Mevcut acik kredi sayisini azaltin veya kapatma planini belgeleyin."
    if col == "vadesiz_hesap":
        return "Vadesiz hesap bakiyesini guclendirerek likidite sinyalini iyilestirin."
    if col == "birikim_hesabi":
        return "Birikim hesabini artirarak nakit tamponunuzu guclendirin."
    if col == "kredi_gecmisi":
        return "Gecikmeli/kritik kayitlari kapatip sorunsuz odeme gecmisi olusturun."
    if col == "diger_taraflar":
        return "Basvuruya kefil veya ortak borclu ekleyerek teminat gucunu artirin."
    if col == "diger_odeme":
        return "Diger odeme planlarini kapatarak gelir uzerindeki baskiyi azaltin."
    if col == "konut":
        return "Konut/ikamet durumunu daha guclu teminat sinyali verecek sekilde belgeleyin."
    if col == "mulk_varligi":
        return "Basvuruda daha guclu varlik veya teminat beyan edin."
    if col == "telefon":
        return "Dogrulanabilir sabit iletisim bilgisini basvuruya ekleyin."
    return f"{label} degerini '{current}' yerine '{target}' olarak guncelleyin."


def print_action_report(cards: list[dict], instance_raw: pd.DataFrame, risk_prob: float | None = None):
    print("\nKREDIBILITE XAI - AKSIYON RECETESI")
    if risk_prob is not None:
        print(f"Mevcut risk: %{risk_prob * 100:.1f}")
    for card in cards:
        print(f"\nSenaryo {card['cf_no']} | {card.get('sonuc', card.get('sonuç'))}")
        for i, action in enumerate(card["actions"], start=1):
            print(f"  {i}. {action['alan']}: {action['mevcut']} -> {action['hedef']}")
            print(f"     {action.get('aciklama', action.get('açıklama'))}")


if __name__ == "__main__":
    bundle = joblib.load(MODELS_DIR / "xgboost_credit.pkl")
    df_raw, df_enc, _ = preprocess(save=False)
    probs = bundle["model"].predict_proba(df_enc[bundle["feature_cols"]])[:, 1]
    idx = int(probs.argsort()[::-1][0])
    instance_raw = df_raw.iloc[[idx]].copy()
    engine, _ = build_dice(df_raw, bundle)
    candidates = generate_cfs(engine, instance_raw)
    cards = format_action_cards(candidates, instance_raw)
    print_action_report(cards, instance_raw, float(probs[idx]))
