"""
src/xai/llm_explainer.py
─────────────────────────
Ollama yerel LLM ile SHAP + DiCE çıktılarını
Türkçe doğal dile çevirir.

Kurulum (bir kez):
    1. https://ollama.com/download  → Windows installer
    2. ollama pull llama3.2
    3. ollama serve          (arka planda çalışır)
    4. pip install ollama

Kullanım:
    from applications.kredibilite_xai.src.xai.llm_explainer import explain_in_turkish
    text = explain_in_turkish(prob, factors, cards)
"""

# ── Prompt şablonları (risk seviyesine göre) ──────────────────────────────
PROMPTS = {
    "high": """Sen bir kredi risk analisti yapay zeka asistanısın. Aşağıdaki bilgilere dayanarak KOBİ sahibine sade ve anlaşılır Türkçe ile 3-4 cümlelik bir açıklama yaz.

Risk Skoru: %{risk_pct} (YÜKSEK RİSK)
En Etkili Faktörler:
{factors}

Önerilen Aksiyonlar (en kısa senaryo):
{actions}

Kurallar:
- Teknik terim kullanma (SHAP, XGBoost, counterfactual gibi kelimeler yazma)
- "Sisteminiz" veya "modelimiz" deme, doğrudan KOBİ sahibine hitap et
- Umut verici ama gerçekçi ol — başvurunun şu an reddedileceğini söyle ama iyileştirme yolunu göster
- Maksimum 4 cümle""",

    "medium": """Sen bir kredi risk analisti yapay zeka asistanısın. Aşağıdaki bilgilere dayanarak KOBİ sahibine sade ve anlaşılır Türkçe ile 3-4 cümlelik bir açıklama yaz.

Risk Skoru: %{risk_pct} (ORTA RİSK)
En Etkili Faktörler:
{factors}

Kurallar:
- Teknik terim kullanma
- Başvurunun değerlendirmede olduğunu, ek belge/güvence istenilebileceğini belirt
- Güçlü yönleri de vurgula
- Maksimum 4 cümle""",

    "low": """Sen bir kredi risk analisti yapay zeka asistanısın. Aşağıdaki bilgilere dayanarak KOBİ sahibine sade ve anlaşılır Türkçe ile 2-3 cümlelik bir açıklama yaz.

Risk Skoru: %{risk_pct} (DÜŞÜK RİSK)
En Etkili Faktörler:
{factors}

Kurallar:
- Teknik terim kullanma
- Başvurunun olumlu göründüğünü, güçlü finansal profilini öne çıkar
- Maksimum 3 cümle"""
}

FALLBACK_MESSAGES = {
    "high": (
        "Kredi başvurunuz şu anda yüksek risk kategorisinde değerlendiriliyor. "
        "Kredi geçmişiniz ve hesap durumunuz bu kararın başlıca nedenleri arasında yer alıyor. "
        "Aşağıdaki aksiyon reçetesini uygulayarak risk profilinizi önemli ölçüde iyileştirebilirsiniz."
    ),
    "medium": (
        "Kredi başvurunuz orta risk kategorisinde görünüyor. "
        "Banka ek belgeler veya güvence talep edebilir. "
        "Finansal profilinizi güçlendirmeniz onay ihtimalinizi artıracaktır."
    ),
    "low": (
        "Kredi başvurunuz düşük risk kategorisinde değerlendiriliyor. "
        "Finansal profiliniz genel itibarıyla sağlıklı görünüyor. "
        "Başvurunuzun olumlu sonuçlanma ihtimali yüksektir."
    ),
}


def _risk_level(prob: float) -> str:
    if prob >= 0.65:
        return "high"
    elif prob >= 0.40:
        return "medium"
    return "low"


def _format_factors(factors: list[dict]) -> str:
    """SHAP faktörlerini prompt için okunabilir listeye çevirir."""
    lines = []
    for f in factors[:5]:
        etki = "olumsuz etkiliyor (riski artırıyor)" if f["shap"] > 0 else "olumlu etkiliyor (riski azaltıyor)"
        lines.append(f"- {f['label']}: {etki}")
    return "\n".join(lines)


def _format_actions(cards: list[dict]) -> str:
    """DiCE kartlarının ilk senaryosunu prompt için listeye çevirir."""
    if not cards:
        return "- Mevcut profil için aksiyon bulunamadı."
    best = cards[0]
    if not best.get("actions"):
        return "- Büyük değişiklik gerekmemektedir."
    lines = []
    for i, a in enumerate(best["actions"][:3], 1):
        lines.append(f"{i}. {a['açıklama']}")
    return "\n".join(lines)


def explain_in_turkish(
    prob: float,
    factors: list[dict],
    cards: list[dict],
    model: str = "llama3.2",
    timeout: int = 15,
) -> tuple[str, bool]:
    """
    Türkçe açıklama üretir.

    Returns
    -------
    (text, is_llm)
        text   : üretilen metin
        is_llm : True = Ollama ürettti, False = fallback statik metin
    """
    level  = _risk_level(prob)
    prompt = PROMPTS[level].format(
        risk_pct=int(prob * 100),
        factors=_format_factors(factors),
        actions=_format_actions(cards),
    )

    try:
        import ollama  # noqa: F401 — kurulu değilse ImportError
        import ollama as ol

        response = ol.chat(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            options={"num_predict": 200, "temperature": 0.4},
        )

        text = response["message"]["content"].strip()
        # Boş veya çok kısa yanıt → fallback
        if len(text) < 30:
            return FALLBACK_MESSAGES[level], False

        return text, True

    except ImportError:
        # pip install ollama yapılmamış
        return FALLBACK_MESSAGES[level], False

    except Exception:
        # Ollama kapalı veya model yok → sessizce fallback
        return FALLBACK_MESSAGES[level], False


def check_ollama_status(model: str = "llama3.2") -> dict:
    """
    Ollama durumunu kontrol eder.
    Returns: {"available": bool, "model_ready": bool, "message": str}
    """
    try:
        import ollama as ol
        models = ol.list()
        model_names = [m["model"].split(":")[0] for m in models.get("models", [])]
        model_ready = model in model_names or any(model in n for n in model_names)
        return {
            "available"  : True,
            "model_ready": model_ready,
            "message"    : f"✅ Ollama aktif — model: {'hazır' if model_ready else 'çekiliyor...'}"
        }
    except ImportError:
        return {"available": False, "model_ready": False,
                "message": "⚠️ ollama paketi kurulu değil → pip install ollama"}
    except Exception:
        return {"available": False, "model_ready": False,
                "message": "⚠️ Ollama çalışmıyor → terminal'de: ollama serve"}


# ── CLI test ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys, warnings
    warnings.filterwarnings("ignore")
    sys.path.append(".")

    from applications.kredibilite_xai.src.xai.shap_explainer import load_explainer, explain_instance, top_factors
    from applications.kredibilite_xai.src.xai.dice_explainer import build_dice, generate_cfs, format_action_cards
    from applications.kredibilite_xai.src.data.preprocess import preprocess, encode
    from applications.kredibilite_xai.src.config import TARGET_COL
    import pandas as pd

    print("=" * 55)
    print("  Kredibilite XAI — LLM Açıklama Motoru Testi")
    print("=" * 55)

    # Ollama durumu
    status = check_ollama_status()
    print(f"\n{status['message']}")

    # Model + veri
    print("\n🔄 Model yükleniyor...")
    bundle, shap_exp = load_explainer()
    df_raw_full, _, _ = preprocess(save=False)

    # Yüksek riskli profil
    feature_cols = bundle["feature_cols"]
    inputs = {
        "kredi_suresi": 36, "kredi_tutari": 12000, "taksit_orani": 4,
        "ikamet_suresi": 2, "yas": 38, "mevcut_kredi": 2, "bakmakla_yukulmu": 1,
        "vadesiz_hesap": "<0€", "kredi_gecmisi": "gecikmeli_ödeme",
        "kredi_amaci": "iş", "birikim_hesabi": "<100€", "istihdam": "1-4 yıl",
        "medeni_durum": "erkek_bekar", "diger_taraflar": "yok",
        "mulk_varligi": "mülk_yok", "diger_odeme": "mağaza",
        "konut": "kiracı", "is_niteligi": "nitelikli",
        "telefon": "hayır", "yabanci_isci": "hayır",
    }
    df_enc = encode(pd.DataFrame([{**inputs, TARGET_COL: 0}]))
    for col in feature_cols:
        if col not in df_enc.columns:
            df_enc[col] = 0
    df_enc = df_enc[feature_cols].astype(float)

    prob = float(bundle["model"].predict_proba(df_enc)[:, 1][0])
    print("\n👤 Test Profili (Tekstilci Ahmet Bey)")
    print(f"   Risk Olasılığı: %{prob*100:.1f} — {_risk_level(prob).upper()}")

    # SHAP
    shap_result = explain_instance(df_enc, shap_exp, feature_cols)
    factors     = top_factors(shap_result, feature_cols, n=5)

    # DiCE
    print("\n⚙️  DiCE hesaplanıyor...")
    dice_exp  = build_dice(df_raw_full, bundle)[0]
    cf_result = generate_cfs(dice_exp,
                              pd.DataFrame([{**inputs, TARGET_COL: 1}]),
                              desired_class=0)
    cards = format_action_cards(cf_result,
                                pd.DataFrame([{**inputs, TARGET_COL: 1}]))

    # LLM
    print("\n🤖 LLM açıklama üretiliyor...")
    text, is_llm = explain_in_turkish(prob, factors, cards)

    print(f"\n{'─'*55}")
    source = "Ollama (llama3.2)" if is_llm else "Statik Fallback"
    print(f"  Kaynak: {source}")
    print(f"{'─'*55}")
    print(f"\n{text}")
    print(f"\n{'='*55}")
    print("✅ llm_explainer.py testi tamamlandı.")
