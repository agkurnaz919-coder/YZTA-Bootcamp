# src/config.py
# Proje genelinde kullanılan sabitler ve yollar

from pathlib import Path

# ── Dizinler ─────────────────────────────────────────────────────────────
ROOT_DIR      = Path(__file__).resolve().parent.parent
DATA_RAW      = ROOT_DIR / "data" / "raw"
DATA_PROCESSED= ROOT_DIR / "data" / "processed"
MODELS_DIR    = ROOT_DIR / "models"
DOCS_DIR      = ROOT_DIR / "docs"

# ── Veri ─────────────────────────────────────────────────────────────────
RAW_DATA_FILE       = DATA_RAW / "german_credit.csv"
PROCESSED_DATA_FILE = DATA_PROCESSED / "credit_processed.csv"

# ── Model ─────────────────────────────────────────────────────────────────
MODEL_FILE    = MODELS_DIR / "xgboost_credit.pkl"
RANDOM_STATE  = 42
TEST_SIZE     = 0.2

# ── XGBoost Hiperparametreleri (başlangıç) ────────────────────────────────
XGB_PARAMS = {
    "n_estimators": 200,
    "max_depth": 4,
    "learning_rate": 0.05,
    "subsample": 0.8,
    "colsample_bytree": 0.8,
    "use_label_encoder": False,
    "eval_metric": "logloss",
    "random_state": RANDOM_STATE,
}

# ── DiCE Ayarları ─────────────────────────────────────────────────────────
DICE_NUM_CF       = 3      # Kaç counterfactual üretilecek
DICE_DESIRED_CLASS = "opposite"  # Reddi onaya çevir

# ── Hedef Değişken ────────────────────────────────────────────────────────
TARGET_COL    = "kredi_riski"   # 0 = Düşük risk (iyi), 1 = Yüksek risk (kötü)

# ── Kolon İsimleri (Türkçeleştirilmiş) ───────────────────────────────────
# NOT: Bu sözlük artık gerçek veri kolonlarıyla (src/data/generate_data.py)
# uyumlu — önceki sürümde UCI'nin orijinal İngilizce kolon adları
# (checking_status, duration, ...) kullanılıyordu ve hiç eşleşme üretmiyordu.
FEATURE_DISPLAY_NAMES = {
    "vadesiz_hesap"    : "Vadesiz Hesap Durumu",
    "kredi_suresi"     : "Kredi Süresi (ay)",
    "kredi_gecmisi"    : "Kredi Geçmişi",
    "kredi_amaci"      : "Kredi Amacı",
    "kredi_tutari"     : "Kredi Tutarı (€)",
    "birikim_hesabi"   : "Birikim Hesabı",
    "istihdam"         : "İstihdam Süresi",
    "taksit_orani"     : "Taksit Yükümlülüğü (%)",
    "medeni_durum"     : "Medeni Durum / Cinsiyet",
    "diger_taraflar"   : "Diğer Taraflar",
    "ikamet_suresi"    : "İkamet Süresi (yıl)",
    "mulk_varligi"     : "Mülk Varlığı",
    "yas"              : "Yaş",
    "diger_odeme"      : "Diğer Ödeme Planları",
    "konut"            : "Konut Durumu",
    "mevcut_kredi"     : "Mevcut Kredi Sayısı",
    "is_niteligi"      : "İş Niteliği",
    "bakmakla_yukulmu" : "Bakmakla Yükümlü Kişi",
    "telefon"          : "Telefon Sahipliği",
    "yabanci_isci"     : "Yabancı İşçi",
}
