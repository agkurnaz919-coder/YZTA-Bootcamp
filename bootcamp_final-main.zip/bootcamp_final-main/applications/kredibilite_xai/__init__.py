"""Kredibilite XAI credit-risk application."""
