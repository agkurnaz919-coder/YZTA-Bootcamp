<div align="center">

# Kredibilite XAI

**Açıklanabilir Yapay Zeka ile KOBİ Kredi Risk Değerlendirmesi**

Kredi başvurusu neden reddedildi? Onaylanmak için ne değişmeli? — İki soruyu da
model içine bakarak, tahmin bazlı değil **kanıt bazlı** yanıtlayan uçtan uca bir sistem.

[![Python](https://img.shields.io/badge/Python-3.11%2B-3776AB?logo=python&logoColor=white)](https://www.python.org/)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.58-FF4B4B?logo=streamlit&logoColor=white)](https://streamlit.io/)
[![XGBoost](https://img.shields.io/badge/XGBoost-2.x-006ACC)](https://xgboost.readthedocs.io/)
[![SHAP](https://img.shields.io/badge/SHAP-explainability-8A2BE2)](https://shap.readthedocs.io/)
[![License](https://img.shields.io/badge/License-MIT-informational)](#lisans)

</div>

---

## İçindekiler

- [Problem](#problem)
- [Yaklaşım](#yaklaşım)
- [Sistem Mimarisi](#sistem-mimarisi)
- [Öne Çıkan Özellikler](#öne-çıkan-özellikler)
- [Model Performansı](#model-performansı)
- [Proje Yapısı](#proje-yapısı)
- [Teknoloji Yığını](#teknoloji-yığını)
- [Kurulum](#kurulum)
- [Kullanım](#kullanım)
- [Tasarım Kararları](#tasarım-kararları)
- [Bilinen Sınırlamalar](#bilinen-sınırlamalar)
- [Yol Haritası](#yol-haritası)
- [Katkıda Bulunma](#katkıda-bulunma)
- [Lisans](#lisans)

---

## Problem

Türkiye'deki KOBİ'lerin büyük bölümü banka kredisi başvurularında ret kararının
gerekçesini öğrenemiyor; skor kartı sistemleri çoğunlukla bir kara kutu olarak
işliyor. Bu durum iki soruna yol açıyor:

1. **Şeffaflık eksikliği** — başvuru sahibi hangi faktörün riski artırdığını bilmiyor.
2. **Aksiyon alınamazlık** — "ne yapsam onaylanırdım?" sorusunun somut bir yanıtı yok.

**Kredibilite XAI**, bir kredi skorlama modelinin üzerine açıklanabilirlik (XAI)
katmanı inşa ederek bu iki soruyu da yanıtlayan bir karar destek simülatörüdür.

## Yaklaşım

```
Risk Skoru  →  "Neden?"          →  "Ne yapmalıyım?"        →  Doğal dilde özet
(XGBoost)      (SHAP değerleri)     (Karşı-olgusal senaryo    (opsiyonel yerel LLM)
                                      arama motoru)
```

Her katman bağımsız çalışır ve bir öncekinin çıktısını girdi olarak alır —
model kararı, o kararı açıklayan kanıt ve o kanıttan türetilen aksiyon
planı arasında tutarlılık garanti edilir.

## Sistem Mimarisi

```mermaid
flowchart TB
    subgraph Veri["📊 Veri Katmanı"]
        A1["UCI German Credit<br/>+ Sentetik KOBİ Profilleri"] --> A2["Preprocessing<br/>src/data/preprocess.py"]
    end

    subgraph Model["🧠 Model Katmanı"]
        A2 --> B1["XGBoost Sınıflandırıcı<br/>src/model/train.py"]
        B1 --> B2["Threshold Optimizasyonu<br/>F1-max · src/model/optimize_threshold.py"]
    end

    subgraph XAI["🔍 Açıklanabilirlik Katmanı"]
        B1 --> C1["SHAP Explainer<br/>Neden bu skor?"]
        B1 --> C2["Aksiyon Reçetesi Motoru<br/>DiCE-esinlenmeli karşı-olgusal arama"]
        C1 --> C3["Yerel LLM Anlatıcı<br/>Ollama / Llama 3.2 - opsiyonel"]
        C2 --> C3
    end

    subgraph UI["🖥️ Sunum Katmanı"]
        B2 --> D1["Streamlit Risk Konsolu<br/>src/ui/app.py"]
        C1 --> D1
        C2 --> D1
        C3 --> D1
    end

    style Veri fill:#0D1220,stroke:#6D5EF0,color:#E7EAF2
    style Model fill:#0D1220,stroke:#22D3EE,color:#E7EAF2
    style XAI fill:#0D1220,stroke:#F5A524,color:#E7EAF2
    style UI fill:#0D1220,stroke:#12D48A,color:#E7EAF2
```

**Neden bu katmanlı ayrım?** Her katman ayrı test edilebilir ve ayrı geliştirilebilir;
model yeniden eğitildiğinde SHAP/aksiyon motoru kodu değişmeden çalışmaya devam eder
çünkü her ikisi de model nesnesine ve `feature_cols` listesine karşı soyutlanmıştır
(bkz. `src/xai/shap_explainer.py`, `src/xai/dice_explainer.py`).

## Öne Çıkan Özellikler

| Özellik | Açıklama |
|---|---|
| **Risk Skoru** | XGBoost tabanlı, F1-optimize edilmiş karar eşiğiyle çalışan sınıflandırma |
| **SHAP Açıklaması** | Her tahmin için özellik bazlı katkı analizi + waterfall görselleştirme |
| **Aksiyon Reçetesi** | "Hangi 3 alanı değiştirirsem onay alırım?" sorusuna somut, sayısal senaryolarla yanıt |
| **Doğal Dil Anlatımı** | Yerel LLM (Ollama) ile SHAP + aksiyon çıktısının Türkçe, sohbet diline çevrilmesi — bağlantı yoksa şablon tabanlı açıklamaya otomatik düşer |
| **Toplu Analiz** | CSV yükleyerek birden çok başvuruyu aynı anda skorlama |
| **Model Şeffaflığı** | ROC eğrisi, confusion matrix ve özellik önem sıralamasının arayüz içinden izlenebilmesi |

## Model Performansı

`python src/model/train.py` çalıştırıldığında (`random_state=42`, 5-fold stratified CV) elde edilen sonuçlar:

| Metrik | Cross-Validation | Test Seti |
|---|---|---|
| ROC-AUC | 0.938 ± 0.010 | 0.916 |
| F1 Score | 0.762 ± 0.032 | 0.667 |
| Accuracy | — | 0.815 |

<details>
<summary>Sınıf bazlı detay (test seti, n=200)</summary>

| Sınıf | Precision | Recall | F1 | Destek |
|---|---|---|---|---|
| Düşük Risk | 0.85 | 0.90 | 0.87 | 140 |
| Yüksek Risk | 0.73 | 0.62 | 0.67 | 60 |

En etkili 5 özellik (gain bazlı): kredi geçmişi — kritik hesap, kredi geçmişi —
gecikmeli ödeme, kredi geçmişi — sorunsuz, vadesiz hesap bakiyesi, birikim hesabı.
Bu sıralama, `docs/beeswarm_summary.png` içindeki SHAP özetiyle tutarlıdır.

</details>

> Model, dengesiz veri setinde (%70 düşük risk / %30 yüksek risk) yüksek riskli
> sınıfı yakalamaya göre ayarlanmıştır; bu yüzden recall/precision dengesi
> varsayılan 0.5 yerine F1-max eşiğine göre optimize edilir (bkz. [Tasarım Kararları](#tasarım-kararları)).

## Proje Yapısı

```
kredibilite-xai/
├── data/
│   ├── raw/                  # Ham veri (generate_data.py ile üretilir, git-ignored)
│   └── processed/            # Encode edilmiş veri (git-ignored)
├── models/                   # Eğitilmiş model dosyası (.pkl, git-ignored)
├── docs/                     # SHAP görselleri, waterfall örnekleri
├── notebooks/                # Keşif / deney defterleri
├── src/
│   ├── config.py             # Yollar, hiperparametreler, sabitler
│   ├── data/
│   │   ├── generate_data.py  # Sentetik KOBİ verisi üretimi
│   │   └── preprocess.py     # Temizlik + one-hot encoding
│   ├── model/
│   │   ├── train.py          # XGBoost eğitimi + CV değerlendirme
│   │   └── optimize_threshold.py
│   ├── xai/
│   │   ├── shap_explainer.py     # "Neden?" katmanı
│   │   ├── dice_explainer.py     # "Ne yapmalıyım?" katmanı
│   │   └── llm_explainer.py      # Doğal dil anlatım katmanı
│   └── ui/
│       └── app.py            # Streamlit risk konsolu
├── tests/
├── requirements.txt
└── kur_ve_calistir.bat       # Windows tek-komut kurulum
```

## Teknoloji Yığını

| Katman | Teknoloji | Neden |
|---|---|---|
| Model | XGBoost | Tablosal veride güçlü performans, yerleşik özellik önemi |
| Açıklanabilirlik ("Neden?") | SHAP (TreeExplainer) | Oyun teorisi tabanlı, tutarlı ve toplanabilir katkı değerleri |
| Açıklanabilirlik ("Ne yapmalı?") | Özel karşı-olgusal arama motoru | `dice-ml` bağımlılığı yerine, aday değişikliklerin üretilip modelin kendisiyle yeniden skorlandığı hafif bir motor — bkz. `src/xai/dice_explainer.py` |
| Doğal dil katmanı | Ollama (Llama 3.2, opsiyonel) | Tamamen yerel çalışır, veri dışarı çıkmaz; kurulu değilse şablon tabanlı fallback devrede |
| Arayüz | Streamlit | Hızlı prototipleme, Python-native veri görselleştirme |
| Görselleştirme | Plotly | İnteraktif ROC / confusion matrix / özellik önemi grafikleri |

## Kurulum

### Windows (tek komut)

```bat
git clone https://github.com/<kullanici-adi>/kredibilite-xai.git
cd kredibilite-xai
kur_ve_calistir.bat
```

Script sırasıyla: sanal ortamı temizden kurar → bağımlılıkları yükler →
sentetik veriyi üretir → modeli eğitir → Streamlit uygulamasını başlatır.

### macOS / Linux

```bash
git clone https://github.com/<kullanici-adi>/kredibilite-xai.git
cd kredibilite-xai

python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

python src/data/generate_data.py
python src/model/train.py
python src/model/optimize_threshold.py

streamlit run src/ui/app.py
```

### Opsiyonel: Doğal Dil Anlatım Katmanı

```bash
# https://ollama.com üzerinden Ollama'yı kurduktan sonra:
ollama pull llama3.2
```

Ollama kurulu değilse veya çalışmıyorsa uygulama otomatik olarak şablon
tabanlı Türkçe açıklamaya düşer — kurulum zorunlu değildir.

## Kullanım

1. Sol panelden bir başvuru profili girin **veya** "Demo — Tekstilci Ahmet Bey"
   ile hazır bir senaryo yükleyin.
2. **Analizi Çalıştır**'a basın.
3. Sekmeler arasında gezinin:
   - **SHAP** → skoru hangi faktörlerin yükselttiği/düşürdüğü
   - **Aksiyon Reçetesi** → onay için 3 alternatif değişiklik senaryosu
   - **AI Açıklama** → tüm bulguların doğal dilde özeti
   - **CSV Toplu Analiz** → birden çok başvuruyu tek seferde skorlama
   - **Model Bilgisi** → ROC eğrisi, confusion matrix, özellik önemi

## Tasarım Kararları

- **F1-max threshold, 0.5 yerine.** Veri dengesiz (%70/%30) olduğundan varsayılan
  0.5 eşiği yüksek riskli başvuruları kaçırıyordu; eşik, CV üzerinde F1'i
  maksimize edecek şekilde otomatik hesaplanıp modelle birlikte kaydediliyor.
- **`dice-ml` yerine özel arama motoru.** Üretim ortamında ek bir ağır bağımlılık
  (ve onun kendi model-uyumluluk kısıtları) yerine, mevcut XGBoost modelini
  doğrudan sorgulayan, değiştirilemez alanları (yaş, medeni durum vb.) dışlayan
  hafif bir aday-üret/yeniden-skorla motoru tercih edildi.
- **LLM katmanı opsiyonel ve yerel.** Kredi verisi hassas olduğundan bulut
  tabanlı bir LLM API'sine bağımlılık yerine Ollama ile tamamen yerel çalışan,
  kurulu değilse sessizce şablon açıklamaya düşen bir tasarım seçildi.

## Bilinen Sınırlamalar

- Veri seti UCI German Credit + sentetik KOBİ profilleriyle genişletilmiştir;
  gerçek kredi kararları için **doğrulanmış üretim verisiyle yeniden eğitim gerekir**.
- Bu proje bir **karar destek simülatörüdür**, otomatik kredi onay/ret sistemi değildir.
- Yüksek riskli sınıfta recall (0.62) precision'a (0.73) göre daha düşük;
  eşik ayarı iş ihtiyacına göre `src/model/optimize_threshold.py` üzerinden değiştirilebilir.

## Yol Haritası

- [ ] Gerçek/anonimleştirilmiş kredi verisiyle model doğrulama
- [ ] Aksiyon reçetesi motoruna maliyet-ağırlıklı öneri sıralaması
- [ ] Çoklu dil desteği (İngilizce arayüz)
- [ ] REST API katmanı (Streamlit dışında entegrasyon için)

## Katkıda Bulunma

Katkılar memnuniyetle karşılanır. Lütfen bir issue açarak değişikliği tartışın,
ardından bir pull request gönderin. Kod stiliyle ilgili herhangi bir zorunluluk
yoktur; yalnızca yeni bağımlılıkların `requirements.txt`'e eklenmesi ve
`src/` altındaki modül sınırlarının (data / model / xai / ui) korunması istenir.

## Lisans

MIT — ayrıntılar için `LICENSE` dosyasına bakın (eklenmediyse projeye
uygun bir lisans dosyası eklemeniz önerilir).

---

<div align="center">

*YZTA Bootcamp 2026 kapsamında geliştirilmiştir.*

</div>
