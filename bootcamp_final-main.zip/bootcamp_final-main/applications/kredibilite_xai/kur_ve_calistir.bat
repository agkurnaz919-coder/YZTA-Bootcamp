@echo off
echo Kredibilite XAI - Kurulum ve Calistirma
echo ========================================
echo.

echo [1/5] Sanal ortam olusturuluyor...
if exist venv (
    echo    Eski venv bulundu, temizleniyor...
    rmdir /s /q venv
)
python -m venv venv

echo [2/5] Sanal ortam aktif ediliyor...
call venv\Scripts\activate

echo [3/5] Paketler kuruluyor...
pip install -r requirements.txt --quiet
pip install ollama --quiet

echo [4/5] Veri uretiliyor ve model egitiliyor...
python src/data/generate_data.py
python src/model/train.py
python src/model/optimize_threshold.py

echo [5/5] Uygulama baslatiliyor...
streamlit run src/ui/app.py
