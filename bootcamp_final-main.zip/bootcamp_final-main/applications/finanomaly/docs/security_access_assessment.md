# Kimlik, Yetki, Gizlilik ve Audit Değerlendirmesi

## Sprint 3 kararı

FinAnomaly yerel bootcamp demosunda seçilebilir demo rolleriyle çalışır.
Üretimde kimlik doğrulama zorunludur. OIDC ayarları verildiğinde dashboard,
Streamlit’in doğruladığı `st.user` claims bilgisini uygulama rollerine eşler;
oturumsuz kullanıcıyı skorlama ekranına almaz.

## Rol matrisi

| Rol | Yetki |
|---|---|
| Görüntüleyici | Özet ve maskelenmiş risk panosu |
| Denetçi | PII ve işlem detayı, manuel etiket |
| Denetim yöneticisi | Denetçi yetkileri, rapor export, model kalite özeti |
| Model yöneticisi | Maskeli dashboard, model eğitim/kalite yetkisi |
| Sistem yöneticisi | Entegrasyon yönetimi; PII, etiket ve export yetkisi yok |

`src/security/auth.py` içindeki allowlist dışındaki OIDC rolleri hiçbir yetki
üretmez. Sistem yöneticisinin finansal etiketi değiştirememesi görevlerin
ayrılığını korur.

## Kimlik doğrulama sözleşmesi

Gerekli ortam alanları:

- `FINANOMALY_OIDC_ISSUER`
- `FINANOMALY_OIDC_CLIENT_ID`
- `FINANOMALY_OIDC_AUTHORIZATION_ENDPOINT`
- `FINANOMALY_OIDC_ROLE_CLAIM` (varsayılan `roles`)

ID token imza, issuer, audience, nonce ve süre doğrulaması Streamlit auth
katmanında veya güvenilen OIDC-aware proxy’de yapılmalıdır. Uygulama içindeki
`user_from_oidc_claims` yalnızca doğrulanmış claims tüketir; token
doğrulayıcısının yerine geçmez.

## PII maskeleme

`calisan` ve `tedarikci`, kurum sırrıyla HMAC-SHA256 tabanlı kararlı takma ada
dönüştürülür. Böylece aynı aktör dashboard içinde aynı kodla görünür fakat
ham kimlik açığa çıkmaz. Serbest metin `aciklama` tamamen maskelenir.

Üretimde `FINANOMALY_MASKING_SECRET` secret manager’dan sağlanmalı ve veri
saklama politikasıyla rotasyonu yönetilmelidir. Yerel varsayılan anahtar
yalnızca demo içindir.

## Audit mimarisi

Etiket değişiklikleri ve rapor export olayları:

1. benzersiz olay ID’si ve UTC zaman alır,
2. önceki olay hash’ini içerir,
3. kanonik içeriğin SHA-256 hash’iyle kapanır,
4. fsync ile append-only JSONL sink’e yazılır,
5. endpoint ayarlıysa merkezi collector’a idempotency anahtarıyla iletilir.

`verify_audit_log` satır değişikliği, ekleme sırası bozulması ve geçersiz JSON
durumunda hata verir.

Yerel hash zinciri **tam bir WORM sistemi değildir**: değişikliği tespit eder,
ancak ayrıcalıklı dosya silinmesini engelleyemez. Üretimde
`FINANOMALY_AUDIT_ENDPOINT` kurumun merkezi append-only/WORM deposuna
bağlanmalı; retention, erişim, şifreleme ve SIEM alarm politikaları orada
uygulanmalıdır.

## Kalan üretim kontrolleri

- Kısa ömürlü, yetkiye bağlı export bağlantıları
- Depolama ve aktarım şifreleme anahtarlarının kurum KMS’inde yönetimi
- OIDC logout/revocation ve acil erişim prosedürü
- Model yayınlama için dört göz onayı
- Audit collector kesintisinde fail-closed/fail-open kararının kurumla
  netleştirilmesi
- Düzenli erişim gözden geçirme ve veri silme talepleri
