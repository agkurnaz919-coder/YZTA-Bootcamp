# Sprint 2 Test Raporu

Otomatik kabul paketi aşağıdaki alanları kapsar:

- Autoencoder yeniden oluşturma skoru ve hibrit risk skoru
- Isolation Forest / autoencoder / hibrit PR-AUC karşılaştırması
- En az beş bağımsız finansal risk kuralı
- Yüksek riskli her işlem için açıklama ve işlem detay objesi
- Departman/kategori dinamik eşikleri
- Kayıtlı model paketiyle yeniden skorlama
- Manuel etiket geri bildirimi ve audit trail satırları
- CSV, XLSX ve geçerli PDF rapor çıktıları
- Streamlit dashboard'un gerçek uygulama bağlamında hatasız render edilmesi
- Yanlış pozitif ve top-20 hit rate metrikleri
- Sprint 1'in üç, Sprint 2'nin en az beş demo senaryosu

Doğrulama komutu:

```bash
python -m pytest -q
```

CLI kilometre taşları:

```bash
python src/model/autoencoder.py
python src/rules/rules_engine.py
python src/model/train_iforest.py
```
