# FinAnomaly Kullanım Kılavuzu

## 1. Uygulamayı açma

```bash
source .venv/bin/activate
streamlit run src/ui/app.py
```

Tarayıcıda gösterilen yerel adrese gidin. Final demo için varsayılan erişim
profili denetim ve model yöneticisi yetkilerini birleştirir. Tek bir rolün
görünümünü denemek için sidebar’dan **Erişim profili** seçin.

## 2. Veri yükleme

Sidebar’daki **CSV veya XLSX yükle** alanından dosyayı seçin. Dosyada şu
kolonlar bulunmalıdır:

`calisan, departman, tarih, tutar, kategori, tedarikci, odeme_tipi, aciklama`

`manuel_etiket` ve `anomali_nedeni` opsiyoneldir. İngilizce yaygın karşılıklar
(`employee`, `department`, `date`, `amount`, `vendor` gibi) otomatik eşlenir.

### Hata mesajları

| Mesaj | Anlamı | Aksiyon |
|---|---|---|
| Dosya boş | Başlık veya işlem yok | En az bir gider satırı ekleyin |
| Desteklenmeyen dosya | Uzantı CSV/XLSX değil | CSV veya XLSX dışa aktarın |
| Dosya okunamadı | CSV ayracı/encoding veya XLSX arşivi bozuk | UTF-8 CSV ya da geçerli XLSX üretin |
| Eksik zorunlu kolonlar | Şema tamamlanmamış | Mesajdaki kolonları ekleyin |
| Veri kalite uyarısı | Bazı tutar/tarih/metinler normalize edildi | Kaynak kayıtları kontrol edin |

## 3. Model çalışma biçimi

**Kayıtlı modeli kullan** açıksa `models/hybrid_anomaly_model.pkl` ile yeniden
eğitim yapılmadan skor üretilir. Paket bulunmazsa veya seçenek kapalıysa
oturum verisi üzerinde yeni model eğitilir.

Ekranın üstünde uygulama, model ve kural sürümüyle son skor süresi görünür.
Detaylı profil **Model kalitesi** sekmesindedir.

## 4. Risk panosu

- Ana kartlar toplam işlem/tutarı, yüksek risk adedini ve incelenecek tutarı
  gösterir.
- **Risk seviyesi** filtresi inceleme kuyruğunu daraltır.
- Kuyruk risk skoruna göre sıralıdır.
- Departman grafiği risk dağılımını; kategori grafiği ortalama risk ve toplam
  tutarı; çalışan tablosu risk yoğunluğunu gösterir.

Görüntüleyici ve PII yetkisi olmayan roller çalışan/tedarikçi için kararlı
takma ad, açıklama için maske görür.

## 5. İşlem inceleme ve aksiyon

**İşlem detayı** sekmesinde bir işlem seçin:

1. Hibrit, Isolation Forest, autoencoder ve kural skorlarını karşılaştırın.
2. Risk faktörlerini ve kural rozetlerini okuyun.
3. Kaynak işlem bilgilerini doğrulayın.
4. Denetçi rolüyle **Geri bildirim & rapor** sekmesinde manuel etiketi
   güncelleyin.
5. **Geri bildirimi güvenli audit log’a kaydet** düğmesine basın.

Değişiklik yoksa olay yazılmaz. Değişiklik varsa önceki/yeni etiket,
kullanıcı, UTC zaman, işlem ID ve skor audit kaydına girer.

## 6. Raporlama

Denetim yöneticisi orta/yüksek riskli işlemleri CSV, XLSX veya PDF olarak
indirebilir. Her indirme `report.exported` audit olayı üretir. CSV Excel
uyumlu UTF-8 BOM taşır; XLSX ayrı özet sayfası içerir.

## 7. Roller

| Rol | Dashboard | PII/detay | Etiket | Export | Model kalite | Entegrasyon |
|---|---:|---:|---:|---:|---:|---:|
| Görüntüleyici | ✓ | — | — | — | — | — |
| Denetçi | ✓ | ✓ | ✓ | — | — | — |
| Denetim yöneticisi | ✓ | ✓ | ✓ | ✓ | ✓ | — |
| Model yöneticisi | ✓ | — | — | — | ✓ | — |
| Sistem yöneticisi | ✓ | — | — | — | — | ✓ |

Bu ayrım sistem yöneticisinin finansal kararları değiştirmesini engeller.

## 8. Demo sırası

Final birleşik dosyasını yükleyin:

`data/raw/finanomaly_final_demo.csv`

Ardından [final demo konuşma metnindeki](final_demo_script.md) üç işlemi
sırayla anlatın. Toplam hedef süre 5 dakikadır.

## 9. Sorun giderme

- Kayıtlı model uyumsuzsa `python src/model/train_iforest.py` ile v3 paketi
  yeniden üretin.
- Audit bütünlüğü için `verify_audit_trail()` çalıştırın. Hata varsa dosyaya
  yazmayı durdurun ve merkezi kayıtla karşılaştırın.
- Model metriği için `manuel_etiket` kolonunda hem `0` hem `1` bulunmalıdır.
- Üretimde varsayılan maskeleme anahtarını kullanmayın; secret manager’dan
  güçlü `FINANOMALY_MASKING_SECRET` sağlayın.
