# Test Notlari

Uctan uca kontrol komutlari:

```bash
python src/data/generate_sample_data.py
python src/data/preprocess.py
python src/model/autoencoder.py
python src/rules/rules_engine.py
python src/model/train_iforest.py
python -m pytest -q
streamlit run src/ui/app.py
```

Beklenen sonuc:

- Ornek veri `data/raw/expenses.csv` altinda olusur
- Temizlenmis veri `data/processed/expenses_processed.csv` altinda olusur
- Risk skorlu cikti `data/processed/expenses_scored.csv` altinda olusur
- Model paketi `models/isolation_forest.pkl` altinda olusur
- Hibrit model paketi `models/hybrid_anomaly_model.pkl` altinda olusur
- Model karsilastirmasi `docs/model_comparison.md` altinda olusur
- Testler Sprint 1'in 3 ve Sprint 2'nin en az 5 demo senaryosunu calistirir
- CSV, XLSX ve PDF raporlari dogrulanir
- Kayitli modelle yeniden skorlama ve audit trail akisi dogrulanir
