# Sprint 2 Backlog

- [x] Model eğitim/servis ayrımı ve kayıtlı model ile yeniden skorlama
- [x] Departman ve kategori bazlı dinamik eşikler
- [x] Kullanıcı geri bildirimiyle manuel etiket güncelleme
- [x] CSV, XLSX ve PDF raporları ile audit trail çıktısı
- [x] Kimlik doğrulama ve rol bazlı erişim değerlendirmesi
- [x] PR-AUC, top-20 hit rate ve yanlış pozitif analizi

Uygulama karşılıkları `src/model/service.py`, `src/model/scoring.py`,
`src/feedback.py`, `src/reporting/` ve `docs/security_access_assessment.md`
altındadır.
