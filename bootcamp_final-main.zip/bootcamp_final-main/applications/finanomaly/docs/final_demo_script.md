# Final Demo Akışı

Hedef süre: **5 dakika**. Dosya:
`data/raw/finanomaly_final_demo.csv`.

## Hazırlık

1. `python src/data/generate_sample_data.py`
2. `python src/model/train_iforest.py --input data/raw/finanomaly_final_demo.csv`
3. `streamlit run src/ui/app.py`
4. Erişim profilini **Final demo** ve risk filtresini **yüksek + orta** bırakın.
5. Risk panosu, işlem detayı, rapor ve model kalitesi sekmelerini bir kez açın.

## Açılış · 0:00–0:40

“KOBİ finans ekipleri binlerce gider satırında hangi işlemi önce inceleyeceğini
bilmekte zorlanıyor. FinAnomaly denetçinin yerine karar vermiyor; modeli ve
finans kurallarını birleştirerek inceleme kuyruğunu açıklanabilir biçimde
önceliklendiriyor.”

Üst metrikleri gösterin. Model/kural sürümü ve skorlama süresine işaret edin.

## Vaka 1 · Satışta tekrar eden tedarikçi · 0:40–1:45

**Problem:** Satış departmanında GrowthPartner’a üç gün içinde aynı tutarda
üç danışmanlık ödemesi var. Satırlar tek tek makul görünebilir.

**Bulgu:** Kuyrukta `sales_duplicate_vendor` etiketli işlemi seçin. “Aynı
tutar tekrarı” ve “Tedarikçiye kısa sürede çoklu ödeme” rozetlerini; model,
autoencoder ve kural katkılarını gösterin.

**Aksiyon:** Denetçi sözleşme/fatura numaralarını eşleştirir, olası mükerrer
ödemeyi bloke eder ve sonucu manuel etiket olarak audit log’a kaydeder.

Geçiş cümlesi: “Buradaki değer yalnızca yüksek skor değil; denetçiye hangi
kanıtı araması gerektiğini de söylüyor.”

## Vaka 2 · Olağandışı temsil gideri · 1:45–2:50

**Problem:** Satışın normal gider davranışına kıyasla ₺24.500 tutarında tek
seferlik temsil organizasyonu var.

**Bulgu:** Eventique işlemini açın. Departman davranışından sapmayı, yüksek
hibrit skoru ve açıklama metnini gösterin. Kategori balonunda risk yoğunluğuna
işaret edin.

**Aksiyon:** Yönetici onayı, katılımcı listesi ve harcama politikası limiti
kontrol edilir; geçerliyse yanlış pozitif etiketiyle geri beslenir.

## Vaka 3 · Hafta sonu/gece ödeme · 2:50–3:55

**Problem:** Pazar gecesi nakit olarak girilmiş ₺16.800 konaklama ödemesi var.

**Bulgu:** LuxuryStay işlemini açın. Hafta sonu/mesai dışı, nakit ve yüksek
tutar sinyallerinin birlikte riski yükselttiğini gösterin.

**Aksiyon:** Seyahat emri ve fiş doğrulanır, ödeme sahibinden teyit alınır,
gerekirse vaka incelemeye eskale edilir.

## Güven ve ürünleşme · 3:55–4:35

Erişim profilini **Görüntüleyici** yapıp isim, tedarikçi ve açıklamanın
maskelendiğini gösterin. Sonra:

- rollerin görev ayrılığı sağladığını,
- etiket ve rapor olaylarının hash-zincirli kayda girdiğini,
- model ve kural sürümünün her çıktıda izlenebildiğini,
- üretimde olayların merkezi WORM audit collector’a gönderilebildiğini

özetleyin.

## Kapanış · 4:35–5:00

“FinAnomaly’nin farkı yalnızca anomali bulması değil; KOBİ’nin mevcut gider
dosyasıyla hızla çalışması, her bulguyu açıklaması ve denetçi aksiyonunu
izlenebilir kılması. Bir sonraki adım gerçek kurum verisiyle kalibrasyon ve
pilot denetçi geri bildirimidir.”

## Prova kontrol listesi

- [ ] Uygulama temiz oturumda açıldı.
- [ ] Üç senaryodaki tüm etiketli işlemler anomali olarak işaretlendi.
- [ ] Her yüksek riskli işlemde açıklama var.
- [ ] Görüntüleyici profilinde PII maskeli.
- [ ] Etiket değişimi sonrası audit bütünlüğü doğrulandı.
- [ ] CSV, XLSX ve PDF indirme düğmeleri çalıştı.
- [ ] Sunum 5 dakikanın altında tamamlandı.
