# Sprint 3 Final Test Raporu

Tarih: 23 Temmuz 2026  
Ortam: Python 3.13, Streamlit 1.58  
Komut: `python -m pytest -q`

## Sonuç

**23 test ve 8 senaryo subtesti geçti.**

| Alan | Doğrulama | Sonuç |
|---|---|---|
| Regresyon | Sprint 1/2 pipeline, kural, rapor ve UI testleri | Geçti |
| Dosya güvenliği | Boş dosya ve eksik kolon hatası | Geçti |
| Sürümleme | Bundle v3, model/kural satırları | Geçti |
| Performans | Eğitim ve runtime profili | Geçti |
| RBAC | Beş rol ve görev ayrılığı | Geçti |
| PII | Kararlı pseudonym, kaynak veriyi değiştirmeme | Geçti |
| Audit | İki olaylı zincir ve değişiklik tespiti | Geçti |
| Final vakalar | Tekrar, temsil sapması, hafta sonu ödeme | Geçti |
| Dashboard | Streamlit AppTest smoke testi | Geçti |

## Final demo veri sonucu

`data/raw/finanomaly_final_demo.csv`:

- 77 toplam işlem
- 5 etiketli hedef anomali
- 5 true positive, 0 false negative
- 5 false positive, 67 true negative
- Precision: `0.5000`
- Recall: `1.0000`
- Accuracy: `0.9351`
- False positive rate: `0.0694`
- PR-AUC: `1.0000`
- Hybrid PR-AUC: `1.0000`

Bu metrikler sabit seed ile üretilmiş sentetik kabul verisine aittir.
Özellikle precision, üretim threshold’u seçmek için yeterli değildir.

## Kabul kriteri izlenebilirliği

| Sprint 3 kriteri | Kanıt |
|---|---|
| Uygulama local’de açılıyor | `tests/test_ui.py` |
| Güvenli dosya yükleme | `tests/test_sprint3.py` input testleri |
| Tutarlı risk ve sürüm çıktısı | Bundle/runtime testleri |
| Yüksek risk açıklaması | Sprint 2 ve final vaka testleri |
| Metrik, filtre, grafik, detay | Streamlit smoke + Sprint 2 testleri |
| Rapor dışa aktarma | CSV/XLSX/PDF imza testleri |
| Üç demo senaryosu | Final vaka regression testi |
| Dokümantasyon | README, kılavuz, mimari, deck, demo metni |

## Açık üretim riskleri

- OIDC sağlayıcı ve merkezi audit endpoint’i yerel CI’da gerçek dış servisle
  entegre test edilmedi.
- Tarayıcı tabanlı klavye/screen-reader testi manuel prova maddesidir.
- Model kalite sonucu gerçek kurum dağılımıyla yeniden ölçülmelidir.
- Yerel hash log değişikliği tespit eder; ayrı depolama olmadan dosya
  silinmesini önleyemez.
