# Demo Senaryolari

## 1. Normal gider akisi

Dosya: `data/raw/scenario_normal.csv`

Beklenti: Supheli islem sayisi dusuk olur; dashboard kategori ve departman
toplamlarini gosterir.

## 2. Hafta sonu yuksek tutar

Dosya: `data/raw/scenario_weekend_spike.csv`

Beklenti: Hafta sonu yuksek konaklama gideri yuksek riskli islem olarak one cikar.

## 3. Tekrar eden tedarikci/tutar

Dosya: `data/raw/scenario_duplicate_vendor.csv`

Beklenti: Ayni tedarikci ve ayni tutardaki tekrar eden danismanlik islemleri
orta veya yuksek risk grubunda listelenir.

## 4. Departman ortalamasinin ustunde gider

Dosya: `data/raw/scenario_department_outlier.csv`

Beklenti: Finans departmaninin tipik harcamalarindan sapan elektronik alimi
departman ust limit kurali ve model skorlarinda one cikar.

## 5. Kisa surede tedarikci odeme yogunlugu

Dosya: `data/raw/scenario_vendor_burst.csv`

Beklenti: Ayni tedarikciye yedi gunluk pencere icinde yapilan coklu odemeler
ayri bir kural ihlali olarak gosterilir.

## 6. Supheli veya eksik aciklama

Dosya: `data/raw/scenario_suspicious_description.csv`

Beklenti: Eksik aciklamali nakit islem hem aciklama hem nakit odeme
kurallarini tetikler.
