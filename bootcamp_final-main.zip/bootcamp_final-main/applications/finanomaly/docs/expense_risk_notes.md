# Muhasebe ve Gider Risk Notlari

Sprint 1 icin izlenen temel risk davranislari:

- Kategori ortalamasindan belirgin sapan yuksek tutarli islemler
- Departman normuna gore aykiri harcama paterni
- Hafta sonu veya is disi zamana denk gelen yuksek tutarli giderler
- Ayni tedarikciye ayni tutar ile tekrar eden islemler
- Nakit odeme ve eksik aciklama kombinasyonu
- Yeni veya nadir tedarikcilerde yuksek tekil harcamalar

Bu sprintte model skoru Isolation Forest ile uretilir. Kural katmani skoru
aciklanabilirlik icin modele ek sinyal olarak kullanilir.
