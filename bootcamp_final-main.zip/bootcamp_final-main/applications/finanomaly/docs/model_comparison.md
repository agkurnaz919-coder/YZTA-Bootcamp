# Model Karşılaştırma Raporu

Isolation Forest, autoencoder ve hibrit skor aynı işaretli veri üzerinde karşılaştırılmıştır.

| Metrik | Değer |
|---|---:|
| Isolation Forest ortalama skoru | 0.2856 |
| Autoencoder ortalama skoru | 0.1155 |
| Skor korelasyonu | 0.8396 |
| Ortalama mutlak skor farkı | 0.1708 |
| Isolation Forest PR-AUC | 0.9617 |
| Autoencoder PR-AUC | 1.0000 |
| Hibrit PR-AUC | 1.0000 |

Hibrit skor; Isolation Forest, autoencoder yeniden oluşturma hatası ve kural skorunu birlikte kullanır.
