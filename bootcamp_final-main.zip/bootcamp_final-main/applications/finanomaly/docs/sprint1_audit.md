# Sprint 1 Tamamlanma Denetimi

Sprint 1 planındaki altyapı, veri hazırlama, feature engineering, Isolation
Forest, CSV çıktısı, Streamlit MVP ve üç demo veri seti repoda mevcuttu.

Denetimde iki eksik bulundu ve giderildi:

1. Üç demo senaryosunun uçtan uca davranışını ayrı ayrı doğrulayan otomatik
   testler yoktu. `tests/test_sprint1_scenarios.py` eklendi.
2. `dayfirst=True` ile karışık tarih ayrıştırması ISO tarihleri yanlış
   yorumlayabiliyordu (`2026-06-14` → `2026-08-05`). Karışık ISO ve yerel
   formatları güvenli ayrıştıran davranış eklendi.

Sprint 1 kabul kriterleri artık otomatik senaryo testleriyle korunmaktadır.
