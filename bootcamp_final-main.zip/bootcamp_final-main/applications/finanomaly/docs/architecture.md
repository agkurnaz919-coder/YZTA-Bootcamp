# FinAnomaly Teknik Mimarisi

## Sistem görünümü

```mermaid
flowchart LR
    U[Denetçi / Yönetici] --> IDP[Kurumsal OIDC sağlayıcı]
    IDP --> AUTH[Doğrulanmış claims + rol eşleme]
    AUTH --> UI[Streamlit çalışma alanı]
    CSV[CSV / XLSX] --> VALID[Dosya doğrulama + kalite özeti]
    VALID --> PREP[Normalize etme + feature engineering]
    PREP --> IF[Isolation Forest]
    PREP --> AE[Autoencoder]
    PREP --> RULES[8 finans kuralı]
    IF --> SCORE[Hibrit skor + dinamik eşik]
    AE --> SCORE
    RULES --> SCORE
    SCORE --> EXPLAIN[Neden + risk faktörleri]
    EXPLAIN --> UI
    UI --> MASK[Rol bazlı PII maskeleme]
    MASK --> REPORT[CSV / XLSX / PDF]
    UI --> AUDIT[Hash-zincirli audit sink]
    AUDIT --> CENTRAL[Merkezi append-only / WORM collector]
    BUNDLE[(Sürümlü model paketi)] --> SCORE
    SCORE --> BUNDLE
```

## Bileşen sorumlulukları

| Katman | Sorumluluk | Ana modül |
|---|---|---|
| Girdi | Dosya türü, boş/bozuk dosya, kolon ve kalite kontrolü | `src/data/preprocess.py` |
| Özellik | Sayısal ve kategorik feature matrisi | `src/model/features.py` |
| Model | Isolation Forest + autoencoder eğitim/skorlama | `src/model/` |
| Kurallar | Sekiz bağımsız, isimlendirilmiş finans kontrolü | `src/rules/rules_engine.py` |
| Açıklama | Risk faktörü ve işlem detay objesi | `src/reporting/explanations.py` |
| Yetki | OIDC claim eşleme ve rol-yetki matrisi | `src/security/auth.py` |
| Gizlilik | HMAC tabanlı kararlı takma ad ve açıklama maskeleme | `src/security/privacy.py` |
| Audit | Yerel hash zinciri ve merkezi HTTP sink | `src/security/audit.py` |
| Sunum | Dashboard, detay, geri bildirim ve rapor | `src/ui/app.py` |

## Skorlama akışı

```mermaid
sequenceDiagram
    participant User as Kullanıcı
    participant UI as Dashboard
    participant V as Validator
    participant M as Hibrit model
    participant R as Kural motoru
    participant A as Audit sink

    User->>UI: CSV/XLSX yükler
    UI->>V: Dosyayı ve şemayı doğrula
    alt Geçersiz dosya
        V-->>UI: Kodlu ve kullanıcı odaklı hata
        UI-->>User: Düzeltme önerisi
    else Geçerli dosya
        V->>M: Temizlenmiş özellikler
        V->>R: Denetlenebilir işlem alanları
        M-->>UI: IF + AE skorları
        R-->>UI: Kural skorları ve nedenler
        UI-->>User: Öncelikli kuyruk + açıklama
        User->>UI: Etiketi değiştirir / rapor indirir
        UI->>A: Kullanıcı ve olay bağlamı
    end
```

## Güven sınırları

- Kimlik sağlayıcıdan gelen token/claims uygulama koduna ulaşmadan önce
  issuer, audience, imza, süre ve nonce açısından doğrulanır.
- Uygulama rolleri yalnızca tanımlı allowlist değerlerinden oluşur; bilinmeyen
  roller yetki üretmez.
- Model skorlama ham veriyle yapılır, fakat gösterim ve export yetkiden sonra
  açılır. Görüntüleyici doğrudan kimlikleri göremez.
- Her audit kaydı önceki olay hash’ini içerir. Değişiklik zinciri bozar ve
  `verify_audit_log` hatasıyla tespit edilir.
- Yerel hash zinciri silinmeyi tek başına önlemez. Üretimde merkezi collector
  WORM/retention politikasıyla asıl kayıt sistemi olmalıdır.

## Model paketi sözleşmesi

Bundle sürüm 3 şu işletim alanlarını taşır:

- `model_version`, `ruleset_version`, `app_version`
- UTC oluşturma zamanı
- özellik kolonları, model parametreleri ve hibrit ağırlıklar
- global/grup risk eşikleri
- eğitim satırı, özellik sayısı, eğitim süresi ve referans throughput

Eski Sprint 2 paketleri okunabilir; sürüm alanları arayüzde `legacy` olarak
gösterilir.
