# FinAnomaly Final Pitch Deck

Bu belge 10 slaytlık final sunumunun ekrana verilecek kısa içeriğini ve
konuşmacı notlarını içerir. Hedef sunum süresi: **7 dakika + demo**.

---

## 1 · FinAnomaly

**Açıklanabilir finansal anomali tespiti**  
KOBİ gider denetimi için hızlı, izlenebilir inceleme kuyruğu

Konuşmacı notu: Ürünü “otomatik suçlama” değil, denetçiye karar desteği olarak
konumlandırın.

---

## 2 · Problem

- Gider satırları büyürken manuel örnekleme kritik işlemleri kaçırıyor.
- Salt eşik kuralları bağlamı, salt ML çıktıları açıklanabilirliği kaçırıyor.
- KOBİ’lerin uzun entegrasyon projelerine ayıracak zamanı ve bütçesi sınırlı.

Konuşmacı notu: Temel ihtiyaç “hangi 20 satıra önce bakmalıyım ve neden?”

---

## 3 · Çözüm

`CSV/XLSX → doğrulama → hibrit risk → açıklama → denetçi aksiyonu`

- Mevcut gider dosyasıyla hızlı başlangıç
- Isolation Forest + autoencoder + sekiz finans kuralı
- Her işlemde neden, risk faktörleri ve model/kural sürümü
- Denetçi geri bildirimi ve çok formatlı rapor

---

## 4 · Neden farklı?

| Alternatif | Zayıf nokta | FinAnomaly |
|---|---|---|
| Manuel örnekleme | Ölçeklenmez | Risk bazlı öncelik |
| Sabit kural seti | Yeni davranışı kaçırır | ML + kural hibriti |
| Kara kutu ML | Denetlenmesi zor | Satır bazlı açıklama |
| Kurumsal ağır ürün | Uzun kurulum | KOBİ odaklı dosya akışı |

---

## 5 · Ürün akışı

1. Denetçi CSV/XLSX yükler.
2. Sistem dosyayı ve veri kalitesini doğrular.
3. Hibrit model risk kuyruğu üretir.
4. Denetçi işlem nedenini ve kaynak bilgiyi inceler.
5. Etiket değişimi ve rapor olayı audit log’a yazılır.

Görsel önerisi: Risk panosu ekran görüntüsü ve bir işlem detay kartı.

---

## 6 · Üç kanıt vakası

- Satışta tekrar eden tedarikçi: aynı tutar + kısa süre yoğunluğu
- Normal kategoriye göre aşırı temsil gideri: davranış sapması
- Hafta sonu/gece ödeme: zaman + nakit + tutar sinyalleri

Her vaka: **problem → açıklanabilir bulgu → denetçi aksiyonu**

---

## 7 · Teknik mimari

- Modüler Python veri/model/kural/raporlama katmanları
- Streamlit + Plotly denetçi çalışma alanı
- Sürümlü ve geriye uyumlu model paketi
- OIDC rol eşleme, PII maskeleme
- Hash-zincirli yerel log + merkezi audit sink

Görsel: [teknik mimari diyagramı](architecture.md).

---

## 8 · Final regresyon sonucu

77 satırlık sentetik final demo setinde:

- 5/5 hedef anomali yakalandı
- Recall: `1.00`
- PR-AUC: `1.00`
- Yanlış pozitif oranı: `0.0694`
- 23 otomatik test + 8 senaryo subtesti geçti

Dipnot: Bunlar sentetik demo sonuçlarıdır; gerçek üretim performansı iddiası
değildir.

---

## 9 · Güven, sınırlılıklar ve yol haritası

**Bugün:** rol kontrolleri, PII maskeleme, audit zinciri, sürüm profili  
**Sırada:** gerçek veri pilotu, OIDC token doğrulama katmanı, WORM saklama,
drift/kalibrasyon izleme, denetçi geri bildirim döngüsü

Ana risk: küçük sentetik veri üzerinde kalibrasyon. Azaltım: gölgede çalışma,
insan onayı ve düzenli threshold review.

---

## 10 · Teklif

**4 haftalık kontrollü pilot**

- Bir gider kaynağı
- Sınırlı denetçi grubu
- Gölge modunda öneri üretimi
- Haftalık yanlış pozitif ve açıklama kalitesi değerlendirmesi

Başarı ölçütü: denetçinin inceleme süresini azaltırken kritik bulgu recall’ını
korumak.
