# Sprint 2 Demo and Process Feedback

## Demo screenshots

### 1. Risk dashboard

![Sprint 2 risk dashboard](screenshots/sprint2/01-risk-dashboard.png)

The dashboard turns the hybrid model output into a clear review queue, with
high-level metrics, rule violations, department summaries and category risk
visuals in one place.

### 2. Explainable transaction detail

![Sprint 2 transaction detail](screenshots/sprint2/02-transaction-detail.png)

The transaction view makes the score auditable by separating Isolation
Forest, autoencoder and rule contributions, then presenting the main risk
factors in plain language.

### 3. Auditor feedback and reporting

![Sprint 2 feedback and reporting](screenshots/sprint2/03-feedback-reporting.png)

The final workflow lets an auditor confirm labels, record changes in the
audit trail and export suspicious transactions as CSV, XLSX or PDF.

## Short process feedback

Sprint 2 went well because implementation followed the acceptance criteria
module by module: model development, rules, explanations, reporting and UI
were integrated behind one tested scoring pipeline. Auditing Sprint 1 first
also exposed and fixed an ISO-date parsing issue before it could affect the
new rules.

The main challenge was calibration with a small synthetic labeled dataset.
The current recall is strong, but the false-positive analysis shows that
thresholds will benefit from real auditor feedback and more representative
data. Automated scenario tests and the final visual walkthrough were useful:
the screenshot review itself caught and corrected a percentage-formatting
issue. Overall, Sprint 2 delivered a complete auditor-facing demo and a
solid base for Sprint 3 product hardening.
