"""FinAnomaly expense-audit application."""
