# FinAnomaly · Sprint 3

FinAnomaly, CSV/XLSX muhasebe ve gider raporlarındaki şüpheli işlemleri
Isolation Forest, neural autoencoder ve açıklanabilir finans kurallarıyla
önceliklendiren denetçi çalışma alanıdır.

## Sprint 3 teslimi

- Boş, bozuk, desteklenmeyen ve eksik kolonlu dosyalar için kullanıcı odaklı
  hata sözleşmesi ve veri kalite özeti
- Her skor satırında model/kural sürümü; model paketinde eğitim ve skorlama
  performans profili
- Erişilebilir, rol bazlı final dashboard; risk kuyruğu, detay, grafikler,
  geri bildirim ve CSV/XLSX/PDF raporları
- OIDC claim → uygulama rolü entegrasyon arayüzü ve en az ayrıcalık matrisi
- Görüntüleyici rolü için kararlı PII maskeleme
- Değişiklikleri fark edilebilir hash-zincirli yerel audit log ve merkezi
  audit collector entegrasyonu
- Üç final vaka verisi, problem → bulgu → aksiyon demo metni ve regresyon
  testleri
- Teknik mimari, kullanım kılavuzu, final pitch deck içeriği ve test raporu

## Hızlı başlangıç

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python src/data/generate_sample_data.py
python src/model/train_iforest.py
streamlit run src/ui/app.py
```

Uygulama varsayılan olarak yerel demo kimliğiyle açılır. Sidebar’daki
**Erişim profili** alanı farklı rollerin görebildiği ekranları denemek için
kullanılır.

Testler:

```bash
python -m pytest -q
```

## Veri şeması

Zorunlu kolonlar:

- `calisan`
- `departman`
- `tarih`
- `tutar`
- `kategori`
- `tedarikci`
- `odeme_tipi`
- `aciklama`

Opsiyonel değerlendirme kolonları:

- `manuel_etiket`: `1` anomali, `0` normal
- `anomali_nedeni`: sentetik etiketin veya denetçi kararının nedeni

Türkçe/İngilizce yaygın kolon adları otomatik eşlenir. Geçersiz tutar ve
tarih değerleri veri kalite uyarısında sayılır ve güvenli varsayılanlarla
normalize edilir. Zorunlu kolon eksikliği ise skorlama başlamadan durdurulur.

## Hibrit skor ve açıklama

Her işlem için:

1. Isolation Forest davranış aykırılığını,
2. autoencoder yeniden oluşturma hatasını,
3. sekiz finans kuralı denetlenebilir iş sinyallerini

üretir. Varsayılan ağırlıklar sırasıyla `%40`, `%35`, `%25`’tir. Manuel
etiket varsa yüksek risk eşiği F1 skoruna göre kalibre edilir; departman ve
kategori dağılımları eşiği dinamik olarak uyarlar. Yüksek riskli her satırda
`neden_supheli`, `risk_faktorleri`, `model_surumu` ve `kural_surumu` bulunur.

Kayıtlı paketle yeniden eğitim yapmadan skorlama:

```python
import pandas as pd
from src.model.service import score_dataframe_with_saved_model

raw = pd.read_csv("data/raw/finanomaly_final_demo.csv")
scored = score_dataframe_with_saved_model(raw)
print(scored.attrs["runtime_profile"])
```

## Güvenlik yapılandırması

OIDC arayüzü şu ortam değişkenlerini destekler:

```bash
export FINANOMALY_OIDC_ISSUER="https://id.example.com"
export FINANOMALY_OIDC_CLIENT_ID="finanomaly"
export FINANOMALY_OIDC_AUTHORIZATION_ENDPOINT="https://id.example.com/authorize"
export FINANOMALY_OIDC_ROLE_CLAIM="roles"
export FINANOMALY_MASKING_SECRET="<secret-manager-value>"
```

Üretimde ID token doğrulaması uygulamanın önündeki OIDC-aware proxy veya
Streamlit kimlik katmanında yapılmalı; yalnızca doğrulanmış claims
`user_from_oidc_claims` fonksiyonuna geçirilmelidir.

Merkezi audit collector’ı etkinleştirmek için:

```bash
export FINANOMALY_AUDIT_ENDPOINT="https://audit.example.com/v1/events"
export FINANOMALY_AUDIT_TOKEN="<secret-manager-value>"
```

Endpoint yoksa olaylar `data/processed/audit_trail.jsonl` dosyasına
hash-zincirli ve append-only biçimde yazılır. Yerel bütünlük kontrolü:

```python
from src.feedback import verify_audit_trail

print(verify_audit_trail())
```

## Final demo verileri

- `data/raw/finanomaly_final_demo.csv`: 77 satırlık birleşik final veri seti
- `data/raw/sprint3_sales_duplicate.csv`: satışta tekrar eden tedarikçi
- `data/raw/sprint3_representation_outlier.csv`: olağandışı temsil gideri
- `data/raw/sprint3_weekend_payment.csv`: hafta sonu/gece ödeme

## Dokümantasyon

- [Kullanım kılavuzu](docs/user_guide.md)
- [Teknik mimari](docs/architecture.md)
- [Demo akışı ve konuşma metni](docs/final_demo_script.md)
- [Final pitch deck](docs/final_pitch_deck.md)
- [Sprint 3 test raporu](docs/sprint3_test_report.md)
- [Güvenlik ve erişim modeli](docs/security_access_assessment.md)

## Sınırlılıklar

Final metrikleri sentetik ve küçük bir etiketli veri setine aittir; üretim
performansının kanıtı değildir. Üretimde gerçek denetçi geri bildirimiyle
kalibrasyon, kurum anahtar yönetimi, doğrulanmış OIDC oturumu, merkezi WORM
log saklama, veri saklama politikası ve model drift izlemesi zorunludur.
