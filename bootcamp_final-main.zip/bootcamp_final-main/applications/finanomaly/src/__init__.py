"""FinAnomaly Sprint 1 package."""
