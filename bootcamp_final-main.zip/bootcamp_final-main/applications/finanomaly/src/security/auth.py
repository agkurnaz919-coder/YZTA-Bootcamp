from __future__ import annotations

import os
import secrets
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Iterable, Mapping
from urllib.parse import urlencode


class Role(str, Enum):
    VIEWER = "goruntuleyici"
    AUDITOR = "denetci"
    AUDIT_MANAGER = "denetim_yoneticisi"
    MODEL_MANAGER = "model_yoneticisi"
    SYSTEM_ADMIN = "sistem_yoneticisi"


class Permission(str, Enum):
    VIEW_DASHBOARD = "dashboard:view"
    VIEW_TRANSACTION_DETAIL = "transaction:view"
    VIEW_PII = "pii:view"
    LABEL_TRANSACTION = "transaction:label"
    EXPORT_REPORT = "report:export"
    MANAGE_REVIEW_QUEUE = "review_queue:manage"
    VIEW_MODEL_METRICS = "model_metrics:view"
    TRAIN_MODEL = "model:train"
    MANAGE_INTEGRATIONS = "integrations:manage"


ROLE_PERMISSIONS: dict[Role, frozenset[Permission]] = {
    Role.VIEWER: frozenset({Permission.VIEW_DASHBOARD}),
    Role.AUDITOR: frozenset(
        {
            Permission.VIEW_DASHBOARD,
            Permission.VIEW_TRANSACTION_DETAIL,
            Permission.VIEW_PII,
            Permission.LABEL_TRANSACTION,
        }
    ),
    Role.AUDIT_MANAGER: frozenset(
        {
            Permission.VIEW_DASHBOARD,
            Permission.VIEW_TRANSACTION_DETAIL,
            Permission.VIEW_PII,
            Permission.LABEL_TRANSACTION,
            Permission.EXPORT_REPORT,
            Permission.MANAGE_REVIEW_QUEUE,
            Permission.VIEW_MODEL_METRICS,
        }
    ),
    Role.MODEL_MANAGER: frozenset(
        {
            Permission.VIEW_DASHBOARD,
            Permission.VIEW_MODEL_METRICS,
            Permission.TRAIN_MODEL,
        }
    ),
    Role.SYSTEM_ADMIN: frozenset(
        {
            Permission.VIEW_DASHBOARD,
            Permission.MANAGE_INTEGRATIONS,
        }
    ),
}

ROLE_LABELS = {
    Role.VIEWER: "Görüntüleyici",
    Role.AUDITOR: "Denetçi",
    Role.AUDIT_MANAGER: "Denetim yöneticisi",
    Role.MODEL_MANAGER: "Model yöneticisi",
    Role.SYSTEM_ADMIN: "Sistem yöneticisi",
}

ROLE_ALIASES = {
    "viewer": Role.VIEWER,
    "goruntuleyici": Role.VIEWER,
    "auditor": Role.AUDITOR,
    "denetci": Role.AUDITOR,
    "audit_manager": Role.AUDIT_MANAGER,
    "denetim_yoneticisi": Role.AUDIT_MANAGER,
    "model_manager": Role.MODEL_MANAGER,
    "model_yoneticisi": Role.MODEL_MANAGER,
    "system_admin": Role.SYSTEM_ADMIN,
    "sistem_yoneticisi": Role.SYSTEM_ADMIN,
}


class AuthorizationError(PermissionError):
    """Raised when a user attempts an operation outside their assigned roles."""


@dataclass(frozen=True)
class UserContext:
    subject: str
    display_name: str
    roles: tuple[Role, ...] = (Role.VIEWER,)
    email: str = ""
    claims: Mapping[str, Any] = field(default_factory=dict, repr=False, compare=False)

    @property
    def permissions(self) -> frozenset[Permission]:
        granted: set[Permission] = set()
        for role in self.roles:
            granted.update(ROLE_PERMISSIONS[role])
        return frozenset(granted)

    def can(self, permission: Permission) -> bool:
        return permission in self.permissions

    def require(self, permission: Permission) -> None:
        if not self.can(permission):
            raise AuthorizationError(
                f"{self.display_name} kullanıcısının '{permission.value}' yetkisi yok."
            )


def normalize_roles(values: str | Iterable[str] | None) -> tuple[Role, ...]:
    if values is None:
        return (Role.VIEWER,)
    raw_values = [values] if isinstance(values, str) else list(values)
    roles: list[Role] = []
    for raw in raw_values:
        if isinstance(raw, Role):
            if raw not in roles:
                roles.append(raw)
            continue
        key = str(raw).strip().casefold().replace("-", "_").replace(" ", "_")
        role = ROLE_ALIASES.get(key)
        if role and role not in roles:
            roles.append(role)
    return tuple(roles) or (Role.VIEWER,)


def user_from_oidc_claims(
    claims: Mapping[str, Any],
    role_claim: str = "roles",
) -> UserContext:
    """Convert verified OIDC claims supplied by the identity layer into app roles."""
    subject = str(claims.get("sub", "")).strip()
    if not subject:
        raise ValueError("OIDC kimlik bilgisinde zorunlu 'sub' alanı yok.")
    display_name = str(
        claims.get("name")
        or claims.get("preferred_username")
        or claims.get("email")
        or subject
    )
    raw_roles = claims.get(role_claim, claims.get("groups"))
    if isinstance(raw_roles, str) and "," in raw_roles:
        raw_roles = [item.strip() for item in raw_roles.split(",")]
    return UserContext(
        subject=subject,
        display_name=display_name,
        email=str(claims.get("email", "")),
        roles=normalize_roles(raw_roles),
        claims=dict(claims),
    )


def demo_user(roles: Iterable[Role] | None = None) -> UserContext:
    selected = tuple(roles or (Role.AUDIT_MANAGER, Role.MODEL_MANAGER))
    return UserContext(
        subject="demo-user",
        display_name="Demo Kullanıcısı",
        roles=selected,
    )


@dataclass(frozen=True)
class OIDCConfig:
    issuer: str = ""
    client_id: str = ""
    authorization_endpoint: str = ""
    role_claim: str = "roles"
    scopes: tuple[str, ...] = ("openid", "profile", "email")

    @classmethod
    def from_env(cls) -> "OIDCConfig":
        scopes = tuple(
            item
            for item in os.getenv(
                "FINANOMALY_OIDC_SCOPES",
                "openid profile email",
            ).split()
            if item
        )
        return cls(
            issuer=os.getenv("FINANOMALY_OIDC_ISSUER", "").rstrip("/"),
            client_id=os.getenv("FINANOMALY_OIDC_CLIENT_ID", ""),
            authorization_endpoint=os.getenv(
                "FINANOMALY_OIDC_AUTHORIZATION_ENDPOINT",
                "",
            ),
            role_claim=os.getenv("FINANOMALY_OIDC_ROLE_CLAIM", "roles"),
            scopes=scopes,
        )

    @property
    def configured(self) -> bool:
        return bool(self.issuer and self.client_id)

    @property
    def discovery_url(self) -> str:
        return f"{self.issuer}/.well-known/openid-configuration" if self.issuer else ""

    def build_authorization_url(
        self,
        redirect_uri: str,
        *,
        state: str | None = None,
        nonce: str | None = None,
    ) -> str:
        if not self.configured or not self.authorization_endpoint:
            raise ValueError("OIDC authorization endpoint yapılandırılmamış.")
        query = urlencode(
            {
                "client_id": self.client_id,
                "redirect_uri": redirect_uri,
                "response_type": "code",
                "scope": " ".join(self.scopes),
                "state": state or secrets.token_urlsafe(24),
                "nonce": nonce or secrets.token_urlsafe(24),
            }
        )
        return f"{self.authorization_endpoint}?{query}"
