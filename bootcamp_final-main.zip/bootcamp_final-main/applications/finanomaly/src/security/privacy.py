from __future__ import annotations

import hashlib
import hmac
import os
from typing import Any

import pandas as pd


SENSITIVE_COLUMNS = ("calisan", "tedarikci", "aciklama")


def _masking_key(secret: str | None = None) -> bytes:
    configured = secret or os.getenv("FINANOMALY_MASKING_SECRET", "")
    return (configured or "finanomaly-local-demo-key").encode("utf-8")


def pseudonymize(
    value: Any,
    *,
    prefix: str = "Kayıt",
    secret: str | None = None,
) -> str:
    text = "" if pd.isna(value) else str(value).strip()
    if not text:
        return f"{prefix}-Bilinmiyor"
    digest = hmac.new(
        _masking_key(secret),
        text.casefold().encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()[:8].upper()
    return f"{prefix}-{digest}"


def mask_description(value: Any) -> str:
    text = "" if pd.isna(value) else str(value).strip()
    return "[Açıklama maskelendi]" if text else "[Açıklama yok]"


def mask_sensitive_data(
    frame: pd.DataFrame,
    *,
    secret: str | None = None,
) -> pd.DataFrame:
    """Return a copy whose direct identifiers are stable pseudonyms."""
    masked = frame.copy()
    if "calisan" in masked:
        masked["calisan"] = masked["calisan"].apply(
            lambda value: pseudonymize(value, prefix="Çalışan", secret=secret)
        )
    if "tedarikci" in masked:
        masked["tedarikci"] = masked["tedarikci"].apply(
            lambda value: pseudonymize(value, prefix="Tedarikçi", secret=secret)
        )
    if "aciklama" in masked:
        masked["aciklama"] = masked["aciklama"].apply(mask_description)
    return masked


def mask_transaction_payload(
    payload: dict[str, Any],
    *,
    secret: str | None = None,
) -> dict[str, Any]:
    masked = dict(payload)
    if "calisan" in masked:
        masked["calisan"] = pseudonymize(
            masked["calisan"],
            prefix="Çalışan",
            secret=secret,
        )
    if "tedarikci" in masked:
        masked["tedarikci"] = pseudonymize(
            masked["tedarikci"],
            prefix="Tedarikçi",
            secret=secret,
        )
    if "aciklama" in masked:
        masked["aciklama"] = mask_description(masked["aciklama"])
    return masked
