from __future__ import annotations

import fcntl
import hashlib
import hmac
import json
import os
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Protocol
from urllib.error import URLError
from urllib.request import Request, urlopen

from applications.finanomaly.src.config import APP_VERSION, AUDIT_TRAIL_PATH


GENESIS_HASH = "0" * 64


class AuditIntegrityError(RuntimeError):
    """Raised when a hash-chained audit file has been altered."""


class AuditDeliveryError(RuntimeError):
    """Raised when a configured central audit endpoint rejects an event."""


@dataclass(frozen=True)
class AuditEvent:
    event_type: str
    actor: str
    target_id: str = ""
    payload: Mapping[str, Any] = field(default_factory=dict)
    occurred_at_utc: str = ""
    event_id: str = ""

    def normalized(self) -> dict[str, Any]:
        event = asdict(self)
        timestamp = self.occurred_at_utc or datetime.now(timezone.utc).isoformat()
        seed = json.dumps(
            {
                "event_type": self.event_type,
                "actor": self.actor,
                "target_id": self.target_id,
                "payload": dict(self.payload),
                "occurred_at_utc": timestamp,
            },
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            default=str,
        )
        event["occurred_at_utc"] = timestamp
        event["event_id"] = self.event_id or hashlib.sha256(seed.encode("utf-8")).hexdigest()[:24]
        event["payload"] = dict(self.payload)
        event["app_version"] = APP_VERSION
        return event


class AuditSink(Protocol):
    def emit(self, event: AuditEvent) -> dict[str, Any]:
        ...


def _canonical_hash(record: Mapping[str, Any]) -> str:
    payload = {key: value for key, value in record.items() if key != "event_hash"}
    canonical = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _parse_records(content: str) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for line_number, line in enumerate(content.splitlines(), start=1):
        if not line.strip():
            continue
        try:
            records.append(json.loads(line))
        except json.JSONDecodeError as exc:
            raise AuditIntegrityError(
                f"Audit log satırı {line_number} geçerli JSON değil."
            ) from exc
    return records


def verify_records(records: list[dict[str, Any]]) -> None:
    previous_hash = GENESIS_HASH
    for index, record in enumerate(records, start=1):
        if record.get("previous_hash") != previous_hash:
            raise AuditIntegrityError(f"Audit zinciri {index}. olayda kırılmış.")
        expected_hash = _canonical_hash(record)
        if not hmac_compare(str(record.get("event_hash", "")), expected_hash):
            raise AuditIntegrityError(f"Audit olayı {index} değiştirilmiş.")
        previous_hash = expected_hash


def hmac_compare(left: str, right: str) -> bool:
    return hmac.compare_digest(left, right)


class HashChainAuditSink:
    """Append-only local sink whose chained hashes make changes detectable."""

    def __init__(self, path: str | Path = AUDIT_TRAIL_PATH) -> None:
        self.path = Path(path)

    def emit(self, event: AuditEvent) -> dict[str, Any]:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a+", encoding="utf-8") as handle:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            handle.seek(0)
            records = _parse_records(handle.read())
            verify_records(records)
            previous_hash = records[-1]["event_hash"] if records else GENESIS_HASH
            record = event.normalized()
            record["sequence"] = len(records) + 1
            record["previous_hash"] = previous_hash
            record["event_hash"] = _canonical_hash(record)
            handle.seek(0, os.SEEK_END)
            handle.write(
                json.dumps(
                    record,
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                    default=str,
                )
                + "\n"
            )
            handle.flush()
            os.fsync(handle.fileno())
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        return record

    def verify(self) -> int:
        if not self.path.exists():
            return 0
        records = _parse_records(self.path.read_text(encoding="utf-8"))
        verify_records(records)
        return len(records)


class HttpAuditSink:
    """Central audit integration using an append-only collector endpoint."""

    def __init__(self, endpoint: str, token: str = "", timeout_seconds: float = 3.0) -> None:
        self.endpoint = endpoint
        self.token = token
        self.timeout_seconds = timeout_seconds

    def emit(self, event: AuditEvent) -> dict[str, Any]:
        record = event.normalized()
        headers = {"Content-Type": "application/json", "Idempotency-Key": record["event_id"]}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        request = Request(
            self.endpoint,
            data=json.dumps(record, ensure_ascii=False, default=str).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        try:
            with urlopen(request, timeout=self.timeout_seconds) as response:
                if response.status < 200 or response.status >= 300:
                    raise AuditDeliveryError(
                        f"Merkezi audit servisi HTTP {response.status} döndürdü."
                    )
        except (OSError, URLError) as exc:
            raise AuditDeliveryError("Merkezi audit servisine olay gönderilemedi.") from exc
        return record


class CompositeAuditSink:
    def __init__(self, *sinks: AuditSink) -> None:
        self.sinks = sinks

    def emit(self, event: AuditEvent) -> dict[str, Any]:
        normalized = event.normalized()
        stable_event = AuditEvent(
            event_type=normalized["event_type"],
            actor=normalized["actor"],
            target_id=normalized["target_id"],
            payload=normalized["payload"],
            occurred_at_utc=normalized["occurred_at_utc"],
            event_id=normalized["event_id"],
        )
        result: dict[str, Any] = {}
        for sink in self.sinks:
            result = sink.emit(stable_event)
        return result


def build_audit_sink(path: str | Path = AUDIT_TRAIL_PATH) -> AuditSink:
    local_sink = HashChainAuditSink(path)
    endpoint = os.getenv("FINANOMALY_AUDIT_ENDPOINT", "").strip()
    if not endpoint:
        return local_sink
    central_sink = HttpAuditSink(
        endpoint,
        token=os.getenv("FINANOMALY_AUDIT_TOKEN", ""),
    )
    return CompositeAuditSink(local_sink, central_sink)


def verify_audit_log(path: str | Path = AUDIT_TRAIL_PATH) -> int:
    return HashChainAuditSink(path).verify()
