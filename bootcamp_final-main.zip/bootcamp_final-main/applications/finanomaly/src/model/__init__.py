"""Model training and scoring."""
