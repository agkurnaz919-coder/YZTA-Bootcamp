import argparse
import pickle
import sys
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter
from typing import Any

import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.metrics import average_precision_score


if __package__ is None or __package__ == "":
    sys.path.insert(0, str(Path(__file__).resolve().parents[4]))

from applications.finanomaly.src.config import (
    APP_VERSION,
    HYBRID_MODEL_PATH,
    HYBRID_WEIGHTS,
    MODEL_BUNDLE_VERSION,
    MODEL_PARAMS,
    MODEL_PATH,
    MODEL_COMPARISON_PATH,
    MODEL_VERSION,
    OPTIONAL_LABEL_COLUMN,
    PROCESSED_EXPENSES_PATH,
    RAW_EXPENSES_PATH,
    RULESET_VERSION,
    SCORED_EXPENSES_PATH,
    ensure_directories,
)
from applications.finanomaly.src.data.preprocess import clean_expense_data, load_expense_file, preprocess_file
from applications.finanomaly.src.model.autoencoder import train_autoencoder
from applications.finanomaly.src.model.evaluation import compare_model_scores, comparison_markdown, false_positive_summary
from applications.finanomaly.src.model.features import align_feature_matrix, build_feature_matrix
from applications.finanomaly.src.model.scoring import (
    build_group_thresholds,
    optimize_risk_thresholds,
    score_transactions,
)


def train_isolation_forest(feature_matrix: pd.DataFrame, params: dict[str, Any] | None = None) -> IsolationForest:
    model_params = dict(MODEL_PARAMS)
    if params:
        model_params.update(params)
    model = IsolationForest(**model_params)
    model.fit(feature_matrix)
    return model


def train_model_bundle(processed: pd.DataFrame) -> dict[str, Any]:
    training_started = perf_counter()
    feature_matrix = build_feature_matrix(processed)
    iforest = train_isolation_forest(feature_matrix)
    autoencoder = train_autoencoder(feature_matrix)
    raw_scores = -iforest.decision_function(feature_matrix)
    low = float(raw_scores.min())
    high = float(pd.Series(raw_scores).quantile(0.99))
    if abs(high - low) < 1e-12:
        high = low + 1.0
    iforest_bounds = (low, high)

    scoring_started = perf_counter()
    initial = score_transactions(
        processed,
        iforest,
        feature_matrix,
        autoencoder_model=autoencoder,
        iforest_bounds=iforest_bounds,
    )
    scoring_duration_ms = (perf_counter() - scoring_started) * 1000
    thresholds = None
    if OPTIONAL_LABEL_COLUMN in initial:
        thresholds = optimize_risk_thresholds(
            initial["risk_skoru"],
            initial[OPTIONAL_LABEL_COLUMN],
        )
    if thresholds is None:
        from applications.finanomaly.src.config import RISK_THRESHOLDS

        thresholds = dict(RISK_THRESHOLDS)
    group_thresholds = build_group_thresholds(initial, thresholds)
    training_duration_ms = (perf_counter() - training_started) * 1000
    rows_per_second = (
        len(processed) / (scoring_duration_ms / 1000)
        if scoring_duration_ms > 0
        else 0.0
    )

    return {
        "bundle_version": MODEL_BUNDLE_VERSION,
        "app_version": APP_VERSION,
        "model_version": MODEL_VERSION,
        "ruleset_version": RULESET_VERSION,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "iforest_model": iforest,
        "autoencoder_model": autoencoder,
        "feature_columns": list(feature_matrix.columns),
        "iforest_bounds": iforest_bounds,
        "risk_thresholds": thresholds,
        "group_thresholds": group_thresholds,
        "model_params": MODEL_PARAMS,
        "hybrid_weights": dict(HYBRID_WEIGHTS),
        "performance_profile": {
            "profile_version": 1,
            "training_rows": len(processed),
            "feature_count": len(feature_matrix.columns),
            "training_duration_ms": round(training_duration_ms, 2),
            "reference_scoring_duration_ms": round(scoring_duration_ms, 2),
            "reference_rows_per_second": round(rows_per_second, 2),
        },
    }


def score_with_model_bundle(processed: pd.DataFrame, bundle: dict[str, Any]) -> pd.DataFrame:
    scoring_started = perf_counter()
    feature_matrix = build_feature_matrix(processed)
    aligned = align_feature_matrix(feature_matrix, bundle["feature_columns"])
    scored = score_transactions(
        processed,
        bundle["iforest_model"],
        aligned,
        autoencoder_model=bundle["autoencoder_model"],
        iforest_bounds=tuple(bundle["iforest_bounds"]),
        thresholds=bundle.get("risk_thresholds"),
        group_thresholds=bundle.get("group_thresholds"),
    )
    model_version = str(
        bundle.get(
            "model_version",
            f"legacy-bundle-v{bundle.get('bundle_version', 1)}",
        )
    )
    ruleset_version = str(bundle.get("ruleset_version", RULESET_VERSION))
    scored["model_surumu"] = model_version
    scored["kural_surumu"] = ruleset_version
    duration_ms = (perf_counter() - scoring_started) * 1000
    scored.attrs["runtime_profile"] = {
        "row_count": len(scored),
        "feature_count": len(aligned.columns),
        "scoring_duration_ms": round(duration_ms, 2),
        "rows_per_second": round(
            len(scored) / (duration_ms / 1000) if duration_ms > 0 else 0.0,
            2,
        ),
    }
    scored.attrs["model_profile"] = {
        "app_version": bundle.get("app_version", "legacy"),
        "bundle_version": bundle.get("bundle_version", 1),
        "model_version": model_version,
        "ruleset_version": ruleset_version,
        "created_at_utc": bundle.get("created_at_utc", ""),
        "performance_profile": bundle.get("performance_profile", {}),
    }
    return scored


def run_hybrid_dataframe_pipeline(
    raw_df: pd.DataFrame,
) -> tuple[pd.DataFrame, dict[str, float | int] | None, dict[str, Any]]:
    processed = clean_expense_data(raw_df)
    bundle = train_model_bundle(processed)
    scored = score_with_model_bundle(processed, bundle)
    evaluation = evaluate_manual_labels(scored)
    return scored, evaluation, bundle


def run_dataframe_pipeline(raw_df: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, float | int] | None, IsolationForest]:
    scored, evaluation, bundle = run_hybrid_dataframe_pipeline(raw_df)
    return scored, evaluation, bundle["iforest_model"]


def run_file_pipeline(
    input_path: str | Path = RAW_EXPENSES_PATH,
    processed_path: str | Path = PROCESSED_EXPENSES_PATH,
    scored_path: str | Path = SCORED_EXPENSES_PATH,
    model_path: str | Path = HYBRID_MODEL_PATH,
    iforest_model_path: str | Path = MODEL_PATH,
    comparison_path: str | Path | None = MODEL_COMPARISON_PATH,
) -> tuple[pd.DataFrame, dict[str, float | int] | None]:
    ensure_directories()
    processed = preprocess_file(input_path, processed_path)
    bundle = train_model_bundle(processed)
    scored = score_with_model_bundle(processed, bundle)

    Path(scored_path).parent.mkdir(parents=True, exist_ok=True)
    scored.to_csv(scored_path, index=False)

    Path(model_path).parent.mkdir(parents=True, exist_ok=True)
    with Path(model_path).open("wb") as handle:
        pickle.dump(bundle, handle)

    legacy_payload = {
        "bundle_version": MODEL_BUNDLE_VERSION,
        "app_version": APP_VERSION,
        "model_version": MODEL_VERSION,
        "ruleset_version": RULESET_VERSION,
        "model": bundle["iforest_model"],
        "feature_columns": bundle["feature_columns"],
        "model_params": MODEL_PARAMS,
        "iforest_bounds": bundle["iforest_bounds"],
        "performance_profile": bundle["performance_profile"],
    }
    Path(iforest_model_path).parent.mkdir(parents=True, exist_ok=True)
    with Path(iforest_model_path).open("wb") as handle:
        pickle.dump(legacy_payload, handle)

    if comparison_path is not None:
        comparison_output = Path(comparison_path)
        comparison_output.parent.mkdir(parents=True, exist_ok=True)
        comparison = compare_model_scores(scored)
        comparison_output.write_text(
            comparison_markdown(comparison),
            encoding="utf-8",
        )

    return scored, evaluate_manual_labels(scored)


def evaluate_manual_labels(scored: pd.DataFrame) -> dict[str, float | int] | None:
    if OPTIONAL_LABEL_COLUMN not in scored.columns:
        return None

    labels = pd.to_numeric(scored[OPTIONAL_LABEL_COLUMN], errors="coerce").fillna(0).astype(int)
    predictions = scored["anomali_mi"].astype(int)

    true_positive = int(((labels == 1) & (predictions == 1)).sum())
    false_positive = int(((labels == 0) & (predictions == 1)).sum())
    false_negative = int(((labels == 1) & (predictions == 0)).sum())
    true_negative = int(((labels == 0) & (predictions == 0)).sum())

    precision = true_positive / (true_positive + false_positive) if true_positive + false_positive else 0.0
    recall = true_positive / (true_positive + false_negative) if true_positive + false_negative else 0.0
    accuracy = (true_positive + true_negative) / len(scored) if len(scored) else 0.0
    false_positive_rate = false_positive / (false_positive + true_negative) if false_positive + true_negative else 0.0
    pr_auc = (
        float(average_precision_score(labels, scored["risk_skoru"]))
        if labels.nunique() > 1
        else 0.0
    )
    top_k = min(20, len(scored))
    top_k_hit_rate = (
        float(labels.loc[scored.nlargest(top_k, "risk_skoru").index].mean())
        if top_k
        else 0.0
    )

    return {
        "true_positive": true_positive,
        "false_positive": false_positive,
        "false_negative": false_negative,
        "true_negative": true_negative,
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "accuracy": round(accuracy, 4),
        "false_positive_rate": round(false_positive_rate, 4),
        "pr_auc": round(pr_auc, 4),
        "top_20_hit_rate": round(top_k_hit_rate, 4),
    }


def top_suspicious(scored: pd.DataFrame, limit: int = 20) -> pd.DataFrame:
    return scored.sort_values("risk_skoru", ascending=False).head(limit)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train Isolation Forest and score expenses.")
    parser.add_argument("--input", default=str(RAW_EXPENSES_PATH), help="CSV/XLSX input path.")
    parser.add_argument("--processed-output", default=str(PROCESSED_EXPENSES_PATH), help="Processed CSV path.")
    parser.add_argument("--scored-output", default=str(SCORED_EXPENSES_PATH), help="Scored CSV path.")
    parser.add_argument("--model-output", default=str(HYBRID_MODEL_PATH), help="Hybrid model bundle path.")
    parser.add_argument("--iforest-output", default=str(MODEL_PATH), help="Legacy Isolation Forest path.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    scored, evaluation = run_file_pipeline(
        input_path=args.input,
        processed_path=args.processed_output,
        scored_path=args.scored_output,
        model_path=args.model_output,
        iforest_model_path=args.iforest_output,
    )

    suspicious = top_suspicious(scored, 20)
    print(f"Scored {len(scored)} rows -> {args.scored_output}")
    print(f"Saved hybrid model -> {args.model_output}")
    print(f"Saved Isolation Forest -> {args.iforest_output}")
    print(f"Suspicious rows in top 20: {len(suspicious)}")
    if evaluation:
        print(f"Evaluation: {evaluation}")
    comparison = compare_model_scores(scored)
    print(f"Model comparison: {comparison}")
    false_positives = false_positive_summary(scored)
    if not false_positives.empty:
        print("Highest false-positive groups:")
        print(false_positives.head(5).to_string(index=False))


if __name__ == "__main__":
    main()
