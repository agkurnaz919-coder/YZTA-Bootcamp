from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score


def compare_model_scores(scored: pd.DataFrame, label_column: str = "manuel_etiket") -> dict[str, float]:
    comparison = {
        "iforest_mean": round(float(scored["iforest_skoru"].mean()), 4),
        "autoencoder_mean": round(float(scored["autoencoder_skoru"].mean()), 4),
        "score_correlation": round(
            float(scored["iforest_skoru"].corr(scored["autoencoder_skoru"])),
            4,
        ),
        "mean_absolute_difference": round(
            float((scored["iforest_skoru"] - scored["autoencoder_skoru"]).abs().mean()),
            4,
        ),
    }
    if label_column in scored:
        labels = pd.to_numeric(scored[label_column], errors="coerce").fillna(0).astype(int)
        if labels.nunique() > 1:
            comparison["iforest_pr_auc"] = round(
                float(average_precision_score(labels, scored["iforest_skoru"])),
                4,
            )
            comparison["autoencoder_pr_auc"] = round(
                float(average_precision_score(labels, scored["autoencoder_skoru"])),
                4,
            )
            comparison["hybrid_pr_auc"] = round(
                float(average_precision_score(labels, scored["risk_skoru"])),
                4,
            )
    return comparison


def false_positive_summary(
    scored: pd.DataFrame,
    label_column: str = "manuel_etiket",
) -> pd.DataFrame:
    columns = ["departman", "kategori", "yanlis_pozitif_sayisi", "toplam_normal", "yanlis_pozitif_orani"]
    if label_column not in scored:
        return pd.DataFrame(columns=columns)
    labels = pd.to_numeric(scored[label_column], errors="coerce").fillna(0).astype(int)
    analysis = scored.assign(
        _normal=labels.eq(0),
        _false_positive=labels.eq(0) & scored["anomali_mi"].astype(bool),
    )
    grouped = (
        analysis.groupby(["departman", "kategori"], dropna=False)
        .agg(
            yanlis_pozitif_sayisi=("_false_positive", "sum"),
            toplam_normal=("_normal", "sum"),
        )
        .reset_index()
    )
    grouped["yanlis_pozitif_orani"] = np.where(
        grouped["toplam_normal"].gt(0),
        grouped["yanlis_pozitif_sayisi"] / grouped["toplam_normal"],
        0.0,
    )
    return grouped.sort_values(
        ["yanlis_pozitif_sayisi", "yanlis_pozitif_orani"],
        ascending=False,
    ).reset_index(drop=True)


def comparison_markdown(comparison: dict[str, float]) -> str:
    labels = {
        "iforest_mean": "Isolation Forest ortalama skoru",
        "autoencoder_mean": "Autoencoder ortalama skoru",
        "score_correlation": "Skor korelasyonu",
        "mean_absolute_difference": "Ortalama mutlak skor farkı",
        "iforest_pr_auc": "Isolation Forest PR-AUC",
        "autoencoder_pr_auc": "Autoencoder PR-AUC",
        "hybrid_pr_auc": "Hibrit PR-AUC",
    }
    lines = [
        "# Model Karşılaştırma Raporu",
        "",
        "Isolation Forest, autoencoder ve hibrit skor aynı işaretli veri üzerinde karşılaştırılmıştır.",
        "",
        "| Metrik | Değer |",
        "|---|---:|",
    ]
    lines.extend(f"| {labels.get(key, key)} | {value:.4f} |" for key, value in comparison.items())
    lines.extend(
        [
            "",
            "Hibrit skor; Isolation Forest, autoencoder yeniden oluşturma hatası ve kural skorunu birlikte kullanır.",
        ]
    )
    return "\n".join(lines) + "\n"
