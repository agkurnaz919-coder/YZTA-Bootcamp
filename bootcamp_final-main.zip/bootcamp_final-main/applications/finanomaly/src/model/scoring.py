import sys
from pathlib import Path

import numpy as np
import pandas as pd


if __package__ is None or __package__ == "":
    sys.path.insert(0, str(Path(__file__).resolve().parents[4]))

from applications.finanomaly.src.config import (
    GROUP_THRESHOLD_COLUMNS,
    HYBRID_WEIGHTS,
    MODEL_VERSION,
    RISK_THRESHOLDS,
)
from applications.finanomaly.src.reporting.explanations import add_explanations
from applications.finanomaly.src.rules.business_rules import apply_business_rules


def normalize_scores(
    values: np.ndarray | pd.Series,
    bounds: tuple[float, float] | None = None,
) -> np.ndarray:
    scores = np.asarray(values, dtype=float)
    if scores.size == 0:
        return scores
    min_score, max_score = bounds or (float(np.nanmin(scores)), float(np.nanmax(scores)))
    if np.isclose(max_score, min_score):
        return np.zeros_like(scores, dtype=float)
    return np.clip((scores - min_score) / (max_score - min_score), 0.0, 1.0)


def assign_risk_level(
    score: float,
    thresholds: dict[str, float] | None = None,
    high_threshold: float | None = None,
) -> str:
    active = thresholds or RISK_THRESHOLDS
    if score >= (high_threshold if high_threshold is not None else active["yuksek"]):
        return "yuksek"
    if score >= active["orta"]:
        return "orta"
    return "dusuk"


def optimize_risk_thresholds(
    scores: pd.Series,
    labels: pd.Series,
    defaults: dict[str, float] | None = None,
) -> dict[str, float]:
    active = dict(defaults or RISK_THRESHOLDS)
    y_true = pd.to_numeric(labels, errors="coerce").fillna(0).astype(int)
    if len(y_true) < 5 or y_true.nunique() < 2:
        return active

    best_f1 = -1.0
    best_threshold = active["yuksek"]
    candidates = np.unique(np.r_[np.linspace(0.35, 0.9, 56), scores.to_numpy(dtype=float)])
    for threshold in candidates:
        predictions = scores.ge(threshold).astype(int)
        true_positive = int(((y_true == 1) & (predictions == 1)).sum())
        false_positive = int(((y_true == 0) & (predictions == 1)).sum())
        false_negative = int(((y_true == 1) & (predictions == 0)).sum())
        precision = true_positive / (true_positive + false_positive) if true_positive + false_positive else 0.0
        recall = true_positive / (true_positive + false_negative) if true_positive + false_negative else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        if f1 > best_f1 or (np.isclose(f1, best_f1) and threshold > best_threshold):
            best_f1 = f1
            best_threshold = float(threshold)

    high = float(np.clip(best_threshold, 0.50, 0.90))
    medium = float(np.clip(high * 0.65, 0.30, min(0.60, high - 0.05)))
    return {"yuksek": round(high, 4), "orta": round(medium, 4)}


def build_group_thresholds(
    scored: pd.DataFrame,
    global_thresholds: dict[str, float],
    group_columns: list[str] | None = None,
) -> dict[str, dict[str, float]]:
    thresholds: dict[str, dict[str, float]] = {}
    for column in group_columns or GROUP_THRESHOLD_COLUMNS:
        if column not in scored:
            continue
        column_thresholds: dict[str, float] = {}
        for group_name, group in scored.groupby(column, dropna=False):
            if len(group) < 3:
                value = global_thresholds["yuksek"]
            else:
                value = float(group["risk_skoru"].quantile(0.85))
                value = float(np.clip(value, global_thresholds["yuksek"] * 0.85, 0.92))
            column_thresholds[str(group_name)] = round(value, 4)
        thresholds[column] = column_thresholds
    return thresholds


def apply_risk_thresholds(
    scored: pd.DataFrame,
    thresholds: dict[str, float] | None = None,
    group_thresholds: dict[str, dict[str, float]] | None = None,
) -> pd.DataFrame:
    active = dict(thresholds or RISK_THRESHOLDS)
    result = scored.copy()
    high_values = pd.Series(active["yuksek"], index=result.index, dtype=float)
    for column, mapping in (group_thresholds or {}).items():
        if column in result:
            mapped = result[column].astype(str).map(mapping).fillna(active["yuksek"])
            high_values = pd.concat([high_values, mapped], axis=1).mean(axis=1)
    result["dinamik_yuksek_esik"] = high_values.round(4)
    result["risk_seviyesi"] = [
        assign_risk_level(score, active, high_threshold)
        for score, high_threshold in zip(result["risk_skoru"], high_values)
    ]
    result["anomali_mi"] = (
        result["iforest_etiketi"].eq(-1)
        | result["risk_seviyesi"].isin(["yuksek", "orta"])
    )
    return add_explanations(result)


def score_transactions(
    df: pd.DataFrame,
    model,
    feature_matrix: pd.DataFrame,
    autoencoder_model=None,
    iforest_bounds: tuple[float, float] | None = None,
    thresholds: dict[str, float] | None = None,
    group_thresholds: dict[str, dict[str, float]] | None = None,
) -> pd.DataFrame:
    model_raw = -model.decision_function(feature_matrix)
    model_risk = normalize_scores(model_raw, iforest_bounds)
    model_label = model.predict(feature_matrix)
    rule_scores = apply_business_rules(df)
    if autoencoder_model is None:
        autoencoder_risk = model_risk
    else:
        autoencoder_risk = autoencoder_model.score_samples(feature_matrix)

    scored = df.copy()
    scored["iforest_skoru"] = model_risk
    scored["iforest_etiketi"] = model_label
    scored["autoencoder_skoru"] = autoencoder_risk
    scored = pd.concat([scored, rule_scores], axis=1)
    scored["model_surumu"] = MODEL_VERSION
    scored["risk_skoru"] = (
        scored["iforest_skoru"].astype(float) * HYBRID_WEIGHTS["iforest"]
        + scored["autoencoder_skoru"].astype(float) * HYBRID_WEIGHTS["autoencoder"]
        + scored["rule_skoru"].astype(float) * HYBRID_WEIGHTS["rules"]
    ).clip(0, 1)
    scored = apply_risk_thresholds(scored, thresholds, group_thresholds)
    return scored.sort_values(["risk_skoru", "rule_hits"], ascending=[False, False]).reset_index(drop=True)
