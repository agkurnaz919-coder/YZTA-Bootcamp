import pickle
import sys
from pathlib import Path
from typing import Any

import pandas as pd


if __package__ is None or __package__ == "":
    sys.path.insert(0, str(Path(__file__).resolve().parents[4]))

from applications.finanomaly.src.config import HYBRID_MODEL_PATH
from applications.finanomaly.src.data.preprocess import clean_expense_data
from applications.finanomaly.src.model.train_iforest import score_with_model_bundle


class _MergedProjectUnpickler(pickle.Unpickler):
    """Load FinAnomaly models saved before the project was namespaced."""

    def find_class(self, module: str, name: str) -> Any:
        if module == "src" or module.startswith("src."):
            module = f"applications.finanomaly.{module}"
        return super().find_class(module, name)


def load_model_bundle(path: str | Path = HYBRID_MODEL_PATH) -> dict[str, Any]:
    with Path(path).open("rb") as handle:
        bundle = _MergedProjectUnpickler(handle).load()
    required = {
        "iforest_model",
        "autoencoder_model",
        "feature_columns",
        "iforest_bounds",
        "risk_thresholds",
    }
    missing = sorted(required.difference(bundle))
    if missing:
        raise ValueError(f"Geçersiz hibrit model paketi; eksik alanlar: {', '.join(missing)}")
    return bundle


def score_dataframe_with_saved_model(
    raw_df: pd.DataFrame,
    model_path: str | Path = HYBRID_MODEL_PATH,
) -> pd.DataFrame:
    bundle = load_model_bundle(model_path)
    processed = clean_expense_data(raw_df)
    return score_with_model_bundle(processed, bundle)


def model_bundle_profile(
    path: str | Path = HYBRID_MODEL_PATH,
) -> dict[str, Any]:
    bundle = load_model_bundle(path)
    return {
        "app_version": bundle.get("app_version", "legacy"),
        "bundle_version": bundle.get("bundle_version", 1),
        "model_version": bundle.get(
            "model_version",
            f"legacy-bundle-v{bundle.get('bundle_version', 1)}",
        ),
        "ruleset_version": bundle.get("ruleset_version", "legacy"),
        "created_at_utc": bundle.get("created_at_utc", ""),
        "model_params": bundle.get("model_params", {}),
        "hybrid_weights": bundle.get("hybrid_weights", {}),
        "risk_thresholds": bundle.get("risk_thresholds", {}),
        "performance_profile": bundle.get("performance_profile", {}),
    }
