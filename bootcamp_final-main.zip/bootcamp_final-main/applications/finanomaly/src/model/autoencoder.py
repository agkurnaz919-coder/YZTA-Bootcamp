import argparse
import pickle
import sys
import warnings
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.exceptions import ConvergenceWarning
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler


if __package__ is None or __package__ == "":
    sys.path.insert(0, str(Path(__file__).resolve().parents[4]))

from applications.finanomaly.src.config import AUTOENCODER_MODEL_PATH, AUTOENCODER_PARAMS, RAW_EXPENSES_PATH
from applications.finanomaly.src.data.preprocess import clean_expense_data, load_expense_file
from applications.finanomaly.src.model.features import build_feature_matrix


class ReconstructionAutoencoder:
    """Small deterministic neural autoencoder built with scikit-learn."""

    def __init__(self, params: dict[str, Any] | None = None) -> None:
        self.params = dict(AUTOENCODER_PARAMS)
        if params:
            self.params.update(params)
        self.scaler = StandardScaler()
        self.estimator: MLPRegressor | None = None
        self.error_bounds: tuple[float, float] = (0.0, 1.0)

    def fit(self, feature_matrix: pd.DataFrame | np.ndarray) -> "ReconstructionAutoencoder":
        values = np.asarray(feature_matrix, dtype=float)
        if values.ndim != 2 or len(values) < 2:
            raise ValueError("Autoencoder eğitimi için en az iki satırlı bir özellik matrisi gerekir.")

        scaled = self.scaler.fit_transform(values)
        params = dict(self.params)
        if len(values) < 10:
            params["early_stopping"] = False
        self.estimator = MLPRegressor(**params)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=ConvergenceWarning)
            self.estimator.fit(scaled, scaled)

        errors = self.reconstruction_error(feature_matrix)
        low = float(np.nanmin(errors))
        high = float(np.nanpercentile(errors, 99))
        if np.isclose(low, high):
            high = low + 1.0
        self.error_bounds = (low, high)
        return self

    def reconstruction_error(self, feature_matrix: pd.DataFrame | np.ndarray) -> np.ndarray:
        if self.estimator is None:
            raise RuntimeError("Autoencoder henüz eğitilmedi.")
        values = np.asarray(feature_matrix, dtype=float)
        scaled = self.scaler.transform(values)
        reconstructed = self.estimator.predict(scaled)
        return np.mean(np.square(scaled - reconstructed), axis=1)

    def score_samples(self, feature_matrix: pd.DataFrame | np.ndarray) -> np.ndarray:
        errors = self.reconstruction_error(feature_matrix)
        low, high = self.error_bounds
        return np.clip((errors - low) / (high - low), 0.0, 1.0)


def train_autoencoder(
    feature_matrix: pd.DataFrame,
    params: dict[str, Any] | None = None,
) -> ReconstructionAutoencoder:
    return ReconstructionAutoencoder(params=params).fit(feature_matrix)


def main() -> None:
    parser = argparse.ArgumentParser(description="FinAnomaly autoencoder modelini eğit ve skor üret.")
    parser.add_argument("--input", default=str(RAW_EXPENSES_PATH), help="CSV/XLSX girdi yolu.")
    parser.add_argument("--model-output", default=str(AUTOENCODER_MODEL_PATH), help="Model çıktı yolu.")
    args = parser.parse_args()

    raw = load_expense_file(args.input)
    processed = clean_expense_data(raw)
    features = build_feature_matrix(processed)
    model = train_autoencoder(features)
    scores = model.score_samples(features)

    output = Path(args.model_output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("wb") as handle:
        pickle.dump(
            {"model": model, "feature_columns": list(features.columns)},
            handle,
        )

    print(f"Autoencoder {len(features)} işlem üzerinde eğitildi -> {output}")
    print(f"Skor aralığı: {scores.min():.4f} - {scores.max():.4f}")


if __name__ == "__main__":
    main()
