import sys
from pathlib import Path

import numpy as np
import pandas as pd


if __package__ is None or __package__ == "":
    sys.path.insert(0, str(Path(__file__).resolve().parents[4]))

from applications.finanomaly.src.config import CATEGORICAL_FEATURE_COLUMNS, NUMERIC_FEATURE_COLUMNS
from applications.finanomaly.src.data.preprocess import add_engineered_features


def build_feature_matrix(df: pd.DataFrame) -> pd.DataFrame:
    missing_numeric = [column for column in NUMERIC_FEATURE_COLUMNS if column not in df.columns]
    if missing_numeric:
        df = add_engineered_features(df)

    numeric = df.reindex(columns=NUMERIC_FEATURE_COLUMNS).copy()
    numeric = numeric.apply(pd.to_numeric, errors="coerce")

    categorical_source = df.reindex(columns=CATEGORICAL_FEATURE_COLUMNS).fillna("Bilinmiyor")
    categorical = pd.get_dummies(categorical_source.astype(str), prefix=CATEGORICAL_FEATURE_COLUMNS)

    features = pd.concat([numeric, categorical], axis=1)
    features = features.replace([np.inf, -np.inf], np.nan).fillna(0.0)
    return features.astype(float)


def align_feature_matrix(features: pd.DataFrame, expected_columns: list[str]) -> pd.DataFrame:
    aligned = features.copy()
    for column in expected_columns:
        if column not in aligned.columns:
            aligned[column] = 0.0
    return aligned.reindex(columns=expected_columns, fill_value=0.0).astype(float)
