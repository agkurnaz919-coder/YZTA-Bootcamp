from pathlib import Path


APP_VERSION = "3.0.0"
MODEL_BUNDLE_VERSION = 3
MODEL_VERSION = "hybrid-iforest-autoencoder-v3"
RULESET_VERSION = "financial-rules-v3"

BASE_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = BASE_DIR / "data"
RAW_DATA_DIR = DATA_DIR / "raw"
PROCESSED_DATA_DIR = DATA_DIR / "processed"
MODEL_DIR = BASE_DIR / "models"
DOCS_DIR = BASE_DIR / "docs"

RAW_EXPENSES_PATH = RAW_DATA_DIR / "expenses.csv"
PROCESSED_EXPENSES_PATH = PROCESSED_DATA_DIR / "expenses_processed.csv"
SCORED_EXPENSES_PATH = PROCESSED_DATA_DIR / "expenses_scored.csv"
MODEL_PATH = MODEL_DIR / "isolation_forest.pkl"
HYBRID_MODEL_PATH = MODEL_DIR / "hybrid_anomaly_model.pkl"
AUTOENCODER_MODEL_PATH = MODEL_DIR / "autoencoder.pkl"
MODEL_COMPARISON_PATH = DOCS_DIR / "model_comparison.md"
AUDIT_TRAIL_PATH = PROCESSED_DATA_DIR / "audit_trail.jsonl"
FINAL_DEMO_DATA_PATH = RAW_DATA_DIR / "finanomaly_final_demo.csv"

REQUIRED_COLUMNS = [
    "calisan",
    "departman",
    "tarih",
    "tutar",
    "kategori",
    "tedarikci",
    "odeme_tipi",
    "aciklama",
]

OPTIONAL_LABEL_COLUMN = "manuel_etiket"
OPTIONAL_REASON_COLUMN = "anomali_nedeni"

COLUMN_ALIASES = {
    "employee": "calisan",
    "employee_name": "calisan",
    "staff": "calisan",
    "department": "departman",
    "date": "tarih",
    "transaction_date": "tarih",
    "amount": "tutar",
    "expense_amount": "tutar",
    "category": "kategori",
    "vendor": "tedarikci",
    "supplier": "tedarikci",
    "merchant": "tedarikci",
    "payment_type": "odeme_tipi",
    "payment_method": "odeme_tipi",
    "description": "aciklama",
    "note": "aciklama",
    "manual_label": OPTIONAL_LABEL_COLUMN,
    "label": OPTIONAL_LABEL_COLUMN,
    "anomaly_reason": OPTIONAL_REASON_COLUMN,
    "reason": OPTIONAL_REASON_COLUMN,
}

CATEGORY_MAP = {
    "ulasim": "Ulasim",
    "travel": "Ulasim",
    "taxi": "Ulasim",
    "yemek": "Yemek",
    "food": "Yemek",
    "meal": "Yemek",
    "konaklama": "Konaklama",
    "lodging": "Konaklama",
    "hotel": "Konaklama",
    "ofis": "Ofis",
    "office": "Ofis",
    "yazilim": "Yazilim",
    "software": "Yazilim",
    "egitim": "Egitim",
    "training": "Egitim",
    "danismanlik": "Danismanlik",
    "consulting": "Danismanlik",
    "elektronik": "Elektronik",
    "electronics": "Elektronik",
}

PAYMENT_TYPE_MAP = {
    "sirket_karti": "Sirket Karti",
    "company_card": "Sirket Karti",
    "card": "Sirket Karti",
    "nakit": "Nakit",
    "cash": "Nakit",
    "havale": "Havale",
    "eft": "Havale",
    "transfer": "Havale",
}

NUMERIC_FEATURE_COLUMNS = [
    "tutar",
    "tutar_zscore",
    "kategori_ortalama_sapmasi",
    "departman_ortalama_sapmasi",
    "hafta_sonu_mu",
    "tedarikci_islem_sayisi",
    "calisan_tedarikci_islem_sayisi",
    "tekrar_tedarikci_tutar_sayisi",
    "yuvarlak_tutar_mi",
    "aciklama_uzunlugu",
    "mesai_disi_mi",
    "ay",
    "gun",
    "saat",
]

CATEGORICAL_FEATURE_COLUMNS = ["departman", "kategori", "odeme_tipi"]

MODEL_PARAMS = {
    "n_estimators": 200,
    "contamination": 0.12,
    "max_samples": "auto",
    "random_state": 42,
}

AUTOENCODER_PARAMS = {
    "hidden_layer_sizes": (24, 8, 24),
    "activation": "relu",
    "solver": "adam",
    "alpha": 0.0005,
    "learning_rate_init": 0.002,
    "max_iter": 600,
    "early_stopping": True,
    "validation_fraction": 0.15,
    "random_state": 42,
}

HYBRID_WEIGHTS = {
    "iforest": 0.40,
    "autoencoder": 0.35,
    "rules": 0.25,
}

RISK_THRESHOLDS = {
    "yuksek": 0.75,
    "orta": 0.45,
}

RISK_LEVELS = ["yuksek", "orta", "dusuk"]

GROUP_THRESHOLD_COLUMNS = ["departman", "kategori"]

SUSPICIOUS_DESCRIPTION_WORDS = {
    "acil",
    "belgesiz",
    "diger",
    "faturasiz",
    "manuel",
    "misc",
    "nakit",
    "ozel",
}


def ensure_directories() -> None:
    for path in [RAW_DATA_DIR, PROCESSED_DATA_DIR, MODEL_DIR, DOCS_DIR]:
        path.mkdir(parents=True, exist_ok=True)


def describe_config() -> str:
    return "\n".join(
        [
            f"APP_VERSION={APP_VERSION}",
            f"MODEL_VERSION={MODEL_VERSION}",
            f"RULESET_VERSION={RULESET_VERSION}",
            f"BASE_DIR={BASE_DIR}",
            f"RAW_EXPENSES_PATH={RAW_EXPENSES_PATH}",
            f"PROCESSED_EXPENSES_PATH={PROCESSED_EXPENSES_PATH}",
            f"SCORED_EXPENSES_PATH={SCORED_EXPENSES_PATH}",
            f"MODEL_PATH={MODEL_PATH}",
            f"HYBRID_MODEL_PATH={HYBRID_MODEL_PATH}",
            f"MODEL_PARAMS={MODEL_PARAMS}",
        ]
    )


if __name__ == "__main__":
    ensure_directories()
    print(describe_config())
