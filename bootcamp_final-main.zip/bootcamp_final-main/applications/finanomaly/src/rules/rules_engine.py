import sys
from pathlib import Path

import numpy as np
import pandas as pd


if __package__ is None or __package__ == "":
    sys.path.insert(0, str(Path(__file__).resolve().parents[4]))

from applications.finanomaly.src.config import RULESET_VERSION, SUSPICIOUS_DESCRIPTION_WORDS


RULE_DEFINITIONS = {
    "ayni_tutar_tekrari": ("Aynı tutar tekrarı", 0.13),
    "hafta_sonu_veya_mesai_disi": ("Hafta sonu veya mesai dışı işlem", 0.12),
    "departman_ust_limit": ("Departman ortalamasının çok üstünde", 0.17),
    "kategori_ust_limit": ("Kategori ortalamasının çok üstünde", 0.13),
    "tedarikci_kisa_sure_coklu_odeme": ("Tedarikçiye kısa sürede çoklu ödeme", 0.17),
    "aciklama_riski": ("Eksik veya şüpheli açıklama", 0.12),
    "nakit_odeme": ("Nakit ödeme", 0.08),
    "yuvarlak_tutar": ("Yüksek yuvarlak tutar", 0.08),
}


def _vendor_burst_flags(df: pd.DataFrame, window_days: int = 7, minimum_count: int = 3) -> pd.Series:
    flags = pd.Series(False, index=df.index, dtype=bool)
    dated = df.assign(_tarih=pd.to_datetime(df["tarih"], errors="coerce"))
    for _vendor, group in dated.groupby("tedarikci", dropna=False):
        valid = group.dropna(subset=["_tarih"]).sort_values("_tarih")
        dates = valid["_tarih"]
        for row_index, date_value in dates.items():
            within_window = dates.between(
                date_value - pd.Timedelta(days=window_days),
                date_value + pd.Timedelta(days=window_days),
            )
            flags.loc[row_index] = int(within_window.sum()) >= minimum_count
    return flags


def _description_risk(series: pd.Series) -> pd.Series:
    descriptions = series.fillna("").astype(str).str.strip().str.lower()
    suspicious_pattern = "|".join(sorted(SUSPICIOUS_DESCRIPTION_WORDS))
    return (
        descriptions.eq("")
        | descriptions.eq("bilinmiyor")
        | descriptions.str.len().le(8)
        | descriptions.str.contains(suspicious_pattern, regex=True, na=False)
    )


def evaluate_rules(df: pd.DataFrame) -> pd.DataFrame:
    """Return one boolean column for every auditable financial rule."""
    required = {
        "tutar",
        "tutar_zscore",
        "kategori_ortalama_sapmasi",
        "departman_ortalama_sapmasi",
        "hafta_sonu_mu",
        "mesai_disi_mi",
        "tekrar_tedarikci_tutar_sayisi",
        "yuvarlak_tutar_mi",
        "odeme_tipi",
        "aciklama",
        "tedarikci",
        "tarih",
    }
    missing = sorted(required.difference(df.columns))
    if missing:
        raise ValueError(f"Kural motoru için eksik kolonlar: {', '.join(missing)}")

    rules = pd.DataFrame(index=df.index)
    repeated_amount_count = df.groupby("tutar", dropna=False)["tutar"].transform("size")
    rules["ayni_tutar_tekrari"] = (
        (repeated_amount_count >= 3)
        | (df["tekrar_tedarikci_tutar_sayisi"].astype(float) >= 2)
    )
    rules["hafta_sonu_veya_mesai_disi"] = (
        df["hafta_sonu_mu"].astype(int).eq(1) | df["mesai_disi_mi"].astype(int).eq(1)
    )
    rules["departman_ust_limit"] = df["departman_ortalama_sapmasi"].astype(float) >= 2.0
    rules["kategori_ust_limit"] = df["kategori_ortalama_sapmasi"].astype(float) >= 2.0
    rules["tedarikci_kisa_sure_coklu_odeme"] = _vendor_burst_flags(df)
    rules["aciklama_riski"] = _description_risk(df["aciklama"])
    rules["nakit_odeme"] = df["odeme_tipi"].astype(str).str.casefold().eq("nakit")
    rules["yuvarlak_tutar"] = (
        df["yuvarlak_tutar_mi"].astype(int).eq(1)
        & df["tutar"].astype(float).ge(df["tutar"].astype(float).median())
    )
    return rules.astype(bool)


def _joined_labels(row: pd.Series) -> str:
    values = [
        RULE_DEFINITIONS[column][0]
        for column, hit in row.items()
        if bool(hit)
    ]
    return " | ".join(values)


def apply_business_rules(df: pd.DataFrame) -> pd.DataFrame:
    rules = evaluate_rules(df)
    weighted = pd.Series(np.zeros(len(df)), index=df.index, dtype=float)
    for column, (_label, weight) in RULE_DEFINITIONS.items():
        weighted += rules[column].astype(float) * weight

    result = pd.DataFrame(index=df.index)
    for column in rules:
        result[f"kural_{column}"] = rules[column]
    result["rule_skoru"] = weighted.clip(0, 1)
    result["rule_hits"] = rules.sum(axis=1).astype(int)
    result["kural_kodlari"] = rules.apply(
        lambda row: " | ".join(column for column, hit in row.items() if bool(hit)),
        axis=1,
    )
    result["kural_ihlalleri"] = rules.apply(_joined_labels, axis=1)
    result["rule_nedenleri"] = result["kural_ihlalleri"]
    result["kural_surumu"] = RULESET_VERSION
    return result


def main() -> None:
    from applications.finanomaly.src.config import RAW_EXPENSES_PATH
    from applications.finanomaly.src.data.preprocess import clean_expense_data, load_expense_file

    processed = clean_expense_data(load_expense_file(RAW_EXPENSES_PATH))
    results = apply_business_rules(processed)
    print(results[["rule_skoru", "rule_hits", "kural_ihlalleri"]].head(20).to_string(index=False))


if __name__ == "__main__":
    main()
