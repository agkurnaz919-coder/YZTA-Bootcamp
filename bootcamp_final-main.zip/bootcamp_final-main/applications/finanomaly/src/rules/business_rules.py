"""Backward-compatible import for the Sprint 2 rule engine."""

from applications.finanomaly.src.rules.rules_engine import RULE_DEFINITIONS, apply_business_rules, evaluate_rules


RULE_WEIGHTS = {name: weight for name, (_label, weight) in RULE_DEFINITIONS.items()}

__all__ = ["RULE_DEFINITIONS", "RULE_WEIGHTS", "apply_business_rules", "evaluate_rules"]
