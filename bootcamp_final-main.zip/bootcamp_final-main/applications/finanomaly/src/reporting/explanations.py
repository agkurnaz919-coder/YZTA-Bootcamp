from __future__ import annotations

from typing import Any

import pandas as pd


def _risk_factors(row: pd.Series) -> list[str]:
    factors: list[tuple[float, str]] = []
    rule_text = str(row.get("kural_ihlalleri", "")).strip()
    if rule_text:
        for label in rule_text.split(" | "):
            factors.append((float(row.get("rule_skoru", 0.0)) + 0.25, label))
    if float(row.get("iforest_skoru", 0.0)) >= 0.60:
        factors.append((float(row["iforest_skoru"]), "Isolation Forest aykırılık skoru yüksek"))
    if float(row.get("autoencoder_skoru", 0.0)) >= 0.60:
        factors.append((float(row["autoencoder_skoru"]), "Autoencoder yeniden oluşturma hatası yüksek"))
    if float(row.get("departman_ortalama_sapmasi", 0.0)) >= 1.5:
        factors.append(
            (
                min(float(row["departman_ortalama_sapmasi"]) / 4, 1.0),
                "Tutar departman davranışından belirgin biçimde sapıyor",
            )
        )
    if float(row.get("kategori_ortalama_sapmasi", 0.0)) >= 1.5:
        factors.append(
            (
                min(float(row["kategori_ortalama_sapmasi"]) / 4, 1.0),
                "Tutar kategori davranışından belirgin biçimde sapıyor",
            )
        )
    if not factors:
        factors.append((float(row.get("risk_skoru", 0.0)), "İşlem genel davranış profiline yakın"))
    return [label for _weight, label in sorted(factors, key=lambda item: item[0], reverse=True)[:3]]


def add_explanations(scored: pd.DataFrame) -> pd.DataFrame:
    explained = scored.copy()
    factor_lists = explained.apply(_risk_factors, axis=1)
    explained["risk_faktorleri"] = factor_lists.apply(lambda values: " | ".join(values))
    explained["neden_supheli"] = explained.apply(
        lambda row: (
            f"{row['risk_seviyesi'].title()} risk ({float(row['risk_skoru']):.0%}): "
            f"{row['risk_faktorleri']}."
        ),
        axis=1,
    )
    return explained


def build_transaction_detail(row: pd.Series | dict[str, Any]) -> dict[str, Any]:
    item = pd.Series(row)
    violations = [
        value
        for value in str(item.get("kural_ihlalleri", "")).split(" | ")
        if value
    ]
    factors = [
        value
        for value in str(item.get("risk_faktorleri", "")).split(" | ")
        if value
    ]
    return {
        "islem_id": item.get("islem_id", ""),
        "islem": {
            "calisan": item.get("calisan", ""),
            "departman": item.get("departman", ""),
            "tarih": str(item.get("tarih", "")),
            "tutar": float(item.get("tutar", 0.0)),
            "kategori": item.get("kategori", ""),
            "tedarikci": item.get("tedarikci", ""),
            "odeme_tipi": item.get("odeme_tipi", ""),
            "aciklama": item.get("aciklama", ""),
        },
        "skorlar": {
            "hibrit_risk": round(float(item.get("risk_skoru", 0.0)), 4),
            "isolation_forest": round(float(item.get("iforest_skoru", 0.0)), 4),
            "autoencoder": round(float(item.get("autoencoder_skoru", 0.0)), 4),
            "kural": round(float(item.get("rule_skoru", 0.0)), 4),
            "risk_seviyesi": item.get("risk_seviyesi", ""),
        },
        "surumler": {
            "model": item.get("model_surumu", ""),
            "kural": item.get("kural_surumu", ""),
        },
        "kural_ihlalleri": violations,
        "risk_faktorleri": factors,
        "aciklama": item.get("neden_supheli", ""),
    }
