from __future__ import annotations

import io
import unicodedata
from datetime import datetime, timezone

import pandas as pd


REPORT_COLUMNS = [
    "islem_id",
    "risk_skoru",
    "risk_seviyesi",
    "iforest_skoru",
    "autoencoder_skoru",
    "rule_skoru",
    "kural_ihlalleri",
    "neden_supheli",
    "model_surumu",
    "kural_surumu",
    "calisan",
    "departman",
    "tarih",
    "tutar",
    "kategori",
    "tedarikci",
    "odeme_tipi",
    "aciklama",
    "manuel_etiket",
]


def prepare_suspicious_report(scored: pd.DataFrame, include_medium: bool = True) -> pd.DataFrame:
    levels = ["yuksek", "orta"] if include_medium else ["yuksek"]
    filtered = scored[scored["risk_seviyesi"].isin(levels)].copy()
    columns = [column for column in REPORT_COLUMNS if column in filtered]
    return filtered.sort_values("risk_skoru", ascending=False)[columns].reset_index(drop=True)


def csv_report_bytes(report: pd.DataFrame) -> bytes:
    return report.to_csv(index=False).encode("utf-8-sig")


def xlsx_report_bytes(report: pd.DataFrame) -> bytes:
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        report.to_excel(writer, sheet_name="Supheli Islemler", index=False)
        model_version = (
            str(report["model_surumu"].iloc[0])
            if len(report) and "model_surumu" in report
            else ""
        )
        ruleset_version = (
            str(report["kural_surumu"].iloc[0])
            if len(report) and "kural_surumu" in report
            else ""
        )
        summary = pd.DataFrame(
            {
                "metrik": [
                    "Rapor zamanı (UTC)",
                    "İşlem sayısı",
                    "Toplam tutar",
                    "Model sürümü",
                    "Kural sürümü",
                ],
                "deger": [
                    datetime.now(timezone.utc).isoformat(),
                    len(report),
                    round(float(report.get("tutar", pd.Series(dtype=float)).sum()), 2),
                    model_version,
                    ruleset_version,
                ],
            }
        )
        summary.to_excel(writer, sheet_name="Ozet", index=False)
    return output.getvalue()


def _ascii_pdf_text(value: object) -> str:
    normalized = unicodedata.normalize("NFKD", str(value))
    ascii_text = normalized.encode("ascii", "ignore").decode("ascii")
    return ascii_text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def _build_pdf(lines_by_page: list[list[str]]) -> bytes:
    objects: dict[int, bytes] = {
        1: b"<< /Type /Catalog /Pages 2 0 R >>",
        3: b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    }
    page_ids = []
    next_id = 4
    for lines in lines_by_page:
        page_id = next_id
        content_id = next_id + 1
        next_id += 2
        page_ids.append(page_id)
        commands = ["BT", "/F1 9 Tf", "40 800 Td", "12 TL"]
        for line in lines:
            commands.append(f"({_ascii_pdf_text(line)}) Tj")
            commands.append("T*")
        commands.append("ET")
        stream = "\n".join(commands).encode("ascii")
        objects[page_id] = (
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] "
            f"/Resources << /Font << /F1 3 0 R >> >> /Contents {content_id} 0 R >>"
        ).encode("ascii")
        objects[content_id] = (
            f"<< /Length {len(stream)} >>\nstream\n".encode("ascii")
            + stream
            + b"\nendstream"
        )
    kids = " ".join(f"{page_id} 0 R" for page_id in page_ids)
    objects[2] = f"<< /Type /Pages /Kids [{kids}] /Count {len(page_ids)} >>".encode("ascii")

    output = io.BytesIO()
    output.write(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = {0: 0}
    for object_id in range(1, max(objects) + 1):
        offsets[object_id] = output.tell()
        output.write(f"{object_id} 0 obj\n".encode("ascii"))
        output.write(objects[object_id])
        output.write(b"\nendobj\n")
    xref_offset = output.tell()
    output.write(f"xref\n0 {max(objects) + 1}\n".encode("ascii"))
    output.write(b"0000000000 65535 f \n")
    for object_id in range(1, max(objects) + 1):
        output.write(f"{offsets[object_id]:010d} 00000 n \n".encode("ascii"))
    output.write(
        (
            f"trailer\n<< /Size {max(objects) + 1} /Root 1 0 R >>\n"
            f"startxref\n{xref_offset}\n%%EOF\n"
        ).encode("ascii")
    )
    return output.getvalue()


def pdf_report_bytes(report: pd.DataFrame) -> bytes:
    model_version = (
        str(report["model_surumu"].iloc[0])
        if len(report) and "model_surumu" in report
        else ""
    )
    ruleset_version = (
        str(report["kural_surumu"].iloc[0])
        if len(report) and "kural_surumu" in report
        else ""
    )
    header = [
        "FinAnomaly Supheli Islem Raporu",
        f"Olusturma zamani (UTC): {datetime.now(timezone.utc).isoformat()}",
        f"Islem sayisi: {len(report)}",
        f"Model surumu: {model_version}",
        f"Kural surumu: {ruleset_version}",
        "",
    ]
    rows = []
    for _, row in report.head(100).iterrows():
        rows.append(
            f"{row.get('islem_id', '')} | {float(row.get('risk_skoru', 0)):.0%} | "
            f"{row.get('risk_seviyesi', '')} | {row.get('calisan', '')} | "
            f"{float(row.get('tutar', 0)):,.2f} | {row.get('tedarikci', '')}"
        )
        rows.append(f"Neden: {row.get('neden_supheli', '')}"[:110])
    all_lines = header + rows
    lines_per_page = 56
    pages = [
        all_lines[index : index + lines_per_page]
        for index in range(0, max(len(all_lines), 1), lines_per_page)
    ]
    return _build_pdf(pages)
