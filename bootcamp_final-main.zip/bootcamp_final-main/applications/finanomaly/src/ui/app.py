import html
import sys
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st


if __package__ is None or __package__ == "":
    sys.path.insert(0, str(Path(__file__).resolve().parents[4]))

from applications.ui_theme import apply_theme, page_header, style_plotly
from applications.finanomaly.src.config import APP_VERSION, HYBRID_MODEL_PATH, RAW_EXPENSES_PATH, RISK_LEVELS
from applications.finanomaly.src.data.preprocess import ExpenseDataError, inspect_data_quality, load_expense_file
from applications.finanomaly.src.feedback import append_audit_event, append_audit_trail, apply_label_feedback
from applications.finanomaly.src.model.evaluation import compare_model_scores, false_positive_summary
from applications.finanomaly.src.model.service import score_dataframe_with_saved_model
from applications.finanomaly.src.model.train_iforest import (
    evaluate_manual_labels,
    run_hybrid_dataframe_pipeline,
    top_suspicious,
)
from applications.finanomaly.src.reporting.explanations import build_transaction_detail
from applications.finanomaly.src.reporting.export import (
    csv_report_bytes,
    pdf_report_bytes,
    prepare_suspicious_report,
    xlsx_report_bytes,
)
from applications.finanomaly.src.security.auth import (
    ROLE_LABELS,
    OIDCConfig,
    Permission,
    Role,
    UserContext,
    demo_user,
    user_from_oidc_claims,
)
from applications.finanomaly.src.security.privacy import mask_sensitive_data


apply_theme()

st.markdown(
    """
    <style>
    .risk-badge {
        display:inline-block; padding:.22rem .5rem; margin:.12rem;
        border-radius:5px; background:#fff5e7; color:#8a4d0f;
        border:1px solid #efd5ae; font-size:.78rem; font-weight:600;
    }
    .fa-skip {position:absolute; left:-9999px; top:auto;}
    .fa-skip:focus {left:1rem; top:1rem; background:var(--ri-surface); color:#111827;
        padding:.6rem; z-index:9999; border:2px solid #176b5b;}
    </style>
    <a class="fa-skip" href="#finanomaly-main">Ana içeriğe geç</a>
    """,
    unsafe_allow_html=True,
)


@st.cache_data(show_spinner=False)
def load_default_data() -> pd.DataFrame:
    return load_expense_file(RAW_EXPENSES_PATH)


def load_uploaded_data(uploaded_file) -> pd.DataFrame:
    return load_expense_file(uploaded_file, uploaded_file.name)


def score_data(raw_df: pd.DataFrame, use_saved_model: bool):
    if use_saved_model and HYBRID_MODEL_PATH.exists():
        try:
            scored = score_dataframe_with_saved_model(raw_df, HYBRID_MODEL_PATH)
        except Exception:  # Pickles can be stale or incompatible across machines.
            scored, evaluation, _bundle = run_hybrid_dataframe_pipeline(raw_df)
            return (
                scored,
                evaluation,
                "Kayıtlı model uyumsuz; oturumda yeniden eğitilen hibrit model",
            )
        return scored, evaluate_manual_labels(scored), "Kayıtlı hibrit model"
    scored, evaluation, _bundle = run_hybrid_dataframe_pipeline(raw_df)
    return scored, evaluation, "Oturumda yeniden eğitilen hibrit model"


def resolve_user_context() -> tuple[UserContext, OIDCConfig]:
    oidc = OIDCConfig.from_env()
    if oidc.configured:
        if not st.user.is_logged_in:
            st.sidebar.warning("Kurumsal oturum gerekli")
            if st.sidebar.button("SSO ile giriş yap", type="primary"):
                st.login()
            st.stop()
        claims = st.user.to_dict()
        user = user_from_oidc_claims(claims, role_claim=oidc.role_claim)
        st.sidebar.success("OIDC oturumu doğrulandı")
        st.sidebar.caption(f"Issuer: {oidc.issuer}")
        if st.sidebar.button("Oturumu kapat"):
            st.logout()
        return user, oidc

    role_options: dict[str, tuple[Role, ...]] = {
        "Final demo (Denetim + Model yöneticisi)": (
            Role.AUDIT_MANAGER,
            Role.MODEL_MANAGER,
        ),
        **{label: (role,) for role, label in ROLE_LABELS.items()},
    }
    selected_label = st.sidebar.selectbox(
        "Erişim profili",
        list(role_options),
        help=(
            "Yerel demoda rol kontrollerini doğrular. Üretimde roller, doğrulanmış "
            "OIDC claims içindeki rol alanından alınır."
        ),
    )
    user = demo_user(role_options[selected_label])
    st.sidebar.caption("Yerel demo kimliği · OIDC bağlantısı yapılandırılmadı")
    return user, oidc


def metric_cards(scored: pd.DataFrame) -> None:
    high_count = int(scored["risk_seviyesi"].eq("yuksek").sum())
    suspicious_amount = scored.loc[scored["anomali_mi"], "tutar"].sum()
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Toplam işlem", f"{len(scored):,}")
    col2.metric("Toplam tutar", f"₺{scored['tutar'].sum():,.2f}")
    col3.metric("Yüksek risk", f"{high_count:,}")
    col4.metric("İncelenecek tutar", f"₺{suspicious_amount:,.2f}")


def render_charts(scored: pd.DataFrame) -> None:
    risk_summary = (
        scored.groupby(["departman", "risk_seviyesi"], as_index=False)
        .agg(islem_sayisi=("islem_id", "count"), riskli_tutar=("tutar", "sum"))
    )
    department_fig = px.bar(
        risk_summary,
        x="departman",
        y="islem_sayisi",
        color="risk_seviyesi",
        category_orders={"risk_seviyesi": ["yuksek", "orta", "dusuk"]},
        color_discrete_map={"yuksek": "#c63d2f", "orta": "#e7a33e", "dusuk": "#4e8f72"},
        title="Departman ve risk seviyesi",
        labels={
            "departman": "Departman",
            "islem_sayisi": "İşlem sayısı",
            "risk_seviyesi": "Risk seviyesi",
        },
        template="plotly_white",
    )
    department_fig.update_layout(legend_title_text="Risk seviyesi")
    style_plotly(department_fig)

    category_summary = (
        scored.groupby("kategori", as_index=False)
        .agg(ortalama_risk=("risk_skoru", "mean"), toplam_tutar=("tutar", "sum"))
        .sort_values("ortalama_risk", ascending=False)
    )
    category_fig = px.scatter(
        category_summary,
        x="kategori",
        y="ortalama_risk",
        size="toplam_tutar",
        color="ortalama_risk",
        color_continuous_scale="OrRd",
        title="Kategori risk yoğunluğu",
        labels={
            "kategori": "Kategori",
            "ortalama_risk": "Ortalama risk",
            "toplam_tutar": "Toplam tutar",
        },
        template="plotly_white",
    )
    category_fig.update_yaxes(tickformat=".0%")
    style_plotly(category_fig)

    col1, col2 = st.columns(2)
    chart_config = {"displayModeBar": False, "responsive": True}
    col1.plotly_chart(department_fig, width="stretch", config=chart_config)
    col2.plotly_chart(category_fig, width="stretch", config=chart_config)
    st.caption(
        "Grafik özeti: departman çubukları işlem adetlerini, kategori balonları "
        "ortalama riski ve toplam tutarı karşılaştırır."
    )

    employee_summary = (
        scored.groupby("calisan", as_index=False)
        .agg(
            ortalama_risk=("risk_skoru", "mean"),
            supheli_islem=("anomali_mi", "sum"),
            toplam_tutar=("tutar", "sum"),
        )
        .sort_values(["ortalama_risk", "supheli_islem"], ascending=False)
    )
    st.subheader("Çalışan bazlı risk özeti")
    st.dataframe(
        employee_summary,
        width="stretch",
        hide_index=True,
        column_config={
            "ortalama_risk": st.column_config.ProgressColumn(
                "Ortalama risk",
                min_value=0.0,
                max_value=1.0,
                format="percent",
            ),
            "toplam_tutar": st.column_config.NumberColumn("Toplam tutar", format="₺%.2f"),
        },
    )


def render_transaction_detail(scored: pd.DataFrame) -> None:
    options = scored["islem_id"].tolist()
    labels = {
        row["islem_id"]: (
            f"{row['islem_id']} · {row['calisan']} · ₺{row['tutar']:,.2f} · "
            f"{row['risk_skoru']:.0%}"
        )
        for _, row in scored.iterrows()
    }
    selected_id = st.selectbox(
        "İşlem seç",
        options,
        format_func=lambda value: labels.get(value, value),
    )
    selected = scored.loc[scored["islem_id"].eq(selected_id)].iloc[0]
    detail = build_transaction_detail(selected)

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Hibrit risk", f"{detail['skorlar']['hibrit_risk']:.0%}")
    col2.metric("Isolation Forest", f"{detail['skorlar']['isolation_forest']:.0%}")
    col3.metric("Autoencoder", f"{detail['skorlar']['autoencoder']:.0%}")
    col4.metric("Kural skoru", f"{detail['skorlar']['kural']:.0%}")

    st.caption(
        f"Model {detail['surumler']['model']} · Kural {detail['surumler']['kural']}"
    )
    st.info(detail["aciklama"])
    if detail["kural_ihlalleri"]:
        badges = "".join(
            f'<span class="risk-badge">{html.escape(violation)}</span>'
            for violation in detail["kural_ihlalleri"]
        )
        st.markdown(badges, unsafe_allow_html=True)
    else:
        st.caption("Bu işlemde doğrudan bir kural ihlali bulunmadı.")

    st.subheader("İşlem bilgileri")
    st.json(detail["islem"], expanded=True)


def record_report_export(actor: str, report_format: str, row_count: int) -> None:
    append_audit_event(
        "report.exported",
        actor,
        target_id=f"suspicious-report.{report_format}",
        payload={"format": report_format, "row_count": row_count},
    )


def render_feedback_and_exports(scored: pd.DataFrame, user: UserContext) -> None:
    stored_feedback = st.session_state.get("feedback_updated")
    same_dataset = (
        isinstance(stored_feedback, pd.DataFrame)
        and set(stored_feedback["islem_id"]) == set(scored["islem_id"])
    )
    current = stored_feedback if same_dataset else scored

    if user.can(Permission.LABEL_TRANSACTION):
        st.subheader("Denetçi geri bildirimi")
        st.caption(
            "Etiket değişiklikleri kullanıcı, zaman ve önceki değerle birlikte "
            "hash-zincirli audit log'a yazılır."
        )
        reviewer = st.text_input("İnceleyen", value=user.display_name)
        feedback_columns = [
            "islem_id",
            "risk_skoru",
            "calisan",
            "tutar",
            "neden_supheli",
            "manuel_etiket",
        ]
        feedback_source = current.head(50).copy()
        if "manuel_etiket" not in feedback_source:
            feedback_source["manuel_etiket"] = 0
        edited = st.data_editor(
            feedback_source[feedback_columns],
            width="stretch",
            hide_index=True,
            disabled=[column for column in feedback_columns if column != "manuel_etiket"],
            column_config={
                "manuel_etiket": st.column_config.CheckboxColumn("Doğrulanmış anomali"),
                "risk_skoru": st.column_config.ProgressColumn(
                    "Risk",
                    min_value=0.0,
                    max_value=1.0,
                    format="percent",
                ),
            },
            key="audit_feedback",
        )
        if st.button("Geri bildirimi güvenli audit log'a kaydet", type="primary"):
            updated, audit_rows = apply_label_feedback(current, edited, reviewer=reviewer)
            if audit_rows.empty:
                st.info("Değişen bir manuel etiket yok.")
            else:
                append_audit_trail(audit_rows)
                st.session_state["feedback_updated"] = updated
                st.success(
                    f"{len(audit_rows)} etiket değişikliği audit log'a kaydedildi."
                )

    if not user.can(Permission.EXPORT_REPORT):
        st.info("Rapor dışa aktarma yalnızca denetim yöneticisi rolüne açıktır.")
        return

    report_source = st.session_state.get("feedback_updated", scored)
    if set(report_source["islem_id"]) != set(scored["islem_id"]):
        report_source = scored
    report = prepare_suspicious_report(report_source)
    st.subheader("Denetim raporları")
    col1, col2, col3 = st.columns(3)
    callback_args = (user.subject, len(report))
    col1.download_button(
        "CSV indir",
        csv_report_bytes(report),
        file_name="finanomaly_supheli_islemler.csv",
        mime="text/csv",
        width="stretch",
        on_click=record_report_export,
        args=(callback_args[0], "csv", callback_args[1]),
    )
    col2.download_button(
        "XLSX indir",
        xlsx_report_bytes(report),
        file_name="finanomaly_denetim_raporu.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        width="stretch",
        on_click=record_report_export,
        args=(callback_args[0], "xlsx", callback_args[1]),
    )
    col3.download_button(
        "PDF indir",
        pdf_report_bytes(report),
        file_name="finanomaly_denetim_raporu.pdf",
        mime="application/pdf",
        width="stretch",
        on_click=record_report_export,
        args=(callback_args[0], "pdf", callback_args[1]),
    )


def main() -> None:
    st.markdown('<div id="finanomaly-main"></div>', unsafe_allow_html=True)
    st.markdown(
        page_header(
            "Finansal denetim",
            "FinAnomaly",
            (
                "Açıklanabilir hibrit anomali tespitiyle riskli işlemleri "
                "önceliklendirin, inceleyin ve denetim çıktısına dönüştürün."
            ),
        ),
        unsafe_allow_html=True,
    )

    user, _oidc_config = resolve_user_context()
    role_names = ", ".join(ROLE_LABELS[role] for role in user.roles)
    st.sidebar.markdown(f"**{user.display_name}**")
    st.sidebar.caption(role_names)

    uploaded_file = st.sidebar.file_uploader(
        "CSV veya XLSX yükle",
        type=["csv", "xlsx"],
        help="Dosya en az sekiz zorunlu gider kolonunu ve bir işlem satırını içermelidir.",
    )
    risk_filter = st.sidebar.multiselect(
        "Risk seviyesi",
        RISK_LEVELS,
        default=["yuksek", "orta"],
    )
    use_saved_model = st.sidebar.toggle(
        "Kayıtlı modeli kullan",
        value=HYBRID_MODEL_PATH.exists(),
        help="Kapalı olduğunda model yüklenen veri üzerinde yeniden eğitilir.",
    )

    try:
        raw_df = load_uploaded_data(uploaded_file) if uploaded_file else load_default_data()
        quality_report = inspect_data_quality(raw_df)
        scored, evaluation, model_mode = score_data(raw_df, use_saved_model)
    except ExpenseDataError as exc:
        st.error(str(exc))
        st.info(
            "Beklenen kolonlar: calisan, departman, tarih, tutar, kategori, "
            "tedarikci, odeme_tipi, aciklama."
        )
        st.stop()
    except Exception:  # noqa: BLE001
        st.error(
            "Veri işlenirken beklenmeyen bir hata oluştu. Dosya biçimini kontrol "
            "edip tekrar deneyin; sorun sürerse sistem yöneticisine başvurun."
        )
        st.stop()

    if model_mode.startswith("Kayıtlı model uyumsuz"):
        st.sidebar.warning(model_mode)
    else:
        st.sidebar.caption(model_mode)
    if quality_report.has_warnings:
        st.sidebar.warning(
            "Veri kalite uyarısı · "
            f"{quality_report.invalid_amount_count} tutar, "
            f"{quality_report.invalid_date_count} tarih, "
            f"{quality_report.blank_sensitive_field_count} boş metin alanı normalize edildi."
        )

    runtime_profile = scored.attrs.get("runtime_profile", {})
    model_profile = scored.attrs.get("model_profile", {})
    st.caption(
        f"Uygulama {APP_VERSION} · Model {model_profile.get('model_version', 'bilinmiyor')} · "
        f"Kural {model_profile.get('ruleset_version', 'bilinmiyor')} · "
        f"{runtime_profile.get('scoring_duration_ms', 0):,.0f} ms"
    )
    metric_cards(scored)

    visible_scored = (
        scored
        if user.can(Permission.VIEW_PII)
        else mask_sensitive_data(scored)
    )
    if not user.can(Permission.VIEW_PII):
        st.info(
            "Bu erişim profilinde çalışan, tedarikçi ve açıklama alanları "
            "kişisel veri koruması için maskelenmiştir."
        )
    filtered = (
        visible_scored[visible_scored["risk_seviyesi"].isin(risk_filter)]
        if risk_filter
        else visible_scored
    )
    suspicious = top_suspicious(filtered, 20)

    tab_names = ["Risk panosu"]
    if user.can(Permission.VIEW_TRANSACTION_DETAIL):
        tab_names.append("İşlem detayı")
    if user.can(Permission.LABEL_TRANSACTION) or user.can(Permission.EXPORT_REPORT):
        tab_names.append("Geri bildirim & rapor")
    if user.can(Permission.VIEW_MODEL_METRICS):
        tab_names.append("Model kalitesi")
    tabs = dict(zip(tab_names, st.tabs(tab_names)))

    with tabs["Risk panosu"]:
        st.subheader("Öncelikli inceleme kuyruğu")
        visible_columns = [
            "risk_skoru",
            "risk_seviyesi",
            "kural_ihlalleri",
            "calisan",
            "departman",
            "tarih",
            "tutar",
            "kategori",
            "tedarikci",
            "aciklama",
        ]
        if suspicious.empty:
            st.success("Seçili filtrelerde incelenecek işlem bulunmuyor.")
        else:
            st.dataframe(
                suspicious[visible_columns],
                width="stretch",
                hide_index=True,
                column_config={
                    "risk_skoru": st.column_config.ProgressColumn(
                        "Hibrit risk",
                        min_value=0.0,
                        max_value=1.0,
                        format="percent",
                    ),
                    "tutar": st.column_config.NumberColumn("Tutar", format="₺%.2f"),
                },
            )
        render_charts(visible_scored)

    if "İşlem detayı" in tabs:
        with tabs["İşlem detayı"]:
            render_transaction_detail(visible_scored)

    if "Geri bildirim & rapor" in tabs:
        with tabs["Geri bildirim & rapor"]:
            render_feedback_and_exports(scored, user)

    if "Model kalitesi" in tabs:
        with tabs["Model kalitesi"]:
            st.subheader("Sürüm ve performans profili")
            st.json(
                {
                    **model_profile,
                    "son_calistirma": runtime_profile,
                }
            )
            st.subheader("Model karşılaştırması")
            st.json(compare_model_scores(scored))
            if evaluation:
                st.subheader("Manuel etiket metrikleri")
                st.json(evaluation)
                st.subheader("Yanlış pozitif analizi")
                st.dataframe(
                    false_positive_summary(scored),
                    width="stretch",
                    hide_index=True,
                )
            else:
                st.info(
                    "PR-AUC ve yanlış pozitif analizi için manuel_etiket kolonu ekleyin."
                )


if __name__ == "__main__":
    main()
