import argparse
import hashlib
import re
import sys
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import BinaryIO
from zipfile import BadZipFile

import numpy as np
import pandas as pd


if __package__ is None or __package__ == "":
    sys.path.insert(0, str(Path(__file__).resolve().parents[4]))

from applications.finanomaly.src.config import (
    CATEGORY_MAP,
    COLUMN_ALIASES,
    OPTIONAL_LABEL_COLUMN,
    OPTIONAL_REASON_COLUMN,
    PAYMENT_TYPE_MAP,
    PROCESSED_EXPENSES_PATH,
    RAW_EXPENSES_PATH,
    REQUIRED_COLUMNS,
    ensure_directories,
)


TURKISH_ASCII_TRANSLATION = {
    ord("\u00e7"): "c",
    ord("\u00c7"): "c",
    ord("\u011f"): "g",
    ord("\u011e"): "g",
    ord("\u0131"): "i",
    ord("\u0130"): "i",
    ord("\u00f6"): "o",
    ord("\u00d6"): "o",
    ord("\u015f"): "s",
    ord("\u015e"): "s",
    ord("\u00fc"): "u",
    ord("\u00dc"): "u",
}


class ExpenseDataError(ValueError):
    """Base exception for input problems that can be shown to an end user."""

    code = "invalid_expense_data"


class EmptyExpenseFileError(ExpenseDataError):
    code = "empty_file"


class UnsupportedExpenseFileError(ExpenseDataError):
    code = "unsupported_file_type"


class CorruptExpenseFileError(ExpenseDataError):
    code = "corrupt_file"


class MissingExpenseColumnsError(ExpenseDataError):
    code = "missing_columns"

    def __init__(self, missing: list[str], available: list[str] | None = None) -> None:
        self.missing = missing
        self.available = available or []
        available_text = ", ".join(self.available) if self.available else "kolon bulunamadı"
        super().__init__(
            "Eksik zorunlu kolonlar: "
            f"{', '.join(missing)}. Dosyada bulunan kolonlar: {available_text}. "
            "Şablon için kullanım kılavuzundaki veri şemasını kontrol edin."
        )


@dataclass(frozen=True)
class DataQualityReport:
    row_count: int
    column_count: int
    invalid_amount_count: int
    invalid_date_count: int
    blank_sensitive_field_count: int

    @property
    def has_warnings(self) -> bool:
        return any(
            [
                self.invalid_amount_count,
                self.invalid_date_count,
                self.blank_sensitive_field_count,
            ]
        )

    def as_dict(self) -> dict[str, int | bool]:
        return {
            "row_count": self.row_count,
            "column_count": self.column_count,
            "invalid_amount_count": self.invalid_amount_count,
            "invalid_date_count": self.invalid_date_count,
            "blank_sensitive_field_count": self.blank_sensitive_field_count,
            "has_warnings": self.has_warnings,
        }


def slugify(value: object) -> str:
    text = str(value).strip().lower().translate(TURKISH_ASCII_TRANSLATION)
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    text = re.sub(r"[^a-z0-9]+", "_", text)
    return text.strip("_")


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    renamed = {}
    for column in df.columns:
        slug = slugify(column)
        renamed[column] = COLUMN_ALIASES.get(slug, slug)

    normalized = df.rename(columns=renamed)
    normalized = normalized.loc[:, ~normalized.columns.duplicated()]
    missing = [column for column in REQUIRED_COLUMNS if column not in normalized.columns]
    if missing:
        raise MissingExpenseColumnsError(missing, list(normalized.columns))
    return normalized


def standardize_category(value: object) -> str:
    if pd.isna(value) or not str(value).strip():
        return "Bilinmiyor"
    slug = slugify(value)
    return CATEGORY_MAP.get(slug, str(value).strip().title() or "Bilinmiyor")


def standardize_payment_type(value: object) -> str:
    if pd.isna(value) or not str(value).strip():
        return "Bilinmiyor"
    slug = slugify(value)
    return PAYMENT_TYPE_MAP.get(slug, str(value).strip().title() or "Bilinmiyor")


def parse_amount(value: object) -> float:
    if pd.isna(value):
        return np.nan

    text = str(value).strip()
    text = re.sub(r"[^0-9,.\-]", "", text)
    if not text:
        return np.nan

    if "," in text and "." in text:
        text = text.replace(".", "").replace(",", ".")
    elif "," in text:
        text = text.replace(",", ".")

    try:
        return float(text)
    except ValueError:
        return np.nan


def _source_is_empty(source: str | Path | BinaryIO) -> bool:
    if isinstance(source, (str, Path)):
        path = Path(source)
        return path.exists() and path.stat().st_size == 0
    if hasattr(source, "getbuffer"):
        return len(source.getbuffer()) == 0
    if hasattr(source, "getvalue"):
        return len(source.getvalue()) == 0
    return False


def load_expense_file(source: str | Path | BinaryIO, name: str | None = None) -> pd.DataFrame:
    source_name = (
        name
        or getattr(source, "name", None)
        or ("upload.csv" if hasattr(source, "read") else str(source))
    )
    suffix = Path(source_name).suffix.lower()
    if suffix not in {".csv", ".xlsx"}:
        raise UnsupportedExpenseFileError(
            f"Desteklenmeyen dosya türü: {suffix or 'uzantısız dosya'}. "
            "Lütfen CSV veya XLSX dosyası yükleyin."
        )
    if _source_is_empty(source):
        raise EmptyExpenseFileError(
            "Yüklenen dosya boş. En az bir başlık satırı ve bir işlem satırı ekleyin."
        )

    try:
        if hasattr(source, "seek"):
            source.seek(0)
        frame = pd.read_excel(source) if suffix == ".xlsx" else pd.read_csv(source)
    except FileNotFoundError as exc:
        raise ExpenseDataError(f"Dosya bulunamadı: {source_name}") from exc
    except pd.errors.EmptyDataError as exc:
        raise EmptyExpenseFileError(
            "Yüklenen dosya boş veya kolon başlıkları okunamıyor."
        ) from exc
    except (pd.errors.ParserError, UnicodeDecodeError, BadZipFile, OSError, ValueError) as exc:
        raise CorruptExpenseFileError(
            "Dosya okunamadı. Dosyanın bozuk olmadığını, UTF-8 CSV veya geçerli "
            "bir XLSX olduğunu kontrol edin."
        ) from exc

    if frame.empty:
        raise EmptyExpenseFileError(
            "Dosyada işlem satırı bulunamadı. En az bir gider kaydı ekleyin."
        )
    return frame


def inspect_data_quality(df: pd.DataFrame) -> DataQualityReport:
    """Summarize recoverable quality issues before values are normalized."""
    if not isinstance(df, pd.DataFrame):
        raise ExpenseDataError("Gider verisi tablo biçiminde olmalıdır.")
    if df.empty:
        raise EmptyExpenseFileError("Veri tablosunda işlenecek gider kaydı bulunamadı.")

    normalized = normalize_columns(df.copy())
    amount_values = normalized["tutar"].apply(parse_amount)
    date_values = pd.to_datetime(
        normalized["tarih"],
        errors="coerce",
        format="mixed",
        dayfirst=True,
    )
    sensitive = normalized[["calisan", "tedarikci", "aciklama"]]
    blank_sensitive = sensitive.apply(
        lambda values: values.isna() | values.astype(str).str.strip().eq("")
    )
    return DataQualityReport(
        row_count=len(normalized),
        column_count=len(normalized.columns),
        invalid_amount_count=int(amount_values.isna().sum()),
        invalid_date_count=int(date_values.isna().sum()),
        blank_sensitive_field_count=int(blank_sensitive.sum().sum()),
    )


def clean_expense_data(df: pd.DataFrame) -> pd.DataFrame:
    if not isinstance(df, pd.DataFrame):
        raise ExpenseDataError("Gider verisi tablo biçiminde olmalıdır.")
    if df.empty:
        raise EmptyExpenseFileError("Veri tablosunda işlenecek gider kaydı bulunamadı.")
    cleaned = normalize_columns(df.copy())

    for column in ["calisan", "departman", "tedarikci", "aciklama"]:
        cleaned[column] = (
            cleaned[column]
            .astype("string")
            .fillna("")
            .str.strip()
            .replace("", "Bilinmiyor")
        )

    cleaned["kategori"] = cleaned["kategori"].apply(standardize_category)
    cleaned["odeme_tipi"] = cleaned["odeme_tipi"].apply(standardize_payment_type)

    cleaned["tutar"] = cleaned["tutar"].apply(parse_amount)
    median_amount = cleaned["tutar"].median()
    if np.isnan(median_amount):
        median_amount = 0.0
    cleaned["tutar"] = cleaned["tutar"].fillna(median_amount).astype(float)

    cleaned["tarih"] = pd.to_datetime(
        cleaned["tarih"],
        errors="coerce",
        format="mixed",
        dayfirst=True,
    )
    fallback_date = cleaned["tarih"].dropna().median()
    if pd.isna(fallback_date):
        fallback_date = pd.Timestamp.today().normalize()
    cleaned["tarih"] = cleaned["tarih"].fillna(fallback_date)

    if "islem_id" not in cleaned.columns:
        identity_columns = [
            "calisan",
            "departman",
            "tarih",
            "tutar",
            "kategori",
            "tedarikci",
            "odeme_tipi",
            "aciklama",
        ]
        duplicate_order = cleaned.groupby(identity_columns, dropna=False).cumcount()
        identities = cleaned[identity_columns].astype(str).agg("|".join, axis=1) + "|" + duplicate_order.astype(str)
        cleaned["islem_id"] = identities.apply(
            lambda value: f"TX-{hashlib.sha1(value.encode('utf-8')).hexdigest()[:12].upper()}"
        )
    else:
        cleaned["islem_id"] = cleaned["islem_id"].fillna("").astype(str).str.strip()
        missing_ids = cleaned["islem_id"].eq("")
        cleaned.loc[missing_ids, "islem_id"] = [
            f"TX-ROW-{index:06d}" for index in range(1, int(missing_ids.sum()) + 1)
        ]

    if OPTIONAL_LABEL_COLUMN in cleaned.columns:
        cleaned[OPTIONAL_LABEL_COLUMN] = (
            pd.to_numeric(cleaned[OPTIONAL_LABEL_COLUMN], errors="coerce")
            .fillna(0)
            .astype(int)
            .clip(0, 1)
        )
    if OPTIONAL_REASON_COLUMN not in cleaned.columns:
        cleaned[OPTIONAL_REASON_COLUMN] = ""
    cleaned[OPTIONAL_REASON_COLUMN] = cleaned[OPTIONAL_REASON_COLUMN].fillna("").astype(str)

    return add_engineered_features(cleaned)


def _safe_zscore(series: pd.Series) -> pd.Series:
    std = series.std(ddof=0)
    if std == 0 or np.isnan(std):
        return pd.Series(np.zeros(len(series)), index=series.index)
    return (series - series.mean()) / std


def add_engineered_features(df: pd.DataFrame) -> pd.DataFrame:
    featured = df.copy()
    amount = featured["tutar"].astype(float)

    featured["tutar_zscore"] = _safe_zscore(amount).fillna(0.0)

    category_mean = featured.groupby("kategori")["tutar"].transform("mean")
    category_std = featured.groupby("kategori")["tutar"].transform(lambda values: values.std(ddof=0))
    featured["kategori_ortalama_sapmasi"] = (
        (amount - category_mean) / category_std.replace(0, np.nan)
    ).replace([np.inf, -np.inf], np.nan).fillna(0.0)

    department_mean = featured.groupby("departman")["tutar"].transform("mean")
    department_std = featured.groupby("departman")["tutar"].transform(lambda values: values.std(ddof=0))
    featured["departman_ortalama_sapmasi"] = (
        (amount - department_mean) / department_std.replace(0, np.nan)
    ).replace([np.inf, -np.inf], np.nan).fillna(0.0)

    featured["hafta_sonu_mu"] = featured["tarih"].dt.dayofweek.isin([5, 6]).astype(int)
    featured["tedarikci_islem_sayisi"] = featured.groupby("tedarikci")["tedarikci"].transform("size")
    featured["calisan_tedarikci_islem_sayisi"] = featured.groupby(["calisan", "tedarikci"])["tedarikci"].transform("size")
    featured["tekrar_tedarikci_tutar_sayisi"] = featured.groupby(["tedarikci", "tutar"])["tutar"].transform("size")
    featured["yuvarlak_tutar_mi"] = (amount.mod(100).abs() < 0.01).astype(int)
    featured["aciklama_uzunlugu"] = featured["aciklama"].astype(str).str.len()
    featured["saat"] = featured["tarih"].dt.hour.astype(int)
    has_explicit_time = featured["saat"].ne(0)
    featured["mesai_disi_mi"] = (
        has_explicit_time & ((featured["saat"] < 8) | (featured["saat"] >= 19))
    ).astype(int)
    featured["ay"] = featured["tarih"].dt.month.astype(int)
    featured["gun"] = featured["tarih"].dt.day.astype(int)

    return featured


def preprocess_file(
    input_path: str | Path = RAW_EXPENSES_PATH,
    output_path: str | Path | None = PROCESSED_EXPENSES_PATH,
) -> pd.DataFrame:
    raw = load_expense_file(input_path)
    processed = clean_expense_data(raw)
    if output_path is not None:
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        processed.to_csv(output_path, index=False)
    return processed


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Clean FinAnomaly expense data.")
    parser.add_argument("--input", default=str(RAW_EXPENSES_PATH), help="CSV/XLSX input path.")
    parser.add_argument("--output", default=str(PROCESSED_EXPENSES_PATH), help="Processed CSV output path.")
    return parser.parse_args()


def main() -> None:
    ensure_directories()
    args = parse_args()
    processed = preprocess_file(args.input, args.output)
    print(f"Processed {len(processed)} rows -> {args.output}")


if __name__ == "__main__":
    main()
