import csv
import random
import sys
from datetime import date, timedelta
from pathlib import Path


if __package__ is None or __package__ == "":
    sys.path.insert(0, str(Path(__file__).resolve().parents[4]))

from applications.finanomaly.src.config import (
    FINAL_DEMO_DATA_PATH,
    OPTIONAL_LABEL_COLUMN,
    OPTIONAL_REASON_COLUMN,
    RAW_DATA_DIR,
    RAW_EXPENSES_PATH,
    ensure_directories,
)


HEADERS = [
    "calisan",
    "departman",
    "tarih",
    "tutar",
    "kategori",
    "tedarikci",
    "odeme_tipi",
    "aciklama",
    OPTIONAL_LABEL_COLUMN,
    OPTIONAL_REASON_COLUMN,
]


EMPLOYEES = [
    ("Ayse Kaya", "Satis"),
    ("Mehmet Demir", "Finans"),
    ("Elif Yilmaz", "Muhendislik"),
    ("Cem Arslan", "Operasyon"),
    ("Deniz Sahin", "IK"),
    ("Mert Aydin", "Satis"),
    ("Selin Kaplan", "Finans"),
    ("Can Polat", "Muhendislik"),
]

CATEGORY_PROFILES = {
    "Ulasim": (180, 90, ["TaxiPro", "MetroLine", "RailFast"]),
    "Yemek": (320, 120, ["YemekNet", "CafePlus", "LunchBox"]),
    "Konaklama": (1850, 650, ["OtelPlus", "StayInn", "CityHotel"]),
    "Ofis": (650, 250, ["OfficeMart", "KirtasiyePro", "SupplyHub"]),
    "Yazilim": (1400, 450, ["CloudSoft", "DevTools", "SaaSMarket"]),
    "Egitim": (950, 300, ["AcademyPro", "EduLab", "WorkshopCo"]),
}

PAYMENT_TYPES = ["Sirket Karti", "Havale", "Nakit"]


def _normal_records(count: int = 72) -> list[dict[str, object]]:
    rng = random.Random(42)
    start = date(2026, 5, 1)
    records = []

    categories = list(CATEGORY_PROFILES)
    for index in range(count):
        employee, department = rng.choice(EMPLOYEES)
        category = rng.choice(categories)
        mean, spread, vendors = CATEGORY_PROFILES[category]
        amount = max(35, round(rng.gauss(mean, spread), 2))
        day = start + timedelta(days=rng.randrange(0, 52))
        vendor = rng.choice(vendors)
        payment = rng.choices(PAYMENT_TYPES, weights=[0.66, 0.24, 0.10], k=1)[0]

        records.append(
            {
                "calisan": employee,
                "departman": department,
                "tarih": day.isoformat(),
                "tutar": amount,
                "kategori": category,
                "tedarikci": vendor,
                "odeme_tipi": payment,
                "aciklama": f"{category} gideri #{index + 1}",
                OPTIONAL_LABEL_COLUMN: 0,
                OPTIONAL_REASON_COLUMN: "",
            }
        )

    return records


def _anomaly_records() -> list[dict[str, object]]:
    duplicate_records = []
    for index, employee in enumerate(["Ayse Kaya", "Mert Aydin", "Elif Yilmaz", "Cem Arslan"]):
        duplicate_records.append(
            {
                "calisan": employee,
                "departman": "Satis" if index < 2 else "Operasyon",
                "tarih": (date(2026, 6, 13) + timedelta(days=index)).isoformat(),
                "tutar": 2900.00,
                "kategori": "Danismanlik",
                "tedarikci": "ConsultingX",
                "odeme_tipi": "Havale",
                "aciklama": "Ayni tedarikci ayni tutar",
                OPTIONAL_LABEL_COLUMN: 1,
                OPTIONAL_REASON_COLUMN: "duplicate_vendor_amount",
            }
        )

    return [
        {
            "calisan": "Mehmet Demir",
            "departman": "Finans",
            "tarih": "2026-06-14",
            "tutar": 16800.00,
            "kategori": "Konaklama",
            "tedarikci": "LuxuryStay",
            "odeme_tipi": "Nakit",
            "aciklama": "Hafta sonu yuksek konaklama",
            OPTIONAL_LABEL_COLUMN: 1,
            OPTIONAL_REASON_COLUMN: "weekend_high_amount",
        },
        {
            "calisan": "Selin Kaplan",
            "departman": "Finans",
            "tarih": "2026-06-19",
            "tutar": 12500.00,
            "kategori": "Elektronik",
            "tedarikci": "TechNova",
            "odeme_tipi": "Havale",
            "aciklama": "Tek seferde elektronik alim",
            OPTIONAL_LABEL_COLUMN: 1,
            OPTIONAL_REASON_COLUMN: "category_outlier",
        },
        {
            "calisan": "Can Polat",
            "departman": "Muhendislik",
            "tarih": "2026-06-20",
            "tutar": 4500.00,
            "kategori": "Yazilim",
            "tedarikci": "UnknownVendor",
            "odeme_tipi": "Nakit",
            "aciklama": "",
            OPTIONAL_LABEL_COLUMN: 1,
            OPTIONAL_REASON_COLUMN: "missing_description_cash",
        },
        *duplicate_records,
    ]


def _sprint_three_records() -> dict[str, list[dict[str, object]]]:
    weekend_payment = [
        {
            "calisan": "Mehmet Demir",
            "departman": "Finans",
            "tarih": "2026-06-14 22:35:00",
            "tutar": 16800.00,
            "kategori": "Konaklama",
            "tedarikci": "LuxuryStay",
            "odeme_tipi": "Nakit",
            "aciklama": "Hafta sonu gece girilen konaklama odemesi",
            OPTIONAL_LABEL_COLUMN: 1,
            OPTIONAL_REASON_COLUMN: "weekend_high_amount",
        }
    ]
    representation_outlier = [
        {
            "calisan": "Ayse Kaya",
            "departman": "Satis",
            "tarih": "2026-06-18 14:20:00",
            "tutar": 24500.00,
            "kategori": "Temsil",
            "tedarikci": "Eventique",
            "odeme_tipi": "Sirket Karti",
            "aciklama": "Musteri temsil organizasyonu",
            OPTIONAL_LABEL_COLUMN: 1,
            OPTIONAL_REASON_COLUMN: "representation_category_outlier",
        }
    ]
    duplicate_vendor = []
    for index, employee in enumerate(["Ayse Kaya", "Mert Aydin", "Ayse Kaya"]):
        duplicate_vendor.append(
            {
                "calisan": employee,
                "departman": "Satis",
                "tarih": f"2026-06-{16 + index:02d} 11:15:00",
                "tutar": 4900.00,
                "kategori": "Danismanlik",
                "tedarikci": "GrowthPartner",
                "odeme_tipi": "Havale",
                "aciklama": "Satis kanal danismanligi",
                OPTIONAL_LABEL_COLUMN: 1,
                OPTIONAL_REASON_COLUMN: "sales_duplicate_vendor",
            }
        )
    return {
        "weekend_payment": weekend_payment,
        "representation_outlier": representation_outlier,
        "sales_duplicate": duplicate_vendor,
    }


def write_csv(path: Path, records: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=HEADERS)
        writer.writeheader()
        writer.writerows(records)


def build_datasets() -> dict[Path, list[dict[str, object]]]:
    normal = _normal_records()
    anomalies = _anomaly_records()
    sprint_three = _sprint_three_records()
    final_demo_anomalies = (
        sprint_three["sales_duplicate"]
        + sprint_three["representation_outlier"]
        + sprint_three["weekend_payment"]
    )

    return {
        RAW_EXPENSES_PATH: normal + anomalies,
        FINAL_DEMO_DATA_PATH: normal + final_demo_anomalies,
        RAW_DATA_DIR / "scenario_normal.csv": normal[:28],
        RAW_DATA_DIR / "scenario_weekend_spike.csv": normal[:28] + anomalies[:1],
        RAW_DATA_DIR / "scenario_duplicate_vendor.csv": normal[:28] + anomalies[3:],
        RAW_DATA_DIR / "scenario_department_outlier.csv": normal[:28] + anomalies[1:2],
        RAW_DATA_DIR / "scenario_vendor_burst.csv": normal[:28] + anomalies[3:],
        RAW_DATA_DIR / "scenario_suspicious_description.csv": normal[:28] + anomalies[2:3],
        RAW_DATA_DIR / "sprint3_sales_duplicate.csv": (
            normal[:28] + sprint_three["sales_duplicate"]
        ),
        RAW_DATA_DIR / "sprint3_representation_outlier.csv": (
            normal[:28] + sprint_three["representation_outlier"]
        ),
        RAW_DATA_DIR / "sprint3_weekend_payment.csv": (
            normal[:28] + sprint_three["weekend_payment"]
        ),
    }


def generate_sample_data(verbose: bool = True) -> None:
    ensure_directories()
    for path, records in build_datasets().items():
        write_csv(path, records)
        if verbose:
            print(f"Wrote {len(records)} rows to {path}")


def main() -> None:
    generate_sample_data(verbose=True)


if __name__ == "__main__":
    main()
