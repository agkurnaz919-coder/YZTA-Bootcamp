from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from applications.finanomaly.src.config import AUDIT_TRAIL_PATH, OPTIONAL_LABEL_COLUMN
from applications.finanomaly.src.security.audit import AuditEvent, HashChainAuditSink, build_audit_sink


def apply_label_feedback(
    scored: pd.DataFrame,
    feedback: pd.DataFrame,
    reviewer: str = "auditor",
) -> tuple[pd.DataFrame, pd.DataFrame]:
    required = {"islem_id", OPTIONAL_LABEL_COLUMN}
    missing = sorted(required.difference(feedback.columns))
    if missing:
        raise ValueError(f"Geri bildirim için eksik kolonlar: {', '.join(missing)}")

    updated = scored.copy()
    if OPTIONAL_LABEL_COLUMN not in updated:
        updated[OPTIONAL_LABEL_COLUMN] = 0
    new_labels = (
        feedback[["islem_id", OPTIONAL_LABEL_COLUMN]]
        .drop_duplicates("islem_id", keep="last")
        .set_index("islem_id")[OPTIONAL_LABEL_COLUMN]
    )
    previous = updated.set_index("islem_id")[OPTIONAL_LABEL_COLUMN]
    changed_ids = [
        transaction_id
        for transaction_id in new_labels.index.intersection(previous.index)
        if int(new_labels.loc[transaction_id]) != int(previous.loc[transaction_id])
    ]

    label_mapping = pd.to_numeric(new_labels, errors="coerce").fillna(0).astype(int).clip(0, 1)
    updated[OPTIONAL_LABEL_COLUMN] = (
        updated["islem_id"]
        .map(label_mapping)
        .fillna(updated[OPTIONAL_LABEL_COLUMN])
        .astype(int)
        .clip(0, 1)
    )

    changed_at = datetime.now(timezone.utc).isoformat()
    audit_rows = []
    for transaction_id in changed_ids:
        row = updated.loc[updated["islem_id"].eq(transaction_id)].iloc[0]
        audit_rows.append(
            {
                "degisiklik_zamani_utc": changed_at,
                "inceleyen": reviewer.strip() or "auditor",
                "islem_id": transaction_id,
                "onceki_etiket": int(previous.loc[transaction_id]),
                "yeni_etiket": int(label_mapping.loc[transaction_id]),
                "risk_skoru": float(row.get("risk_skoru", 0.0)),
                "neden_supheli": row.get("neden_supheli", ""),
            }
        )
    return updated, pd.DataFrame(audit_rows)


def append_audit_trail(
    audit_rows: pd.DataFrame,
    path: str | Path = AUDIT_TRAIL_PATH,
) -> None:
    """Append feedback as hash-chained events and optionally mirror them centrally."""
    if audit_rows.empty:
        return
    sink = build_audit_sink(path)
    for row in audit_rows.to_dict(orient="records"):
        sink.emit(
            AuditEvent(
                event_type="transaction.label_changed",
                actor=str(row.get("inceleyen", "auditor")),
                target_id=str(row.get("islem_id", "")),
                occurred_at_utc=str(row.get("degisiklik_zamani_utc", "")),
                payload={
                    "onceki_etiket": int(row.get("onceki_etiket", 0)),
                    "yeni_etiket": int(row.get("yeni_etiket", 0)),
                    "risk_skoru": float(row.get("risk_skoru", 0.0)),
                    "neden_supheli": str(row.get("neden_supheli", "")),
                },
            )
        )


def append_audit_event(
    event_type: str,
    actor: str,
    *,
    target_id: str = "",
    payload: dict[str, object] | None = None,
    path: str | Path = AUDIT_TRAIL_PATH,
) -> dict[str, object]:
    return build_audit_sink(path).emit(
        AuditEvent(
            event_type=event_type,
            actor=actor,
            target_id=target_id,
            payload=payload or {},
        )
    )


def verify_audit_trail(path: str | Path = AUDIT_TRAIL_PATH) -> int:
    return HashChainAuditSink(path).verify()
