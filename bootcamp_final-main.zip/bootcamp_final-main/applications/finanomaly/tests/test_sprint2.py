import io
import pickle
import sys
import tempfile
import unittest
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from applications.finanomaly.src.data.generate_sample_data import generate_sample_data
from applications.finanomaly.src.data.preprocess import clean_expense_data
from applications.finanomaly.src.feedback import apply_label_feedback
from applications.finanomaly.src.model.evaluation import compare_model_scores, false_positive_summary
from applications.finanomaly.src.model.autoencoder import ReconstructionAutoencoder
from applications.finanomaly.src.model.service import (
    _MergedProjectUnpickler,
    score_dataframe_with_saved_model,
)
from applications.finanomaly.src.model.train_iforest import run_hybrid_dataframe_pipeline, score_with_model_bundle
from applications.finanomaly.src.reporting.explanations import build_transaction_detail
from applications.finanomaly.src.reporting.export import (
    csv_report_bytes,
    pdf_report_bytes,
    prepare_suspicious_report,
    xlsx_report_bytes,
)
from applications.finanomaly.src.rules.rules_engine import evaluate_rules


class SprintTwoAcceptanceTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        generate_sample_data(verbose=False)
        cls.raw = pd.read_csv(ROOT / "data" / "raw" / "expenses.csv")
        cls.scored, cls.evaluation, cls.bundle = run_hybrid_dataframe_pipeline(cls.raw)

    def test_autoencoder_and_hybrid_scores_are_produced(self) -> None:
        self.assertTrue(self.scored["autoencoder_skoru"].between(0, 1).all())
        self.assertTrue(self.scored["risk_skoru"].between(0, 1).all())
        comparison = compare_model_scores(self.scored)
        self.assertIn("hybrid_pr_auc", comparison)
        self.assertGreaterEqual(comparison["hybrid_pr_auc"], 0.5)

    def test_at_least_five_independent_rules_fire(self) -> None:
        rules = evaluate_rules(clean_expense_data(self.raw))
        fired = [column for column in rules if rules[column].any()]
        self.assertGreaterEqual(len(fired), 5)

    def test_every_high_risk_transaction_has_explanation_and_detail(self) -> None:
        high = self.scored[self.scored["risk_seviyesi"].eq("yuksek")]
        self.assertGreater(len(high), 0)
        self.assertFalse(high["neden_supheli"].str.strip().eq("").any())
        detail = build_transaction_detail(high.iloc[0])
        self.assertIn("skorlar", detail)
        self.assertIn("risk_faktorleri", detail)

    def test_saved_bundle_rescores_without_retraining(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            model_path = Path(directory) / "hybrid.pkl"
            with model_path.open("wb") as handle:
                pickle.dump(self.bundle, handle)
            rescored = score_dataframe_with_saved_model(self.raw.head(12), model_path)
        self.assertEqual(len(rescored), 12)
        self.assertIn("dinamik_yuksek_esik", rescored)

    def test_pre_merge_model_module_name_is_remapped(self) -> None:
        unpickler = _MergedProjectUnpickler(io.BytesIO())
        resolved = unpickler.find_class(
            "src.model.autoencoder",
            "ReconstructionAutoencoder",
        )
        self.assertIs(resolved, ReconstructionAutoencoder)

    def test_feedback_produces_audit_rows(self) -> None:
        target = self.scored.head(1)[["islem_id", "manuel_etiket"]].copy()
        target["manuel_etiket"] = 1 - target["manuel_etiket"]
        updated, audit = apply_label_feedback(self.scored, target, reviewer="test-auditor")
        self.assertEqual(len(audit), 1)
        self.assertEqual(audit.iloc[0]["inceleyen"], "test-auditor")
        self.assertNotEqual(
            int(updated.loc[updated["islem_id"].eq(target.iloc[0]["islem_id"]), "manuel_etiket"].iloc[0]),
            int(self.scored.loc[self.scored["islem_id"].eq(target.iloc[0]["islem_id"]), "manuel_etiket"].iloc[0]),
        )

    def test_csv_xlsx_and_pdf_reports_are_valid(self) -> None:
        report = prepare_suspicious_report(self.scored)
        self.assertGreater(len(report), 0)
        self.assertTrue(csv_report_bytes(report).startswith(b"\xef\xbb\xbf"))
        self.assertTrue(xlsx_report_bytes(report).startswith(b"PK"))
        self.assertTrue(pdf_report_bytes(report).startswith(b"%PDF-"))

    def test_extended_metrics_and_false_positive_analysis(self) -> None:
        self.assertIn("pr_auc", self.evaluation)
        self.assertIn("top_20_hit_rate", self.evaluation)
        analysis = false_positive_summary(self.scored)
        self.assertIn("yanlis_pozitif_orani", analysis)

    def test_five_sprint_two_scenarios_run_end_to_end(self) -> None:
        filenames = [
            "scenario_weekend_spike.csv",
            "scenario_duplicate_vendor.csv",
            "scenario_department_outlier.csv",
            "scenario_vendor_burst.csv",
            "scenario_suspicious_description.csv",
        ]
        for filename in filenames:
            with self.subTest(filename=filename):
                raw = pd.read_csv(ROOT / "data" / "raw" / filename)
                scored = score_with_model_bundle(clean_expense_data(raw), self.bundle)
                anomalies = scored.loc[scored["manuel_etiket"].eq(1)]
                self.assertGreater(len(anomalies), 0)
                self.assertTrue(anomalies["anomali_mi"].all())


if __name__ == "__main__":
    unittest.main()
