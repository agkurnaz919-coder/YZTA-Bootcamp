import unittest
from pathlib import Path
from unittest.mock import Mock, patch

import pandas as pd

from streamlit.testing.v1 import AppTest

from applications.finanomaly.src.ui import app as ui_app


ROOT = Path(__file__).resolve().parents[1]


class StreamlitDashboardSmokeTest(unittest.TestCase):
    def test_dashboard_renders_without_runtime_exception(self) -> None:
        app = AppTest.from_file(str(ROOT / "src" / "ui" / "app.py"))
        app.run(timeout=30)

        self.assertFalse(app.exception)
        self.assertGreaterEqual(len(app.metric), 4)
        self.assertGreaterEqual(len(app.dataframe), 2)

    def test_incompatible_saved_model_falls_back_to_session_training(self) -> None:
        raw = pd.DataFrame({"row": [1]})
        expected = pd.DataFrame({"risk_skoru": [0.5]})
        model_path = Mock()
        model_path.exists.return_value = True
        with (
            patch.object(ui_app, "HYBRID_MODEL_PATH", model_path),
            patch.object(
                ui_app,
                "score_dataframe_with_saved_model",
                side_effect=ModuleNotFoundError("legacy module"),
            ),
            patch.object(
                ui_app,
                "run_hybrid_dataframe_pipeline",
                return_value=(expected, {"recall": 1.0}, {}),
            ) as train,
        ):
            scored, evaluation, mode = ui_app.score_data(raw, use_saved_model=True)

        train.assert_called_once_with(raw)
        self.assertIs(scored, expected)
        self.assertEqual(evaluation, {"recall": 1.0})
        self.assertTrue(mode.startswith("Kayıtlı model uyumsuz"))


if __name__ == "__main__":
    unittest.main()
