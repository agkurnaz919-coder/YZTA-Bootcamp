import io
import json
import sys
import tempfile
import unittest
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from applications.finanomaly.src.config import MODEL_BUNDLE_VERSION, MODEL_VERSION, RULESET_VERSION
from applications.finanomaly.src.data.generate_sample_data import generate_sample_data
from applications.finanomaly.src.data.preprocess import (
    CorruptExpenseFileError,
    EmptyExpenseFileError,
    MissingExpenseColumnsError,
    UnsupportedExpenseFileError,
    clean_expense_data,
    load_expense_file,
)
from applications.finanomaly.src.model.train_iforest import run_hybrid_dataframe_pipeline
from applications.finanomaly.src.reporting.export import prepare_suspicious_report
from applications.finanomaly.src.security.audit import AuditEvent, AuditIntegrityError, HashChainAuditSink
from applications.finanomaly.src.security.auth import Permission, Role, demo_user, user_from_oidc_claims
from applications.finanomaly.src.security.privacy import mask_sensitive_data


class SprintThreeAcceptanceTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        generate_sample_data(verbose=False)
        cls.raw = pd.read_csv(ROOT / "data" / "raw" / "finanomaly_final_demo.csv")
        cls.scored, cls.evaluation, cls.bundle = run_hybrid_dataframe_pipeline(cls.raw)

    def test_empty_and_missing_column_files_have_actionable_errors(self) -> None:
        with self.assertRaisesRegex(EmptyExpenseFileError, "boş"):
            load_expense_file(io.BytesIO(b""), name="empty.csv")
        with self.assertRaises(CorruptExpenseFileError):
            load_expense_file(io.BytesIO(b"\xff\xfe\x00\x00"), name="broken.csv")
        with self.assertRaises(UnsupportedExpenseFileError):
            load_expense_file(io.BytesIO(b"not-an-expense"), name="expense.txt")

        incomplete = pd.DataFrame({"calisan": ["Ayse"], "tutar": [100]})
        with self.assertRaises(MissingExpenseColumnsError) as raised:
            clean_expense_data(incomplete)
        self.assertIn("Eksik zorunlu kolonlar", str(raised.exception))
        self.assertIn("departman", raised.exception.missing)

    def test_bundle_and_rows_expose_version_and_performance_profile(self) -> None:
        self.assertEqual(self.bundle["bundle_version"], MODEL_BUNDLE_VERSION)
        self.assertEqual(self.bundle["model_version"], MODEL_VERSION)
        self.assertEqual(self.bundle["ruleset_version"], RULESET_VERSION)
        self.assertGreater(self.bundle["performance_profile"]["feature_count"], 0)
        self.assertGreater(self.bundle["performance_profile"]["reference_rows_per_second"], 0)
        self.assertTrue(self.scored["model_surumu"].eq(MODEL_VERSION).all())
        self.assertTrue(self.scored["kural_surumu"].eq(RULESET_VERSION).all())
        self.assertGreater(self.scored.attrs["runtime_profile"]["rows_per_second"], 0)
        report = prepare_suspicious_report(self.scored)
        self.assertIn("model_surumu", report)
        self.assertIn("kural_surumu", report)

    def test_roles_enforce_separation_of_duties(self) -> None:
        viewer = demo_user([Role.VIEWER])
        auditor = demo_user([Role.AUDITOR])
        manager = demo_user([Role.AUDIT_MANAGER])
        system_admin = demo_user([Role.SYSTEM_ADMIN])

        self.assertTrue(viewer.can(Permission.VIEW_DASHBOARD))
        self.assertFalse(viewer.can(Permission.VIEW_PII))
        self.assertTrue(auditor.can(Permission.LABEL_TRANSACTION))
        self.assertFalse(auditor.can(Permission.EXPORT_REPORT))
        self.assertTrue(manager.can(Permission.EXPORT_REPORT))
        self.assertFalse(system_admin.can(Permission.LABEL_TRANSACTION))

    def test_oidc_claims_map_only_known_roles(self) -> None:
        user = user_from_oidc_claims(
            {
                "sub": "oidc-123",
                "name": "Test User",
                "roles": ["auditor", "untrusted-role"],
            }
        )
        self.assertEqual(user.roles, (Role.AUDITOR,))
        self.assertEqual(user.subject, "oidc-123")

    def test_pii_masking_is_stable_and_does_not_mutate_source(self) -> None:
        source = self.scored.head(3)
        masked = mask_sensitive_data(source, secret="test-secret")
        masked_again = mask_sensitive_data(source, secret="test-secret")

        self.assertTrue(masked["calisan"].str.startswith("Çalışan-").all())
        self.assertTrue(masked["tedarikci"].str.startswith("Tedarikçi-").all())
        self.assertTrue(masked["aciklama"].str.contains("maskelendi|yok").all())
        self.assertListEqual(masked["calisan"].tolist(), masked_again["calisan"].tolist())
        self.assertFalse(source["calisan"].str.startswith("Çalışan-").any())

    def test_hash_chained_audit_log_detects_tampering(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "audit.jsonl"
            sink = HashChainAuditSink(path)
            sink.emit(AuditEvent("transaction.viewed", "auditor", "TX-1"))
            sink.emit(AuditEvent("transaction.label_changed", "auditor", "TX-1"))
            self.assertEqual(sink.verify(), 2)

            records = path.read_text(encoding="utf-8").splitlines()
            first = json.loads(records[0])
            first["actor"] = "tampered-user"
            records[0] = json.dumps(first)
            path.write_text("\n".join(records) + "\n", encoding="utf-8")
            with self.assertRaises(AuditIntegrityError):
                sink.verify()

    def test_three_final_demo_scenarios_are_detected(self) -> None:
        for filename in [
            "sprint3_sales_duplicate.csv",
            "sprint3_representation_outlier.csv",
            "sprint3_weekend_payment.csv",
        ]:
            with self.subTest(filename=filename):
                frame = pd.read_csv(ROOT / "data" / "raw" / filename)
                scored, _evaluation, _bundle = run_hybrid_dataframe_pipeline(frame)
                expected = scored.loc[scored["manuel_etiket"].eq(1)]
                self.assertGreater(len(expected), 0)
                self.assertTrue(expected["anomali_mi"].all())
                self.assertFalse(expected["neden_supheli"].str.strip().eq("").any())


if __name__ == "__main__":
    unittest.main()
