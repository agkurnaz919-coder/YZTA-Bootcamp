import sys
import unittest
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from applications.finanomaly.src.config import RAW_EXPENSES_PATH, REQUIRED_COLUMNS
from applications.finanomaly.src.data.generate_sample_data import generate_sample_data
from applications.finanomaly.src.data.preprocess import clean_expense_data
from applications.finanomaly.src.model.train_iforest import run_dataframe_pipeline, top_suspicious


class FinAnomalyPipelineTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        generate_sample_data(verbose=False)

    def test_preprocess_adds_required_features(self) -> None:
        raw = pd.read_csv(RAW_EXPENSES_PATH)
        processed = clean_expense_data(raw)

        for column in REQUIRED_COLUMNS:
            self.assertIn(column, processed.columns)
        self.assertIn("tutar_zscore", processed.columns)
        self.assertIn("kategori_ortalama_sapmasi", processed.columns)
        self.assertIn("hafta_sonu_mu", processed.columns)
        self.assertFalse(processed["tutar"].isna().any())

    def test_pipeline_scores_transactions(self) -> None:
        raw = pd.read_csv(RAW_EXPENSES_PATH)
        scored, evaluation, _model = run_dataframe_pipeline(raw)

        self.assertEqual(len(raw), len(scored))
        self.assertTrue(scored["risk_skoru"].between(0, 1).all())
        self.assertTrue(set(scored["risk_seviyesi"]).issubset({"dusuk", "orta", "yuksek"}))
        self.assertGreater(scored["anomali_mi"].sum(), 0)
        self.assertIsNotNone(evaluation)
        self.assertGreaterEqual(evaluation["recall"], 0.5)

    def test_top_suspicious_limit(self) -> None:
        raw = pd.read_csv(RAW_EXPENSES_PATH)
        scored, _evaluation, _model = run_dataframe_pipeline(raw)
        top_rows = top_suspicious(scored, limit=20)

        self.assertLessEqual(len(top_rows), 20)
        self.assertTrue(top_rows["risk_skoru"].is_monotonic_decreasing)

    def test_missing_category_and_payment_are_normalized(self) -> None:
        raw = pd.read_csv(RAW_EXPENSES_PATH).head(3)
        raw.loc[0, "kategori"] = None
        raw.loc[1, "odeme_tipi"] = None
        processed = clean_expense_data(raw)

        self.assertEqual(processed.loc[0, "kategori"], "Bilinmiyor")
        self.assertEqual(processed.loc[1, "odeme_tipi"], "Bilinmiyor")


if __name__ == "__main__":
    unittest.main()
