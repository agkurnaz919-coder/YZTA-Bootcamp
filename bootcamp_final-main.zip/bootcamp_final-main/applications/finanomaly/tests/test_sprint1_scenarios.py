import sys
import unittest
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from applications.finanomaly.src.data.generate_sample_data import generate_sample_data
from applications.finanomaly.src.model.train_iforest import run_dataframe_pipeline


class SprintOneDemoScenarioTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        generate_sample_data(verbose=False)

    def _score(self, filename: str) -> pd.DataFrame:
        raw = pd.read_csv(ROOT / "data" / "raw" / filename)
        scored, _evaluation, _model = run_dataframe_pipeline(raw)
        return scored

    def test_normal_scenario_runs_end_to_end(self) -> None:
        scored = self._score("scenario_normal.csv")
        self.assertEqual(len(scored), 28)
        self.assertTrue(scored["risk_skoru"].between(0, 1).all())

    def test_weekend_spike_is_detected_end_to_end(self) -> None:
        scored = self._score("scenario_weekend_spike.csv")
        anomaly = scored.loc[scored["manuel_etiket"].eq(1)].iloc[0]
        self.assertTrue(anomaly["anomali_mi"])
        self.assertIn("Hafta sonu", anomaly["kural_ihlalleri"])

    def test_duplicate_vendor_is_detected_end_to_end(self) -> None:
        scored = self._score("scenario_duplicate_vendor.csv")
        anomalies = scored.loc[scored["manuel_etiket"].eq(1)]
        self.assertTrue(anomalies["anomali_mi"].all())
        self.assertTrue(anomalies["kural_ihlalleri"].str.contains("tekrar|çoklu", case=False).all())
