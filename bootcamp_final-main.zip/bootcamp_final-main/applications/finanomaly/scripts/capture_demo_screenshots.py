import argparse
from pathlib import Path

from playwright.sync_api import sync_playwright


DEFAULT_CHROME_PATH = Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome")


def capture_demo(url: str, output_dir: Path, chrome_path: Path) -> list[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    captures = [
        (
            "01-risk-dashboard.png",
            "Risk panosu",
            "Öncelikli inceleme kuyruğu",
        ),
        (
            "02-transaction-detail.png",
            "İşlem detayı",
            "İşlem bilgileri",
        ),
        (
            "03-feedback-reporting.png",
            "Geri bildirim & rapor",
            "Denetçi geri bildirimi",
        ),
        (
            "04-model-quality.png",
            "Model kalitesi",
            "Sürüm ve performans profili",
        ),
    ]
    generated: list[Path] = []

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(
            executable_path=str(chrome_path),
            headless=True,
            args=["--no-sandbox"],
        )
        page = browser.new_page(
            viewport={"width": 1440, "height": 1100},
            device_scale_factor=1,
        )
        page.goto(url, wait_until="networkidle", timeout=60_000)

        for filename, tab_name, ready_text in captures:
            page.get_by_role("tab", name=tab_name, exact=True).click()
            page.get_by_text(ready_text, exact=True).wait_for(timeout=30_000)
            page.wait_for_timeout(600)
            target = output_dir / filename
            page.screenshot(path=str(target), full_page=False)
            generated.append(target)

        browser.close()

    return generated


def main() -> None:
    parser = argparse.ArgumentParser(description="Capture FinAnomaly Sprint 3 demo screens.")
    parser.add_argument("--url", default="http://127.0.0.1:8765")
    parser.add_argument("--output-dir", default="docs/screenshots/sprint3")
    parser.add_argument("--chrome-path", default=str(DEFAULT_CHROME_PATH))
    args = parser.parse_args()

    paths = capture_demo(
        url=args.url,
        output_dir=Path(args.output_dir),
        chrome_path=Path(args.chrome_path),
    )
    for path in paths:
        print(path)


if __name__ == "__main__":
    main()
