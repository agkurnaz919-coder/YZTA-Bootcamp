"""Shared visual system for the unified Streamlit workspace.

The three products keep their own information architecture, while this module
provides one deliberately quiet set of surfaces, type, controls, and charts.
"""

from __future__ import annotations

import html

import streamlit as st


CANVAS = "#D4DED9"
SIDEBAR = "#C7D4CD"
SURFACE = "#E8EEEB"
SURFACE_MUTED = "#DCE5E0"
BORDER = "#B7C6BE"
BORDER_STRONG = "#99ACA2"
TEXT = "#17212B"
# Dark enough to keep secondary copy at WCAG AA contrast on every shared
# surface, including the slightly darker sidebar and page canvas.
TEXT_MUTED = "#4E5B66"
ACCENT = "#176B5B"
ACCENT_HOVER = "#125749"
ACCENT_TINT = "#CFE2DB"
INFO = "#315E81"
INFO_TINT = "#EDF4F8"
WARNING = "#9A5A12"
WARNING_TINT = "#FFF5E7"
DANGER = "#B5473C"
DANGER_TINT = "#FCEFED"
SUCCESS = "#287A5B"
SUCCESS_TINT = "#ECF6F1"


def apply_theme() -> None:
    """Apply the shared minimal theme to the current Streamlit page."""

    st.markdown(
        f"""
        <style>
        :root {{
            --ri-canvas: {CANVAS};
            --ri-sidebar: {SIDEBAR};
            --ri-surface: {SURFACE};
            --ri-surface-muted: {SURFACE_MUTED};
            --ri-border: {BORDER};
            --ri-border-strong: {BORDER_STRONG};
            --ri-text: {TEXT};
            --ri-muted: {TEXT_MUTED};
            --ri-accent: {ACCENT};
            --ri-accent-hover: {ACCENT_HOVER};
            --ri-accent-tint: {ACCENT_TINT};
        }}

        html, body, [data-testid="stAppViewContainer"], [data-testid="stApp"] {{
            background: var(--ri-canvas) !important;
            color: var(--ri-text) !important;
            font-family: Inter, ui-sans-serif, -apple-system, BlinkMacSystemFont,
                "Segoe UI", sans-serif !important;
        }}

        [data-testid="stHeader"] {{
            background: color-mix(in srgb, var(--ri-canvas) 92%, transparent) !important;
        }}

        .block-container {{
            width: 100%;
            max-width: 1320px;
            padding-top: 1.75rem !important;
            padding-bottom: 3rem !important;
        }}

        h1, h2, h3, h4 {{
            color: var(--ri-text) !important;
            font-family: inherit !important;
            font-weight: 650 !important;
            letter-spacing: -0.025em !important;
        }}

        p, li, label, [data-testid="stMarkdownContainer"] {{
            color: var(--ri-text);
        }}

        [data-testid="stCaptionContainer"], .stCaption {{
            color: var(--ri-muted) !important;
        }}

        [data-testid="stSidebar"] {{
            background: var(--ri-sidebar) !important;
            border-right: 1px solid var(--ri-border) !important;
        }}

        [data-testid="stSidebarHeader"] {{
            height: 76px !important;
        }}

        [data-testid="stSidebarLogo"] {{
            width: 12.75rem !important;
            height: auto !important;
            max-width: 100% !important;
            margin: 0 !important;
            object-fit: contain !important;
        }}

        [data-testid="stSidebar"] [data-testid="stMarkdownContainer"] h3 {{
            margin: 1.4rem 0 .55rem !important;
            color: var(--ri-muted) !important;
            font-size: .72rem !important;
            font-weight: 700 !important;
            letter-spacing: .08em !important;
            text-transform: uppercase !important;
        }}

        [data-testid="stSidebar"] hr {{
            border-color: var(--ri-border) !important;
        }}

        [data-testid="stSidebar"] label,
        [data-testid="stSidebar"] p {{
            color: var(--ri-text) !important;
        }}

        [data-baseweb="input"] > div,
        [data-baseweb="select"] > div,
        [data-testid="stNumberInput"] input,
        [data-testid="stTextInput"] input {{
            background: var(--ri-surface) !important;
            border-color: var(--ri-border-strong) !important;
            border-radius: 8px !important;
            color: var(--ri-text) !important;
            box-shadow: none !important;
        }}

        .stButton > button,
        .stDownloadButton > button,
        button[kind="secondary"] {{
            min-height: 2.55rem;
            border: 1px solid var(--ri-border-strong) !important;
            border-radius: 8px !important;
            background: var(--ri-surface) !important;
            color: var(--ri-text) !important;
            box-shadow: none !important;
            font-weight: 600 !important;
            letter-spacing: 0 !important;
        }}

        .stButton > button:hover,
        .stDownloadButton > button:hover,
        button[kind="secondary"]:hover {{
            border-color: var(--ri-accent) !important;
            color: var(--ri-accent) !important;
        }}

        .stButton > button[kind="primary"],
        button[kind="primary"] {{
            border-color: var(--ri-accent) !important;
            background: var(--ri-accent) !important;
            color: #FFFFFF !important;
        }}

        .stButton > button[kind="primary"]:hover,
        button[kind="primary"]:hover {{
            border-color: var(--ri-accent-hover) !important;
            background: var(--ri-accent-hover) !important;
            color: #FFFFFF !important;
        }}

        [data-testid="stMetric"],
        [data-testid="metric-container"] {{
            min-height: 104px;
            padding: .95rem 1rem !important;
            border: 1px solid var(--ri-border) !important;
            border-radius: 10px !important;
            background: var(--ri-surface) !important;
            box-shadow: none !important;
        }}

        [data-testid="stMetricLabel"],
        [data-testid="stMetricLabel"] * {{
            color: var(--ri-muted) !important;
            font-size: .75rem !important;
            font-weight: 650 !important;
            letter-spacing: .02em !important;
            text-transform: none !important;
        }}

        [data-testid="stMetricValue"],
        [data-testid="stMetricValue"] * {{
            color: var(--ri-text) !important;
            font-family: inherit !important;
            font-size: 1.45rem !important;
            font-weight: 650 !important;
        }}

        [data-testid="stTabs"] [data-baseweb="tab-list"] {{
            gap: 1.35rem;
            padding: 0 !important;
            border-bottom: 1px solid var(--ri-border) !important;
            border-radius: 0 !important;
            background: transparent !important;
            box-shadow: none !important;
        }}

        [data-testid="stTabs"] [data-baseweb="tab"] {{
            padding: .65rem .05rem .75rem !important;
            border-radius: 0 !important;
            background: transparent !important;
            color: var(--ri-muted) !important;
            font-size: .84rem !important;
            font-weight: 600 !important;
        }}

        [data-testid="stTabs"] [aria-selected="true"] {{
            border-bottom: 2px solid var(--ri-accent) !important;
            background: transparent !important;
            color: var(--ri-accent) !important;
        }}

        [data-testid="stExpander"],
        [data-testid="stAlert"],
        [data-testid="stFileUploaderDropzone"] {{
            border: 1px solid var(--ri-border) !important;
            border-radius: 10px !important;
            background: var(--ri-surface) !important;
            box-shadow: none !important;
        }}

        [data-testid="stDataFrame"] {{
            overflow: hidden;
            border: 1px solid var(--ri-border);
            border-radius: 10px !important;
        }}

        hr {{
            border-color: var(--ri-border) !important;
        }}

        *:focus-visible {{
            outline: 2px solid var(--ri-accent) !important;
            outline-offset: 2px;
        }}

        ::selection {{
            background: var(--ri-accent-tint);
            color: var(--ri-text);
        }}

        .ri-page-header {{
            margin: 0 0 1.5rem;
            padding: .25rem 0 1.35rem;
            border-bottom: 1px solid var(--ri-border);
        }}

        .ri-page-header__kicker {{
            margin-bottom: .45rem;
            color: var(--ri-accent);
            font-size: .72rem;
            font-weight: 700;
            letter-spacing: .09em;
            text-transform: uppercase;
        }}

        .ri-page-header h1 {{
            margin: 0 0 .5rem;
            color: var(--ri-text) !important;
            font-size: clamp(1.85rem, 3vw, 2.55rem);
            line-height: 1.12;
        }}

        .ri-page-header p {{
            max-width: 760px;
            margin: 0;
            color: var(--ri-muted) !important;
            font-size: .98rem;
            line-height: 1.65;
        }}

        .ri-page-header__meta {{
            margin-top: .8rem;
            color: var(--ri-muted);
            font-size: .75rem;
        }}

        .ri-card {{
            height: 100%;
            min-height: 246px;
            box-sizing: border-box;
            padding: 1.2rem;
            border: 1px solid var(--ri-border);
            border-radius: 10px;
            background: var(--ri-surface);
            box-shadow: none;
        }}

        .ri-card h3 {{
            margin: .7rem 0 .45rem;
            font-size: 1.05rem;
        }}

        .ri-card p {{
            margin: 0;
            color: var(--ri-muted);
            font-size: .88rem;
            line-height: 1.6;
        }}

        .ri-label {{
            display: inline-flex;
            align-self: flex-start;
            padding: .2rem .5rem;
            border-radius: 5px;
            background: var(--ri-accent-tint);
            color: var(--ri-accent);
            font-size: .68rem;
            font-weight: 700;
            letter-spacing: .04em;
            text-transform: uppercase;
        }}

        .ri-home-hero {{
            position: relative;
            display: grid;
            grid-template-columns: minmax(0, 1.05fr) minmax(360px, .95fr);
            gap: clamp(2rem, 5vw, 4.5rem);
            align-items: center;
            margin: 0 0 2rem;
            padding: clamp(2.5rem, 6vw, 5.2rem) 0;
            border-bottom: 1px solid var(--ri-border);
            overflow: hidden;
        }}

        .ri-home-hero::before {{
            position: absolute;
            width: 620px;
            height: 620px;
            right: -260px;
            top: 50%;
            border: 1px solid color-mix(
                in srgb,
                var(--ri-accent) 14%,
                transparent
            );
            border-radius: 50%;
            content: "";
            transform: translateY(-50%);
            box-shadow:
                0 0 0 80px color-mix(in srgb, var(--ri-accent) 3%, transparent),
                0 0 0 160px color-mix(in srgb, var(--ri-accent) 2%, transparent);
            pointer-events: none;
        }}

        .ri-home-hero__content,
        .ri-risk-console {{
            position: relative;
            z-index: 1;
        }}

        .ri-home-hero__eyebrow {{
            display: inline-flex;
            align-items: center;
            gap: .55rem;
            margin-bottom: 1.15rem;
            padding: .36rem .7rem;
            border: 1px solid color-mix(
                in srgb,
                var(--ri-accent) 28%,
                var(--ri-border)
            );
            border-radius: 999px;
            background: var(--ri-accent-tint);
            color: var(--ri-accent);
            font-size: .66rem;
            font-weight: 750;
            letter-spacing: .06em;
            text-transform: uppercase;
        }}

        .ri-home-hero__eyebrow > span {{
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: var(--ri-accent);
            box-shadow: 0 0 0 4px color-mix(
                in srgb,
                var(--ri-accent) 12%,
                transparent
            );
        }}

        .ri-home-hero h1 {{
            max-width: 720px;
            margin: 0;
            font-size: clamp(2.35rem, 5vw, 4rem);
            line-height: 1.04;
            letter-spacing: -.045em !important;
        }}

        .ri-home-hero h1 span {{
            color: var(--ri-accent);
        }}

        .ri-home-hero__content > p {{
            max-width: 650px;
            margin: 1.25rem 0 0;
            color: var(--ri-muted) !important;
            font-size: .98rem;
            line-height: 1.7;
        }}

        .ri-home-hero__actions {{
            display: flex;
            flex-wrap: wrap;
            gap: .75rem;
            margin-top: 1.55rem;
        }}

        .ri-home-button {{
            display: inline-flex;
            min-height: 2.7rem;
            align-items: center;
            justify-content: center;
            gap: .45rem;
            padding: .65rem 1rem;
            border: 1px solid var(--ri-border-strong);
            border-radius: 8px;
            color: var(--ri-text) !important;
            font-size: .78rem;
            font-weight: 700;
            text-decoration: none !important;
            transition: border-color .18s ease, background .18s ease,
                color .18s ease, transform .18s ease;
        }}

        .ri-home-button--primary {{
            border-color: var(--ri-accent);
            background: var(--ri-accent);
            color: #FFFFFF !important;
        }}

        .ri-home-button--primary:hover {{
            border-color: var(--ri-accent-hover);
            background: var(--ri-accent-hover);
            transform: translateY(-2px);
        }}

        .ri-home-button--secondary {{
            background: var(--ri-surface);
        }}

        .ri-home-button--secondary:hover {{
            border-color: var(--ri-accent);
            color: var(--ri-accent) !important;
        }}

        .ri-home-hero__proof {{
            display: flex;
            flex-wrap: wrap;
            gap: .55rem 1.15rem;
            margin-top: 1.25rem;
        }}

        .ri-home-hero__proof span {{
            display: inline-flex;
            align-items: center;
            gap: .4rem;
            color: var(--ri-muted);
            font-size: .69rem;
            font-weight: 600;
        }}

        .ri-home-hero__proof span::before {{
            width: 5px;
            height: 5px;
            border-radius: 50%;
            background: var(--ri-accent);
            content: "";
        }}

        .ri-risk-console {{
            overflow: hidden;
            border: 1px solid var(--ri-border-strong);
            border-radius: 12px;
            background: color-mix(
                in srgb,
                var(--ri-surface) 92%,
                var(--ri-accent-tint)
            );
            box-shadow: 0 22px 48px rgba(23, 33, 43, .13);
        }}

        .ri-risk-console__header {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            padding: 1rem 1.1rem;
            border-bottom: 1px solid var(--ri-border);
            background: color-mix(
                in srgb,
                var(--ri-surface-muted) 82%,
                var(--ri-surface)
            );
        }}

        .ri-risk-console__header > div {{
            display: grid;
            gap: .12rem;
        }}

        .ri-risk-console__kicker {{
            color: var(--ri-muted);
            font-size: .62rem;
            font-weight: 700;
            letter-spacing: .07em;
            text-transform: uppercase;
        }}

        .ri-risk-console__header strong {{
            color: var(--ri-text);
            font-size: .84rem;
        }}

        .ri-risk-console__status {{
            display: inline-flex;
            align-items: center;
            gap: .42rem;
            padding: .32rem .55rem;
            border: 1px solid color-mix(
                in srgb,
                var(--ri-accent) 24%,
                var(--ri-border)
            );
            border-radius: 999px;
            color: var(--ri-accent);
            font-size: .63rem;
            font-weight: 700;
        }}

        .ri-risk-console__status i {{
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: var(--ri-accent);
        }}

        .ri-risk-console__body {{
            display: grid;
            gap: .65rem;
            padding: 1rem;
        }}

        .ri-console-row {{
            display: grid;
            grid-template-columns: auto minmax(0, 1fr) auto;
            gap: .75rem;
            align-items: center;
            padding: .8rem;
            border: 1px solid var(--ri-border);
            border-radius: 8px;
            background: var(--ri-surface);
        }}

        .ri-console-row__index {{
            display: grid;
            width: 30px;
            height: 30px;
            place-items: center;
            border-radius: 7px;
            background: var(--ri-accent-tint);
            color: var(--ri-accent);
            font-size: .62rem;
            font-weight: 750;
        }}

        .ri-console-row > div {{
            display: grid;
            gap: .1rem;
        }}

        .ri-console-row strong {{
            color: var(--ri-text);
            font-size: .78rem;
        }}

        .ri-console-row div > span {{
            color: var(--ri-muted);
            font-size: .66rem;
            line-height: 1.4;
        }}

        .ri-console-row__tag {{
            padding: .25rem .45rem;
            border-radius: 5px;
            background: var(--ri-surface-muted);
            color: var(--ri-muted);
            font-size: .58rem;
            font-weight: 700;
            letter-spacing: .03em;
            text-transform: uppercase;
        }}

        .ri-risk-console__footer {{
            display: flex;
            align-items: center;
            justify-content: center;
            gap: .55rem;
            padding: .8rem 1rem;
            border-top: 1px solid var(--ri-border);
            color: var(--ri-muted);
            font-size: .62rem;
            font-weight: 650;
        }}

        .ri-risk-console__footer i {{
            color: var(--ri-accent);
            font-style: normal;
        }}

        .ri-home-section {{
            padding: .35rem 0 1.75rem;
        }}

        .ri-home-section--workflow {{
            padding-top: 1.75rem;
            border-top: 1px solid var(--ri-border);
        }}

        .ri-home-section--platform,
        .ri-home-section--roles {{
            padding-top: 1.75rem;
            border-top: 1px solid var(--ri-border);
        }}

        .ri-home-section__heading {{
            display: flex;
            align-items: flex-end;
            justify-content: space-between;
            gap: 2rem;
            margin-bottom: 1rem;
        }}

        .ri-home-section__heading h2 {{
            margin: .15rem 0 0;
            font-size: 1.28rem;
            line-height: 1.25;
        }}

        .ri-home-section__heading > p {{
            max-width: 520px;
            margin: 0;
            color: var(--ri-muted);
            font-size: .82rem;
            line-height: 1.55;
        }}

        .ri-home-section__eyebrow {{
            color: var(--ri-accent);
            font-size: .68rem;
            font-weight: 700;
            letter-spacing: .07em;
            text-transform: uppercase;
        }}

        .ri-home-section__heading--centered {{
            display: grid;
            grid-template-columns: 1fr;
            gap: .45rem;
            justify-content: stretch;
            justify-items: center;
            text-align: center;
        }}

        .ri-home-section__heading--centered > p {{
            max-width: 620px;
            margin-right: auto;
            margin-left: auto;
        }}

        .ri-solution-grid {{
            display: grid;
            grid-template-columns: repeat(
                auto-fit,
                minmax(min(100%, 16rem), 1fr)
            );
            gap: 1.1rem;
            align-items: stretch;
        }}

        .ri-solution-card {{
            display: flex;
            min-height: 286px;
            box-sizing: border-box;
            flex-direction: column;
            padding: 1.25rem;
            border: 1px solid var(--ri-border);
            border-radius: 10px;
            background: var(--ri-surface);
            color: var(--ri-text) !important;
            text-decoration: none !important;
            box-shadow: 0 1px 2px rgba(23, 33, 43, .03);
            transition: border-color .18s ease, box-shadow .18s ease,
                transform .18s ease;
        }}

        .ri-solution-card:hover {{
            border-color: color-mix(in srgb, var(--ri-accent) 52%, var(--ri-border));
            box-shadow: 0 10px 24px rgba(23, 33, 43, .08);
            transform: translateY(-3px);
        }}

        .ri-solution-card:focus-visible {{
            border-color: var(--ri-accent);
        }}

        .ri-solution-card h3 {{
            margin: .8rem 0 .35rem;
            font-size: 1.08rem;
        }}

        .ri-solution-card__promise {{
            display: block;
            color: var(--ri-text);
            font-size: .9rem;
            font-weight: 650;
            line-height: 1.45;
        }}

        .ri-solution-card p {{
            margin: .6rem 0 0;
            color: var(--ri-muted) !important;
            font-size: .81rem;
            line-height: 1.55;
        }}

        .ri-solution-card__outputs {{
            display: block;
            margin-top: auto;
            padding-top: 1rem;
            color: var(--ri-muted);
            font-size: .7rem;
            font-weight: 600;
            line-height: 1.45;
        }}

        .ri-solution-card__cta {{
            display: inline-flex;
            align-items: center;
            gap: .35rem;
            margin-top: .7rem;
            color: var(--ri-accent);
            font-size: .79rem;
            font-weight: 700;
        }}

        .ri-solution-card__cta span {{
            transition: transform .18s ease;
        }}

        .ri-solution-card:hover .ri-solution-card__cta span {{
            transform: translateX(3px);
        }}

        .ri-workflow-grid {{
            display: grid;
            grid-template-columns: repeat(
                auto-fit,
                minmax(min(100%, 13rem), 1fr)
            );
            gap: .85rem;
        }}

        .ri-workflow-step {{
            padding: 1rem;
            border: 1px solid var(--ri-border);
            border-radius: 9px;
            background: var(--ri-surface-muted);
        }}

        .ri-workflow-step__number {{
            color: var(--ri-accent);
            font-size: .68rem;
            font-weight: 750;
            letter-spacing: .07em;
        }}

        .ri-workflow-step h3 {{
            margin: .35rem 0 .3rem;
            font-size: .91rem;
        }}

        .ri-workflow-step p {{
            margin: 0;
            color: var(--ri-muted) !important;
            font-size: .77rem;
            line-height: 1.5;
        }}

        .ri-platform-flow {{
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: .8rem;
        }}

        .ri-platform-stage {{
            position: relative;
            min-height: 148px;
            padding: 1rem;
            border: 1px solid var(--ri-border);
            border-top: 3px solid var(--ri-border-strong);
            border-radius: 9px;
            background: var(--ri-surface);
        }}

        .ri-platform-stage--engines {{
            border-top-color: var(--ri-accent);
            background: color-mix(
                in srgb,
                var(--ri-accent-tint) 62%,
                var(--ri-surface)
            );
        }}

        .ri-platform-stage__number {{
            display: block;
            margin-bottom: .55rem;
            color: var(--ri-accent);
            font-size: .62rem;
            font-weight: 750;
            letter-spacing: .05em;
            text-transform: uppercase;
        }}

        .ri-platform-stage strong {{
            display: block;
            color: var(--ri-text);
            font-size: .82rem;
        }}

        .ri-platform-stage p {{
            margin: .35rem 0 0;
            color: var(--ri-muted) !important;
            font-size: .7rem;
            line-height: 1.5;
        }}

        .ri-platform-stage__chips {{
            display: flex;
            flex-wrap: wrap;
            gap: .3rem;
            margin-top: .55rem;
        }}

        .ri-platform-stage__chips span {{
            padding: .18rem .35rem;
            border: 1px solid color-mix(
                in srgb,
                var(--ri-accent) 24%,
                var(--ri-border)
            );
            border-radius: 4px;
            color: var(--ri-accent);
            font-size: .56rem;
            font-weight: 700;
        }}

        .ri-role-grid {{
            display: grid;
            grid-template-columns: repeat(
                auto-fit,
                minmax(min(100%, 17rem), 1fr)
            );
            gap: .85rem;
        }}

        .ri-role-card {{
            display: flex;
            gap: .85rem;
            padding: 1rem;
            border: 1px solid var(--ri-border);
            border-radius: 9px;
            background: var(--ri-surface);
        }}

        .ri-role-card__icon {{
            display: grid;
            width: 32px;
            height: 32px;
            flex: 0 0 32px;
            place-items: center;
            border-radius: 7px;
            background: var(--ri-accent-tint);
            color: var(--ri-accent);
            font-size: .62rem;
            font-weight: 750;
        }}

        .ri-role-card__label {{
            color: var(--ri-accent);
            font-size: .62rem;
            font-weight: 750;
            letter-spacing: .04em;
            text-transform: uppercase;
        }}

        .ri-role-card h3 {{
            margin: .3rem 0 .35rem;
            font-size: .84rem;
            line-height: 1.4;
        }}

        .ri-role-card p {{
            margin: 0;
            color: var(--ri-muted) !important;
            font-size: .7rem;
            line-height: 1.5;
        }}

        .ri-trust-strip {{
            display: grid;
            grid-template-columns: repeat(
                auto-fit,
                minmax(min(100%, 14rem), 1fr)
            );
            gap: 1rem;
            margin: .1rem 0 1.35rem;
            padding: 1.05rem 1.15rem;
            border: 1px solid color-mix(
                in srgb,
                var(--ri-accent) 18%,
                var(--ri-border)
            );
            border-radius: 10px;
            background: var(--ri-accent-tint);
        }}

        .ri-trust-item {{
            display: flex;
            align-items: flex-start;
            gap: .65rem;
        }}

        .ri-trust-item__mark {{
            width: 7px;
            height: 7px;
            margin-top: .33rem;
            flex: 0 0 7px;
            border-radius: 50%;
            background: var(--ri-accent);
        }}

        .ri-trust-item strong,
        .ri-trust-item span {{
            display: block;
        }}

        .ri-trust-item strong {{
            margin-bottom: .18rem;
            color: var(--ri-text);
            font-size: .78rem;
        }}

        .ri-trust-item div > span {{
            color: var(--ri-muted);
            font-size: .71rem;
            line-height: 1.45;
        }}

        .ri-home-footer {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            margin: 0 0 1.35rem;
            padding: .85rem 0 0;
            border-top: 1px solid var(--ri-border);
            color: var(--ri-muted);
            font-size: .7rem;
        }}

        .ri-home-footer strong {{
            color: var(--ri-text);
            font-size: .76rem;
        }}

        @media (max-width: 1050px) {{
            .ri-home-hero {{
                grid-template-columns: 1fr;
            }}

            .ri-home-hero__content {{
                max-width: 760px;
            }}

            .ri-risk-console {{
                max-width: 760px;
            }}

            .ri-platform-flow {{
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }}
        }}

        @media (max-width: 700px) {{
            .ri-home-section__heading {{
                display: block;
            }}

            .ri-home-section__heading > p {{
                margin-top: .55rem;
            }}

            .ri-solution-card {{
                min-height: 0;
            }}

            .ri-home-hero {{
                padding-top: 2rem;
            }}

            .ri-home-hero h1 {{
                font-size: clamp(2rem, 11vw, 2.75rem);
            }}

            .ri-home-hero__actions {{
                align-items: stretch;
                flex-direction: column;
            }}

            .ri-home-button {{
                width: 100%;
                box-sizing: border-box;
            }}

            .ri-console-row {{
                grid-template-columns: auto minmax(0, 1fr);
            }}

            .ri-console-row__tag {{
                display: none;
            }}

            .ri-platform-flow {{
                grid-template-columns: 1fr;
            }}

            .ri-platform-stage {{
                min-height: 0;
            }}

            .ri-home-footer {{
                align-items: flex-start;
                flex-direction: column;
                gap: .25rem;
            }}
        }}

        @media (prefers-reduced-motion: reduce) {{
            .ri-solution-card,
            .ri-solution-card__cta span,
            .ri-home-button {{
                transition: none;
            }}

            .ri-solution-card:hover {{
                transform: none;
            }}

            .ri-solution-card:hover .ri-solution-card__cta span {{
                transform: none;
            }}

            .ri-home-button--primary:hover {{
                transform: none;
            }}
        }}
        </style>
        """,
        unsafe_allow_html=True,
    )


def page_header(
    kicker: str,
    title: str,
    description: str,
    *,
    meta: str | None = None,
) -> str:
    """Return a consistent, flat page header."""

    meta_html = (
        f'<div class="ri-page-header__meta">{html.escape(meta)}</div>'
        if meta
        else ""
    )
    return (
        '<section class="ri-page-header">'
        f'<div class="ri-page-header__kicker">{html.escape(kicker)}</div>'
        f"<h1>{html.escape(title)}</h1>"
        f"<p>{html.escape(description)}</p>"
        f"{meta_html}"
        "</section>"
    )


def style_plotly(figure, *, height: int | None = None):
    """Apply shared, low-noise Plotly styling and return the figure."""

    layout = {
        "paper_bgcolor": SURFACE,
        "plot_bgcolor": SURFACE,
        "font": {"family": "Inter, Arial, sans-serif", "size": 12, "color": TEXT_MUTED},
        "margin": {"l": 48, "r": 24, "t": 58, "b": 48},
        "legend": {
            "bgcolor": "rgba(0,0,0,0)",
            "font": {"color": TEXT_MUTED},
        },
        "xaxis": {
            "gridcolor": "#EDF0F2",
            "linecolor": BORDER,
            "zerolinecolor": BORDER,
            "title_font": {"color": TEXT_MUTED},
        },
        "yaxis": {
            "gridcolor": "#EDF0F2",
            "linecolor": BORDER,
            "zerolinecolor": BORDER,
            "title_font": {"color": TEXT_MUTED},
        },
        "title": {"font": {"color": TEXT, "size": 16}, "x": 0},
    }
    if height is not None:
        layout["height"] = height
    figure.update_layout(**layout)
    return figure
