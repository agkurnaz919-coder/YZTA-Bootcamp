import json
import logging
import requests

# ── Loglama ─────────────────────────────────────────────────────────────────────
logger = logging.getLogger(__name__)

# ── Sabitler ─────────────────────────────────────────────────────────────────────
OLLAMA_URL   = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "llama3.2"

# ================================================================================
# DİNAMİK SYSTEM PROMPTLARI — Kesin Şablon (Halüsinasyon ve Boş Yanıt Önleyici)
# ================================================================================

#  YÜKSEK RİSK PROMPTU (Risk >= %50)
SYSTEM_PROMPT_HIGH_RISK = """\
Sen kurumsal bir B2B SaaS Müşteri Başarı analistisin. 
Sana verilen MÜŞTERİ VERİLERİ'ni kullanarak BİREBİR aşağıdaki şablonda bir Türkçe rapor yaz. Kendi kendine hiçbir sayı veya hedef uydurma! Sadece sana verilen verileri şablondaki yerlere yerleştir.

ŞABLON:
###  Mevcut Durum Analizi
Müşterimizin güncel analizlerinde kayıp riski [BURAYA RİSK SKORUNU YAZ] seviyesindedir. [BURAYA ABONELİK SÜRESİNİ YAZ] boyunca yaşanan etkileşim düşüklüğü acil müdahale gerektirmektedir.

###  Teknik Aksiyon Önerileri
[SANA VERİLEN DICE REÇETELERİNİ BURAYA MADDE MADDE YAZ, SAYI UYDURMA]

###  Kurtarma Stratejisi
Müşteri ile 48 saat içinde kriz toplantısı organize edilmelidir. Hızlı aksiyon alınmazsa müşteri kaybedilebilir.
"""

#  DÜŞÜK RİSK PROMPTU (Risk < %50)
SYSTEM_PROMPT_LOW_RISK = """\
Sen kurumsal bir B2B SaaS Müşteri Başarı analistisin. 
Sana verilen MÜŞTERİ VERİLERİ'ni kullanarak BİREBİR aşağıdaki şablonda bir Türkçe rapor yaz. Müşteri risk taşımamaktadır. Kendi kendine sayı uydurma!

ŞABLON:
###  Mevcut Durum Analizi
Müşterimizin güncel analizlerinde kayıp riski [BURAYA RİSK SKORUNU YAZ] seviyesindedir. [BURAYA ABONELİK SÜRESİNİ YAZ] boyunca gösterilen aktif etkileşim platforma olan bağlılığı kanıtlamaktadır.

###  Gelişim ve Optimizasyon Önerileri
- Müşterinin platform kullanımını desteklemek için periyodik bilgilendirmelere devam edilmelidir.
- Mevcut operasyonel durum stabil şekilde korunmalıdır.

###  Elde Tutma ve Upsell Stratejisi
Müşteriye sadakatinden dolayı özel bir teşekkür e-postası iletilmeli ve bir üst pakete (Upsell) geçiş fırsatları zarifçe sunulmalıdır.
"""

# ── Fallback Mesajları ────────────────────────────────────────────────────────────
FALLBACK_OLLAMA_DOWN = (
    "** Ollama bağlantısı kurulamadı.**\n\n"
    "Lütfen Ollama'nın çalıştığından emin olun:\n\n"
    "```\n"
    "ollama serve          # Ollama sunucusunu başlat\n"
    "ollama pull llama3.2  # Modeli indir (ilk kurulumda)\n"
    "```\n\n"
    "Sunucu başlatıldıktan sonra bu sayfayı yenileyin."
)

FALLBACK_MODEL_NOT_FOUND = (
    "** `llama3.2` modeli bulunamadı.**\n\n"
    "Modeli indirmek için terminalde şunu çalıştırın:\n\n"
    "```\n"
    "ollama pull llama3.2\n"
    "```"
)

FALLBACK_EMPTY_RESPONSE = (
    "** Model boş yanıt döndürdü.**\n\n"
    "Lütfen birkaç saniye bekleyip tekrar deneyin."
)

# ================================================================================
# YARDIMCI: Müşteri Metriklerini Kullanıcı Mesajına Çevir
# ================================================================================
def _build_user_message(
    risk_score: float,
    abonelik_suresi: int,
    aylik_giris: int,
    aktif_kullanici: int,
    destek_bileti: int,
    dice_recipes: list[dict] | None,
) -> str:
    pct = round(risk_score * 100, 1)

    metrics_block = (
        f"Risk Skoru      : %{pct}\n"
        f"Abonelik Süresi : {abonelik_suresi} ay\n"
        f"Aylık Giriş     : {aylik_giris} giriş/ay\n"
        f"Aktif Kullanıcı : {aktif_kullanici} kullanıcı\n"
        f"Destek Bileti   : {destek_bileti} açık bilet\n"
    )

    feat_tr = {
        "Aylik_Giris_Sayisi"    : "Aylık Giriş Sayısı",
        "Aktif_Kullanici_Sayisi": "Aktif Kullanıcı Sayısı",
        "Destek_Bileti_Sayisi"  : "Destek Bileti Sayısı",
    }
    
    current_vals = {
        "Aylik_Giris_Sayisi"    : aylik_giris,
        "Aktif_Kullanici_Sayisi": aktif_kullanici,
        "Destek_Bileti_Sayisi"  : destek_bileti,
    }

    dice_lines = ["\nİyileştirme Hedefleri:"]

    if not dice_recipes or pct < 50.0:
        dice_lines.append("Müşteri güvende. Teknik hedefler yoksayılabilir.")
    else:
        for i, cf in enumerate(dice_recipes, 1):
            dice_lines.append(f"- Reçete {i}:")
            for feat, tgt_val in cf.items():
                if feat not in feat_tr:
                    continue
                label   = feat_tr.get(feat)
                cur_val = current_vals.get(feat)
                try:
                    delta   = float(tgt_val) - float(cur_val)
                    tgt_int = int(round(float(tgt_val)))
                    cur_int = int(round(float(cur_val)))
                    if delta > 0.5:
                        dice_lines.append(f"  * {label} {cur_int}'den {tgt_int}'ye çıkarılmalı.")
                    elif delta < -0.5:
                        dice_lines.append(f"  * {label} {cur_int}'den {tgt_int}'ye düşürülmeli.")
                except:
                    pass

    return f"{metrics_block}\n" + "\n".join(dice_lines)

# ================================================================================
# ANA FONKSİYON — Ollama API
# ================================================================================
def generate_churn_explanation(
    risk_score: float,
    abonelik_suresi: int,
    aylik_giris: int,
    aktif_kullanici: int,
    destek_bileti: int,
    dice_recipes: list[dict] | None = None,
) -> str:
    
    user_data = _build_user_message(
        risk_score=risk_score, abonelik_suresi=abonelik_suresi,
        aylik_giris=aylik_giris, aktif_kullanici=aktif_kullanici,
        destek_bileti=destek_bileti, dice_recipes=dice_recipes
    )

    if risk_score >= 0.50:
        selected_prompt = SYSTEM_PROMPT_HIGH_RISK
    else:
        selected_prompt = SYSTEM_PROMPT_LOW_RISK

    full_prompt = f"{selected_prompt}\n\n--- MÜŞTERİ VERİLERİ ---\n{user_data}"

    payload = {
        "model" : OLLAMA_MODEL,
        "prompt": full_prompt,
        "stream": False,
        "options": {
            "temperature": 0.1,
            "top_p": 0.9,
        },
    }

    try:
        response = requests.post(OLLAMA_URL, json=payload, timeout=120)
        response.raise_for_status()
    except requests.exceptions.ConnectionError:
        return FALLBACK_OLLAMA_DOWN
    except Exception as e:
        return f"** Beklenmeyen bir hata.**\n\nDetay: `{str(e)[:300]}`"

    try:
        explanation = response.json().get("response", "").strip()
    except:
        return "** Ollama yanıtı okunamadı.**"

    if not explanation:
        return FALLBACK_EMPTY_RESPONSE

    return explanation
