# ⚡ ChurnLens | B2B SaaS Churn Prevention & Counterfactual XAI Pipeline

Kurumsal SaaS şirketlerinin en büyük problemi olan müşteri kaybını (churn) gerçekleşmeden önce tespit eden ve **Açıklanabilir Yapay Zeka (XAI)** destekli kişiselleştirilmiş aksiyon reçeteleri sunan, uçtan uca makine öğrenmesi ve karar destek platformu. ChurnLens, yalnızca "kimin" gideceğini tahmin etmekle kalmaz, "neden" gideceğini açıklar ve müşteriyi platformda tutmak için eyleme dönüştürülebilir "nasıl" adımlarını mantıksal kısıtlar çerçevesinde üretir.

---

## ✨ Öne Çıkan Özellikler (Features)

*   **Sıfırdan XAI Mimarisi:** Saf Python ile geliştirilmiş, karar süreçleri tamamen şeffaf model ve mantıksal mimari.
*   **Yüksek Doğruluklu Tahmin:** XGBoost algoritması ve 5-Fold Stratified Cross-Validation tabanlı, kurumsal standartlarda sağlamlaştırılmış risk tahmini.
*   **DiCE (Counterfactual Explanations) Reçeteleri:** Modelin churn öngörüsünü tersine çevirmek için mantıksal kısıtlara bağlı (Örn: *Zaman geri alınamaz, abonelik süresi sabit tutulur*) kişiselleştirilmiş aksiyon reçeteleri üretimi.
*   **LLM Destekli Aksiyon Planları:** Ollama (Yerel) veya Gemini modelleri ile teknik DiCE çıktılarını, müşteri başarı ekipleri için kusursuz, anlaşılır Türkçe raporlara dönüştüren doğal dil üretim katmanı.
*   **Etkileşimli Dashboard:** Streamlit tabanlı; modern, kurumsal renk paletine sahip, yönetici ve müşteri başarı (Customer Success) ekipleri için tasarlanmış şık kullanıcı arayüzü.

---

## 📂 Proje Mimarisi ve Dosya Yapısı

```text
ChurnLens/
├── data/
│   └── churn_data.csv             # B2B SaaS müşteri veri seti
├── app.py                         # Streamlit web arayüzü ve dashboard
├── churnlens_sprint1.py           # XGBoost model eğitimi ve DiCE XAI motoru
├── llm_explainer.py               # Ollama (Llama 3.2 vb.) yerel LLM entegrasyonu
├── requirements.txt               # Proje bağımlılıkları
└── README.md                      # Proje dokümantasyonu
```

---

## 🚀 Kurulum ve Çalıştırma (Getting Started)

Projeyi yerel ortamınızda çalıştırmak için aşağıdaki adımları izleyin:

### 1. Sanal Ortam Kurulumu

**Venv kullanarak:**
```bash
python -m venv venv
# Windows için:
venv\Scripts\activate
# macOS/Linux için:
source venv/bin/activate
```

**Conda kullanarak:**
```bash
conda create -n churnlens_env python=3.10 -y
conda activate churnlens_env
```

### 2. Bağımlılıkların Yüklenmesi
```bash
pip install -r requirements.txt
```

### 3. LLM Kurulumu (Ollama İle Yerel Kullanım İçin)
Açıklamaları yerel olarak üretmek isterseniz Ollama'yı kurup Llama 3.2 modelini indirin:
```bash
# Ollama yüklü değilse https://ollama.com adresinden indirin
ollama serve
ollama pull llama3.2
```

### 4. Uygulamanın Başlatılması

Modeli eğitmek ve XAI pipeline'ını çalıştırmak için backend betiğini başlatın:
```bash
python churnlens_sprint1.py
```

Etkileşimli Streamlit kullanıcı arayüzünü ayağa kaldırmak için:
```bash
streamlit run app.py
```

---

## 📊 Sprint 1 Başarı Metrikleri ve Performans

Modelimiz, aşırı uyumu (overfitting) önlemek ve genelleyici gücü kanıtlamak adına **5-Fold Stratified Cross-Validation** ile test edilmiştir.

| Metrik | Skor | Hedef / Durum |
| :--- | :---: | :--- |
| **Ortalama AUC** | **0.9635** | 🎯 **0.85 Başarı Eşiği Aşılmıştır** |
| **Ortalama F1 Skoru** | 0.9412 | Çok yüksek sınıflandırma doğruluğu |
| **Ortalama Accuracy** | 0.9520 | Stabil ve güvenilir tahmin gücü |

### 🧠 DiCE Mantıksal Kısıt Mimarisi
Üretilen aksiyon reçeteleri, iş dünyasının gerçeklerine %100 uyumludur. Counterfactual (Karşıt Olgusal) senaryolar üretilirken:
*   Müşterinin geçmiş abonelik süresi ve aylık ödediği ücret değiştirilemez (Kilitli Değişken).
*   Yalnızca **Destek Bileti Sayısı**, **Aktif Kullanıcı Oranı** ve **Platforma Giriş Sayısı** gibi müşteri başarı ekibinin doğrudan eyleme geçebileceği (actionable) özellikler üzerinden senaryo üretilir.

---

## 🗺️ Gelecek Planlar (Roadmap - Sprint 2)

Projenin bir sonraki aşamasında, teknik reçeteleri proaktif müşteri iletişimine dönüştürecek entegrasyonlar sağlanacaktır:

- [x] **LLM (Ollama/Gemini) Entegrasyonu:** DiCE tarafından üretilen sayısal ve teknik reçetelerin, insan dilinde ve kişiselleştirilmiş "Müşteri Başarı (Customer Success) E-postalarına" dönüştürülmesi.
- [ ] **FastAPI Katmanı:** Modelin ve XAI motorunun mikroservis mimarisine taşınması, API uç noktalarının (endpoints) oluşturulması.
- [ ] **Otomatik Bildirim Sistemi:** Kritik risk seviyesindeki müşteriler tespit edildiğinde, Slack veya E-posta üzerinden ilgili ekiplere otomatik ve anlık bildirim (alert) gönderilmesi.
