# -*- coding: utf-8 -*-
# ================================================================================
#   ChurnLens | B2B SaaS Müşteri Kaybı Önleme Motoru - Sprint 3 Final Dashboard
#   Çalıştırmak için: streamlit run app.py
# ================================================================================

import re
import os
import pickle
import sys
import warnings
import traceback
from pathlib import Path
from types import SimpleNamespace

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# ── Sprint 2 / M4 — LLM Entegrasyonu ─────────────────────────────────
# llm_explainer modülü Ollama yerel LLM servisine bağlanır
try:
    from applications.churnlens.llm_explainer import generate_churn_explanation
    LLM_AVAILABLE = True
except ImportError:
    LLM_AVAILABLE = False
    def generate_churn_explanation(risk_score, abonelik_suresi, aylik_giris,
                                   aktif_kullanici, destek_bileti, dice_recipes=None):
        return " `llm_explainer.py` modülü bulunamadı. Lütfen dosyanın proje kök dizininde olduğundan emin olun."

warnings.filterwarnings("ignore")

# pyrefly: ignore [missing-import]
import numpy as np
import pandas as pd
# pyrefly: ignore [missing-import]
import plotly.graph_objects as go
# pyrefly: ignore [missing-import]
import streamlit as st

from applications.ui_theme import (
    ACCENT,
    ACCENT_TINT,
    BORDER,
    DANGER,
    DANGER_TINT,
    INFO,
    INFO_TINT,
    SUCCESS,
    SUCCESS_TINT,
    SURFACE,
    SURFACE_MUTED,
    TEXT,
    TEXT_MUTED,
    WARNING,
    WARNING_TINT,
    apply_theme,
    page_header,
    style_plotly,
)

# ── Sabitler ────────────────────────────────────────────────────────────────────
RANDOM_STATE = 42
N_SAMPLES    = 1000
N_CFs        = 3
MODEL_PATH   = os.path.join(os.path.dirname(os.path.abspath(__file__)), "xgboost_churn.pkl")
DATA_PATH    = os.path.join(os.path.dirname(os.path.abspath(__file__)), "churn_data.csv")

FEATURE_COLS = [
    "Abonelik_Suresi_Ay",
    "Aylik_Giris_Sayisi",
    "Aktif_Kullanici_Sayisi",
    "Destek_Bileti_Sayisi",
    "Aylik_Ucret_Euro",
]
TARGET_COL       = "Churn_Etti_Mi"
FEATURES_TO_VARY = [
    "Aylik_Giris_Sayisi",
    "Aktif_Kullanici_Sayisi",
    "Destek_Bileti_Sayisi",
]
FEATURE_LABELS = {
    "Abonelik_Suresi_Ay"    : "Abonelik Süresi (Ay)",
    "Aylik_Giris_Sayisi"    : "Aylık Giriş Sayısı",
    "Aktif_Kullanici_Sayisi": "Aktif Kullanıcı Sayısı",
    "Destek_Bileti_Sayisi"  : "Destek Bileti Sayısı",
    "Aylik_Ucret_Euro"      : "Aylık Ücret (€)",
}
FEATURE_UNITS = {
    "Abonelik_Suresi_Ay"    : "ay",
    "Aylik_Giris_Sayisi"    : "giriş",
    "Aktif_Kullanici_Sayisi": "kullanıcı",
    "Destek_Bileti_Sayisi"  : "bilet",
    "Aylik_Ucret_Euro"      : "€",
}

# Shared native controls plus compatibility rules for legacy inline report cards.
apply_theme()
st.markdown(
    """
    <style>
    [data-testid="stMarkdownContainer"] [style*="background:#0d1a2e"],
    [data-testid="stMarkdownContainer"] [style*="background:#0b1627"],
    [data-testid="stMarkdownContainer"] [style*="background:#0a1525"] {
        background:var(--ri-surface) !important;
        border-color:var(--ri-border) !important;
        box-shadow:none !important;
    }
    [data-testid="stMarkdownContainer"] [style*="color:#eef4ff"],
    [data-testid="stMarkdownContainer"] [style*="color:#e8f0fe"],
    [data-testid="stMarkdownContainer"] [style*="color:#dce7f6"],
    [data-testid="stMarkdownContainer"] [style*="color:#c8d8e8"] {
        color:#17212b !important;
    }
    [data-testid="stMarkdownContainer"] [style*="color:#a9b7ca"],
    [data-testid="stMarkdownContainer"] [style*="color:#a0b4c8"],
    [data-testid="stMarkdownContainer"] [style*="color:#8293aa"],
    [data-testid="stMarkdownContainer"] [style*="color:#7f91aa"],
    [data-testid="stMarkdownContainer"] [style*="color:#71839a"],
    [data-testid="stMarkdownContainer"] [style*="color:#6b8099"],
    [data-testid="stMarkdownContainer"] [style*="color:#4a6080"],
    [data-testid="stMarkdownContainer"] [style*="color:#3a5070"],
    [data-testid="stMarkdownContainer"] [style*="color:#2a4060"],
    [data-testid="stMarkdownContainer"] [style*="color:#1e3050"] {
        color:#4e5b66 !important;
    }
    [data-testid="stMarkdownContainer"] [style*="-webkit-background-clip:text"] {
        background:transparent !important;
        color:#17212b !important;
        -webkit-text-fill-color:#17212b !important;
    }
    </style>
    """,
    unsafe_allow_html=True,
)



# ── Yardımcı Fonksiyonlar ───────────────────────────────────────────────────────

def _replace_string_nans(df, columns):
    pat = re.compile(r"^\s*nan\s*$", re.IGNORECASE)
    for col in columns:
        df[col] = df[col].apply(lambda v: np.nan if isinstance(v, str) and pat.match(v) else v)
        df[col] = pd.to_numeric(df[col], errors="coerce")
    return df


def clean_data(df):
    df = df.copy()
    df = _replace_string_nans(df, FEATURE_COLS)
    discrete = {"Aylik_Giris_Sayisi", "Aktif_Kullanici_Sayisi", "Destek_Bileti_Sayisi", "Abonelik_Suresi_Ay"}
    for col in FEATURE_COLS:
        if df[col].isnull().any():
            fv = df[col].dropna().mode().iloc[0] if col in discrete else df[col].median()
            df[col] = df[col].fillna(fv)
    return df


def generate_synthetic_data(n=N_SAMPLES, seed=RANDOM_STATE):
    rng = np.random.default_rng(seed)
    ab = rng.integers(1, 60, size=n).astype(float)
    gi = rng.integers(0, 200, size=n).astype(float)
    ak = rng.integers(1, 100, size=n).astype(float)
    db = rng.integers(0, 30, size=n).astype(float)
    uc = rng.uniform(100, 5000, size=n).round(2)
    score = 0.45*(1-gi/200) + 0.25*(1-ak/100) + 0.20*(db/30) + 0.10*(1-ab/60)
    churn = ((score + rng.uniform(-.05, .05, n)) > .50).astype(int)
    df = pd.DataFrame({
        "Musteri_ID"            : [f"MUS-{i:04d}"for i in range(1, n+1)],
        "Abonelik_Suresi_Ay"    : ab.astype(object),
        "Aylik_Giris_Sayisi"    : gi.astype(object),
        "Aktif_Kullanici_Sayisi": ak.astype(object),
        "Destek_Bileti_Sayisi"  : db.astype(object),
        "Aylik_Ucret_Euro"      : uc.astype(object),
        "Churn_Etti_Mi"         : churn,
    })
    nans = ["nan", "NaN", "NAN"]
    for col in FEATURE_COLS:
        mask = rng.random(n) < .05
        df.loc[df.index[mask], col] = list(rng.choice(nans, mask.sum()))
    return df


# ── Model / Veri / DiCE ─────────────────────────────────────────────────────────

@st.cache_resource(show_spinner=False)
def load_or_train_model():
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.model_selection import train_test_split
    # pyrefly: ignore [missing-import]
    from xgboost import XGBClassifier

    if os.path.exists(MODEL_PATH):
        with open(MODEL_PATH, "rb") as f:
            pipeline = pickle.load(f)
        return pipeline, "disk"

    raw   = generate_synthetic_data()
    clean = clean_data(raw)
    X, y  = clean[FEATURE_COLS], clean[TARGET_COL]
    Xtr, _, ytr, _ = train_test_split(X, y, test_size=.2, random_state=RANDOM_STATE, stratify=y)
    pipeline = Pipeline([
        ("scaler", StandardScaler()),
        ("clf", XGBClassifier(n_estimators=300, max_depth=6, learning_rate=.05,
                               subsample=.85, colsample_bytree=.85,
                               eval_metric="logloss", random_state=RANDOM_STATE, n_jobs=-1)),
    ])
    pipeline.fit(Xtr, ytr)
    with open(MODEL_PATH, "wb") as f:
        pickle.dump(pipeline, f)
    return pipeline, "trained"


@st.cache_resource(show_spinner=False)
def load_train_data():
    if os.path.exists(DATA_PATH):
        return clean_data(pd.read_csv(DATA_PATH))
    return clean_data(generate_synthetic_data())


@st.cache_resource(show_spinner=False)
def build_dice_explainer(_pipeline, _train_df):
    """Return a lightweight DiCE-compatible counterfactual adapter.

    dice-ml 0.11 requires pandas<2, while the merged applications require
    pandas 2+. This local engine keeps ChurnLens's existing result contract
    and searches realistic low-risk profiles from the training distribution.
    """

    class CounterfactualAdapter:
        def __init__(self, pipeline, train_df):
            self.pipeline = pipeline
            self.train_df = train_df.copy()

        def generate_counterfactuals(
            self,
            query,
            total_CFs=3,
            desired_class=0,
            features_to_vary=None,
            random_seed=42,
        ):
            del random_seed
            varying = list(features_to_vary or FEATURES_TO_VARY)
            current = query[FEATURE_COLS].iloc[0].astype(float)
            desired = self.train_df[
                self.train_df[TARGET_COL].astype(int) == int(desired_class)
            ].copy()
            if desired.empty:
                raise ValueError("İstenen sınıf için referans müşteri bulunamadı.")

            desired["_risk"] = self.pipeline.predict_proba(
                desired[FEATURE_COLS]
            )[:, 1]
            desired = desired.sort_values("_risk")

            candidates = []
            seen = set()
            for _, reference in desired.iterrows():
                candidate = current.copy()
                for feature in varying:
                    candidate[feature] = float(reference[feature])
                candidate_frame = pd.DataFrame([candidate], columns=FEATURE_COLS)
                prediction = int(self.pipeline.predict(candidate_frame)[0])
                signature = tuple(round(float(candidate[col]), 4) for col in FEATURE_COLS)
                if prediction == int(desired_class) and signature not in seen:
                    candidates.append(candidate)
                    seen.add(signature)
                if len(candidates) >= int(total_CFs):
                    break

            if not candidates:
                raise ValueError("Uygulanabilir düşük risk senaryosu üretilemedi.")

            final_cfs = pd.DataFrame(candidates, columns=FEATURE_COLS)
            example = SimpleNamespace(final_cfs_df=final_cfs)
            return SimpleNamespace(cf_examples_list=[example])

    return CounterfactualAdapter(_pipeline, _train_df)


# ── HTML Bileşenleri (tek satır, newline içermeyen string) ──────────────────────

def S(*parts) -> str:
    """Join parts into a single-line HTML string."""
    return "".join(parts)


def H(tag: str, style: str, *children) -> str:
    return f'<{tag} style="{style}">{"".join(children)}</{tag}>'


def SPAN(style: str, text: str) -> str:
    return f'<span style="{style}">{text}</span>'


def DIV(style: str, *children) -> str:
    return f'<div style="{style}">{"".join(children)}</div>'


def html_header() -> str:
    return page_header(
        "Müşteri kaybı analizi",
        "ChurnLens",
        (
            "B2B SaaS müşterileri için risk değerlendirmesi, açıklanabilir "
            "göstergeler ve uygulanabilir iyileştirme planları."
        ),
        meta="XGBoost · Karşı-olgusal analiz · Yerel AI açıklaması",
    )


def html_info_box(
    text: str,
    border: str = INFO,
    bg: str = INFO_TINT,
    text_color: str = TEXT,
) -> str:
    return DIV(
        f"background:{bg};border:1px solid {border};border-left:3px solid {border};"
        f"border-radius:8px;padding:.85rem 1.2rem;color:{text_color};"
        f"font-size:.84rem;margin-bottom:1rem;font-family:'Inter',sans-serif;",
        text
    )


def risk_profile(probability: float) -> dict:
    if probability >= 0.70:
        return {
            "level": "high",
            "label": "Yüksek Risk",
            "priority": "Öncelik: 24 saat içinde müdahale",
            "color": DANGER,
            "background": DANGER_TINT,
            "description": (
                "Müşterinin ayrılma olasılığı belirgin biçimde yüksek. "
                "Müşteri başarı ekibinin gecikmeden temas kurması önerilir."
            ),
        }
    if probability >= 0.35:
        return {
            "level": "medium",
            "label": "Orta Risk",
            "priority": "Öncelik: Bu hafta içinde takip",
            "color": WARNING,
            "background": WARNING_TINT,
            "description": (
                "Müşteri takip gerektiriyor. Erken ve hedefli iyileştirmeler "
                "riskin yükselmesini önleyebilir."
            ),
        }
    return {
        "level": "low",
        "label": "Düşük Risk",
        "priority": "Öncelik: Rutin izleme",
        "color": SUCCESS,
        "background": SUCCESS_TINT,
        "description": (
            "Müşteri şu anda sağlıklı görünüyor. Mevcut kullanım ve destek "
            "deneyiminin korunması yeterlidir."
        ),
    }


def healthy_benchmarks(train_df: pd.DataFrame) -> dict:
    healthy = train_df[train_df[TARGET_COL].astype(int) == 0]
    reference = healthy if not healthy.empty else train_df
    return {
        feature: float(reference[feature].median())
        for feature in FEATURE_COLS
    }


def _format_metric(feature: str, value: float) -> str:
    if feature == "Aylik_Ucret_Euro":
        return f"€{value:,.0f}"
    return f"{value:,.0f} {FEATURE_UNITS[feature]}"


def build_customer_reasons(
    values: dict,
    benchmarks: dict,
    feature_importance: dict,
) -> list[dict]:
    definitions = {
        "Destek_Bileti_Sayisi": {
            "direction": "lower",
            "title": "Destek yükü sağlıklı seviyenin üzerinde",
            "explanation": (
                "Açık destek taleplerinin birikmesi çözülmemiş sorunlara ve "
                "müşteri memnuniyetsizliğine işaret eder."
            ),
            "action": "Kritik biletleri sınıflandırın ve çözüm süresi hedefi belirleyin.",
        },
        "Aylik_Giris_Sayisi": {
            "direction": "higher",
            "title": "Platform kullanımı düşük",
            "explanation": (
                "Düşük giriş sıklığı, ürünün müşterinin günlük iş akışında "
                "yeterince yer edinmediğini gösterir."
            ),
            "action": "Kullanım oturumu planlayın ve temel iş akışlarını yeniden aktive edin.",
        },
        "Aktif_Kullanici_Sayisi": {
            "direction": "higher",
            "title": "Ekip içi ürün benimsemesi zayıf",
            "explanation": (
                "Aktif kullanıcı sayısının düşük kalması ürün değerinin "
                "müşteri organizasyonuna yayılmadığını gösterir."
            ),
            "action": "Yeni kullanıcı aktivasyonu ve rol bazlı eğitim planı oluşturun.",
        },
        "Abonelik_Suresi_Ay": {
            "direction": "higher",
            "title": "Müşteri erken dönem riskinde",
            "explanation": (
                "Kısa abonelik süresi, müşterinin henüz kalıcı kullanım "
                "alışkanlığı geliştirmediği hassas onboarding dönemini gösterir."
            ),
            "action": "Onboarding hedeflerini ve ilk değer kazanım adımlarını gözden geçirin.",
        },
    }
    reasons = []
    for feature, definition in definitions.items():
        current = float(values[feature])
        reference = float(benchmarks[feature])
        denominator = max(abs(reference), 1.0)
        if definition["direction"] == "higher":
            gap = max((reference - current) / denominator, 0.0)
        else:
            gap = max((current - reference) / denominator, 0.0)
        if gap < 0.08:
            continue
        importance = float(feature_importance.get(feature, 0.0))
        reasons.append(
            {
                **definition,
                "feature": feature,
                "current": current,
                "reference": reference,
                "rank_score": gap * (0.5 + importance),
            }
        )
    reasons.sort(key=lambda item: item["rank_score"], reverse=True)
    return reasons[:3]


def html_risk_overview(
    probability: float,
    profile: dict,
    reasons: list[dict],
) -> str:
    percentage = probability * 100
    reason_names = ", ".join(reason["title"].lower() for reason in reasons)
    if reason_names:
        summary = f"Bu sonucu en çok açıklayan göstergeler: {reason_names}."
    else:
        summary = (
            "Tek bir baskın olumsuz gösterge bulunmadı; skor metriklerin "
            "birlikte oluşturduğu örüntüden kaynaklanıyor."
        )
    return DIV(
        f"background:{profile['background']};border:1px solid {profile['color']}55;"
        f"border-left:3px solid {profile['color']};border-radius:10px;"
        "padding:1.5rem 1.7rem;margin-bottom:1.2rem;",
        DIV(
            "display:flex;align-items:flex-start;justify-content:space-between;"
            "gap:1.5rem;flex-wrap:wrap;",
            DIV(
                "flex:1;min-width:260px;",
                DIV(
                    f"color:{profile['color']};font-size:.72rem;font-weight:800;"
                    "text-transform:uppercase;letter-spacing:1.2px;margin-bottom:.45rem;",
                    "Genel Risk Değerlendirmesi",
                ),
                DIV(
                    f"color:{TEXT};font-size:1.55rem;font-weight:700;margin-bottom:.45rem;",
                    profile["label"],
                ),
                DIV(
                    f"color:{TEXT_MUTED};font-size:.9rem;line-height:1.65;max-width:760px;",
                    profile["description"],
                ),
            ),
            DIV(
                "min-width:190px;text-align:right;",
                DIV(
                    f"color:{TEXT_MUTED};font-size:.72rem;text-transform:uppercase;"
                    "letter-spacing:.9px;margin-bottom:.25rem;",
                    "Tahmini Churn Olasılığı",
                ),
                DIV(
                    f"color:{profile['color']};font-size:2.35rem;font-weight:800;"
                    "line-height:1;",
                    f"%{percentage:.1f}",
                ),
                DIV(
                    f"color:{TEXT_MUTED};font-size:.72rem;margin-top:.35rem;",
                    "Karar eşiği: %35",
                ),
            ),
        ),
        DIV(
            f"height:8px;border-radius:4px;margin:1.25rem 0 .65rem;"
            f"background:{SURFACE_MUTED};position:relative;",
            DIV(
                f"position:absolute;left:0;top:0;width:{percentage:.1f}%;height:100%;"
                f"background:{profile['color']};border-radius:4px;",
            ),
            DIV(
                f"position:absolute;left:clamp(1%,{percentage:.1f}%,99%);top:50%;"
                f"width:3px;height:19px;background:{TEXT};border-radius:2px;"
                "transform:translate(-50%,-50%);"
            ),
        ),
        DIV(
            f"display:flex;justify-content:space-between;color:{TEXT_MUTED};"
            "font-size:.68rem;margin-bottom:1rem;",
            SPAN("", "Düşük: %0–34"),
            SPAN("", "Orta: %35–69"),
            SPAN("", "Yüksek: %70–100"),
        ),
        DIV(
            f"border-top:1px solid {BORDER};padding-top:.9rem;"
            "display:flex;justify-content:space-between;gap:1.2rem;flex-wrap:wrap;",
            DIV(f"color:{TEXT_MUTED};font-size:.82rem;line-height:1.55;flex:1;", summary),
            DIV(
                f"color:{profile['color']};font-size:.78rem;font-weight:700;",
                profile["priority"],
            ),
        ),
    )


def html_reason_cards(reasons: list[dict]) -> str:
    if not reasons:
        return html_info_box(
            "Müşteri metrikleri düşük riskli referans grubuyla genel olarak uyumlu. "
            "Model skoru, tek bir göstergeden çok metriklerin birleşik örüntüsüne dayanıyor.",
            SUCCESS,
            SUCCESS_TINT,
            TEXT,
        )
    cards = []
    for index, reason in enumerate(reasons, 1):
        comparison = (
            f"Mevcut: {_format_metric(reason['feature'], reason['current'])} "
            f"| Düşük risk referansı: {_format_metric(reason['feature'], reason['reference'])}"
        )
        cards.append(
            DIV(
                f"background:{SURFACE};border:1px solid {BORDER};border-radius:10px;"
                "padding:1rem 1.15rem;",
                DIV(
                    "display:flex;align-items:flex-start;gap:.85rem;",
                    DIV(
                        "width:28px;height:28px;flex:0 0 28px;border-radius:8px;"
                        f"background:{ACCENT_TINT};color:{ACCENT};font-size:.76rem;font-weight:700;"
                        "display:flex;align-items:center;justify-content:center;",
                        str(index),
                    ),
                    DIV(
                        "flex:1;",
                        DIV(
                            f"color:{TEXT};font-size:.9rem;font-weight:700;margin-bottom:.3rem;",
                            reason["title"],
                        ),
                        DIV(
                            f"color:{TEXT_MUTED};font-size:.76rem;margin-bottom:.55rem;",
                            comparison,
                        ),
                        DIV(
                            f"color:{TEXT_MUTED};font-size:.8rem;line-height:1.55;margin-bottom:.6rem;",
                            reason["explanation"],
                        ),
                        DIV(
                            f"color:{ACCENT};font-size:.76rem;font-weight:650;",
                            f"Öneri: {reason['action']}",
                        ),
                    ),
                ),
            )
        )
    return DIV(
        "display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));"
        "gap:.8rem;margin:.65rem 0 1.25rem;",
        *cards,
    )


def html_metric_comparison_cards(values: dict, benchmarks: dict) -> str:
    cards = []
    for feature in FEATURE_COLS:
        current = float(values[feature])
        reference = float(benchmarks[feature])
        if feature in {"Aylik_Giris_Sayisi", "Aktif_Kullanici_Sayisi", "Abonelik_Suresi_Ay"}:
            healthy = current >= reference
            status = "Referansla uyumlu"if healthy else "Referansın altında"
        elif feature == "Destek_Bileti_Sayisi":
            healthy = current <= reference
            status = "Referansla uyumlu"if healthy else "Referansın üzerinde"
        else:
            healthy = True
            status = "Bağlam metriği"
        status_color = SUCCESS if healthy else WARNING
        cards.append(
            DIV(
                f"background:{SURFACE};border:1px solid {BORDER};border-radius:10px;"
                "padding:.95rem 1.05rem;min-width:170px;",
                DIV(
                    f"color:{TEXT_MUTED};font-size:.66rem;font-weight:700;text-transform:uppercase;"
                    "letter-spacing:.65px;min-height:2rem;",
                    FEATURE_LABELS[feature],
                ),
                DIV(
                    f"color:{TEXT};font-size:1.2rem;font-weight:700;margin:.25rem 0;",
                    _format_metric(feature, current),
                ),
                DIV(
                    f"color:{TEXT_MUTED};font-size:.68rem;",
                    f"Düşük risk referansı: {_format_metric(feature, reference)}",
                ),
                DIV(
                    f"color:{status_color};font-size:.68rem;font-weight:700;margin-top:.45rem;",
                    status,
                ),
            )
        )
    return DIV(
        "display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));"
        "gap:.7rem;margin:.65rem 0 1rem;",
        *cards,
    )


def html_action_cards(instance: pd.Series, cf_df: pd.DataFrame) -> str:
    accents = [ACCENT, WARNING, INFO]
    badges  = ["PRIMARY", "ALT-A",   "ALT-B"]
    titles  = ["Birincil Öneri", "Alternatif A", "Alternatif B"]

    rgba_map = {ACCENT: "23,107,91", WARNING: "154,90,18", INFO: "49,94,129"}
    all_cards = []

    for idx, row in cf_df.iterrows():
        i      = int(idx)
        accent = accents[i] if i < len(accents) else ACCENT
        badge  = badges[i]  if i < len(badges)  else f"CF-{i+1}"
        title  = titles[i]  if i < len(titles)  else f"Seçenek {i+1}"
        rgba   = rgba_map.get(accent, "23,107,91")

        rows = []
        for j, feat in enumerate(FEATURE_COLS):
            cur = float(instance[feat])
            tgt = float(row[feat])
            is_last = (j == len(FEATURE_COLS) - 1)
            border_s = "border-bottom:none;"if is_last else f"border-bottom:1px solid {BORDER};"

            if feat == "Abonelik_Suresi_Ay":
                tag_txt, tag_bg, tag_col, tgt_col = "SABİT",    "rgba(74,96,128,0.2)",  "#4a8099", "#4a6080"
            elif abs(tgt - cur) < 0.5:
                tag_txt, tag_bg, tag_col, tgt_col = "— DEĞİŞMEZ",  "rgba(74,96,128,0.15)", "#4a8099", "#4a6080"
            elif tgt > cur:
                tag_txt, tag_bg, tag_col, tgt_col = "▲ ARTIR",     "rgba(0,204,102,0.15)", "#00cc66", "#00cc66"
            else:
                tag_txt, tag_bg, tag_col, tgt_col = "▼ AZALT",     "rgba(255,68,68,0.15)", "#ff4444", "#ff4444"

            if feat == "Aylik_Ucret_Euro":
                cur_s, tgt_s = f"€{cur:,.0f}", f"€{tgt:,.0f}"
            else:
                u = FEATURE_UNITS[feat]
                cur_s, tgt_s = f"{cur:.0f} {u}", f"{tgt:.0f} {u}"

            rows.append(DIV(
                f"display:flex;align-items:center;justify-content:space-between;padding:.55rem 0;{border_s}",
                SPAN("color:#6b8099;font-size:.74rem;font-weight:500;flex:1.4;", FEATURE_LABELS[feat]),
                DIV("display:flex;align-items:center;gap:.4rem;flex:2;justify-content:flex-end;flex-wrap:wrap;",
                    SPAN("color:#3a5070;font-size:.78rem;", cur_s),
                    SPAN("color:#2a4060;font-size:.78rem;", "→"),
                    SPAN(f"color:{tgt_col};font-size:.82rem;font-weight:700;", tgt_s),
                    SPAN(f"background:{tag_bg};color:{tag_col};font-size:.6rem;font-weight:700;"
                         "padding:.15rem .42rem;border-radius:4px;letter-spacing:.4px;", tag_txt),
                ),
            ))

        result_box = DIV(
            "margin-top:1.1rem;background:rgba(0,204,102,0.08);"
            "border:1px solid rgba(0,204,102,0.22);border-radius:8px;"
            "padding:.7rem 1rem;display:flex;align-items:center;gap:.5rem;",
            SPAN("color:#00cc66;font-size:.78rem;font-weight:600;",
                 "Bu hedefler uygulanırsa model müşteriyi düşük risk sınıfında değerlendiriyor."),
        )

        badge_el = DIV(
            f"display:inline-block;background:rgba({rgba},0.13);color:{accent};"
            "font-size:.62rem;font-weight:700;padding:.18rem .55rem;border-radius:20px;"
            "letter-spacing:.7px;margin-bottom:.9rem;", badge
        )
        title_el = DIV(f"color:{TEXT};font-size:.95rem;font-weight:700;margin-bottom:1.1rem;", title)

        card = DIV(
            f"flex:1;min-width:280px;background:{SURFACE};"
            f"border:1px solid {BORDER};border-top:2px solid {accent};"
            f"border-radius:10px;padding:1.4rem 1.5rem;box-sizing:border-box;",
            badge_el, title_el, *rows, result_box
        )
        all_cards.append(card)

    return DIV("display:flex;gap:1rem;flex-wrap:wrap;margin-top:1.4rem;", *all_cards)




# Beklenen CSV kolon isimleri (M5)
EXPECTED_CSV_COLS = [
    "Abonelik_Suresi_Ay",
    "Aylik_Giris_Sayisi",
    "Aktif_Kullanici_Sayisi",
    "Destek_Bileti_Sayisi",
    "Aylik_Ucret_Euro",
]


# ── Demo Sayfası Sabitleri (Canlı Demo — War Room) ─────────────────────────────

DEMO_SCENARIO_VALS = {
    "Abonelik_Suresi_Ay"    : 9.0,
    "Aylik_Giris_Sayisi"    : 62.0,
    "Aktif_Kullanici_Sayisi": 22.0,
    "Destek_Bileti_Sayisi"  : 28.0,
    "Aylik_Ucret_Euro"      : 3427.35,
}

# Jüri güvenliği: DiCE başarısız olursa kullanılacak statik fallback CF hedefleri
DEMO_CF_FALLBACK = {
    "Abonelik_Suresi_Ay"    : 9.0,
    "Aylik_Giris_Sayisi"    : 120.0,
    "Aktif_Kullanici_Sayisi": 55.0,
    "Destek_Bileti_Sayisi"  : 5.0,
    "Aylik_Ucret_Euro"      : 3427.35,
}


def render_demo_page(pipeline, train_df) -> None:
    """A Şirketi kriz senaryosunu göster."""

    # ── Geri Butonu ─────────────────────────────────────────────────────────────
    if st.button("Ana Sayfaya Dön", key="demo_back_btn"):
        st.session_state.current_page = "main"
        st.session_state.pop("demo_llm_explanation", None)
        st.rerun()

    st.markdown(
        page_header(
            "Canlı demo",
            "A Şirketi · Onboarding risk senaryosu",
            (
                "Müşteri 9 ay önce sisteme katıldı. Kullanıcı katılımı kritik "
                "seviyenin altında; iyileştirme hedefleri bu profil üzerinden hesaplanır."
            ),
        ),
        unsafe_allow_html=True)

    # ── Model Tahmini ────────────────────────────────────────────────────────────
    demo_df    = pd.DataFrame([DEMO_SCENARIO_VALS])
    churn_prob = float(pipeline.predict_proba(demo_df)[0, 1])
    pct        = churn_prob * 100

    demo_profile = risk_profile(churn_prob)
    demo_benchmarks = healthy_benchmarks(train_df)
    demo_importance = dict(
        zip(FEATURE_COLS, pipeline.named_steps["clf"].feature_importances_)
    )
    demo_reasons = build_customer_reasons(
        DEMO_SCENARIO_VALS,
        demo_benchmarks,
        demo_importance,
    )
    st.markdown(
        html_risk_overview(churn_prob, demo_profile, demo_reasons),
        unsafe_allow_html=True,
    )
    st.markdown(
        H(
            "h3",
            "color:#dce7f6;font-size:1.02rem;font-weight:700;margin:.7rem 0 .35rem;",
            "Bu Senaryonun Temel Nedenleri",
        ),
        unsafe_allow_html=True,
    )
    st.markdown(html_reason_cards(demo_reasons), unsafe_allow_html=True)

    st.markdown("<hr style='border:none;border-top:1px solid #1e2a40;margin:1.5rem 0;'>",
                unsafe_allow_html=True)

    # ── BÖLÜM A: Mevcut Durum vs Yapay Zeka Hedefleri ───────────────────────────
    st.markdown(
        H("h3", "color:#c8d8e8;font-size:1.05rem;font-weight:700;margin-bottom:1rem;",
          "Mevcut Durum ve İyileştirme Hedefleri"),
        unsafe_allow_html=True)

    col_now, col_ai = st.columns(2, gap="large")
    with col_now:
        st.markdown(
            DIV(
                "background:rgba(255,68,68,0.06);border:1px solid rgba(255,68,68,0.22);"
                "border-top:3px solid #ff4444;border-radius:14px;padding:1.1rem 1.3rem;margin-bottom:.8rem;",
                DIV("color:#ff6666;font-size:.7rem;font-weight:700;text-transform:uppercase;"
                    "letter-spacing:1.2px;", "MEVCUT DURUM (A ŞİRKETİ)"),
            ),
            unsafe_allow_html=True)
        st.metric("Churn Riski",     f"%{pct:.1f}",   delta=f"+{pct-35:.1f} puan karar eşiğinin üstü", delta_color="inverse")
        st.metric("Aylık Giriş",     "62 giriş/ay",   delta="Hedefin altında",             delta_color="inverse")
        st.metric("Aktif Kullanıcı", "22 kullanıcı",  delta="Kritik düşük",             delta_color="inverse")
        st.metric("Destek Bileti",   "28 açık bilet", delta="Alarm seviyesi",            delta_color="inverse")
        st.metric("Abonelik Süresi", "9 ay",          delta="Onboarding dönemi")

    with col_ai:
        st.markdown(
            DIV(
                "background:rgba(0,204,102,0.06);border:1px solid rgba(0,204,102,0.22);"
                "border-top:3px solid #00cc66;border-radius:14px;padding:1.1rem 1.3rem;margin-bottom:.8rem;",
                DIV("color:#00cc66;font-size:.7rem;font-weight:700;text-transform:uppercase;"
                    "letter-spacing:1.2px;", "ÖNERİLEN HEDEFLER"),
            ),
            unsafe_allow_html=True)
        st.metric("Hedef Risk",        "< %35",           delta="Düşük risk sınıfı",       delta_color="off")
        st.metric("Hedef Giriş",      "≥ 120 giriş/ay",  delta="+58 artırılmalı",            delta_color="normal")
        st.metric("Hedef Kullanıcı",  "≥ 55 kullanıcı",  delta="+33 aktivasyon gerekli",     delta_color="normal")
        st.metric("Hedef Bilet",      "≤ 5 bilet",        delta="-23 acil çözüm",             delta_color="normal")
        st.metric("Abonelik (Sabit)", "9 ay",             delta="Geçmişe dönük değiştirilemez")

    st.markdown("<hr style='border:none;border-top:1px solid #1e2a40;margin:1.5rem 0;'>",
                unsafe_allow_html=True)

    # ── BÖLÜM B: DiCE Counterfactual Reçeteleri ─────────────────────────────────
    st.markdown(
        H("h3", "color:#c8d8e8;font-size:1.05rem;font-weight:700;margin-bottom:.6rem;",
          "Riski Azaltmak İçin Önerilen Hedefler"),
        unsafe_allow_html=True)
    st.markdown(html_info_box(
        "<strong>Değiştirilemeyen alan:</strong> Abonelik süresi geçmişe dönük "
        "değiştirilemediği için tüm planlarda sabit tutulur.",
        "#00aaff", "rgba(0,170,255,0.07)", "#a0c4e8"), unsafe_allow_html=True)

    demo_cf_list = []
    try:
        with st.spinner("İyileştirme hedefleri hesaplanıyor..."):
            explainer = build_dice_explainer(pipeline, train_df)
            cf_result = explainer.generate_counterfactuals(
                demo_df.copy().reset_index(drop=True),
                total_CFs=N_CFs, desired_class=0,
                features_to_vary=FEATURES_TO_VARY, random_seed=RANDOM_STATE,
            )
            cf_df = (cf_result.cf_examples_list[0]
                     .final_cfs_df[FEATURE_COLS]
                     .reset_index(drop=True))
        st.markdown(html_action_cards(demo_df.iloc[0], cf_df), unsafe_allow_html=True)
        with st.expander("Teknik hedef değerleri", expanded=False):
            st.dataframe(cf_df.rename(columns=FEATURE_LABELS).style.format(precision=1),
                         width="stretch")
        demo_cf_list = cf_df.to_dict(orient="records")
    except Exception as _dice_err:
        st.markdown(html_info_box(
            f"İyileştirme planı bu oturumda oluşturulamadı — "
            f"<code>{str(_dice_err)[:100]}</code><br>"
            "Statik referans hedefleri kullanılmaktadır.",
            "#ffb800", "rgba(255,184,0,0.07)", "#e8c46a"), unsafe_allow_html=True)
        demo_cf_list = [DEMO_CF_FALLBACK]

    st.markdown("<hr style='border:none;border-top:1px solid #1e2a40;margin:1.5rem 0;'>",
                unsafe_allow_html=True)

    # ── BÖLÜM C: LLM Aksiyon Raporu ──────────────────────────────────────────────
    st.markdown(
        H("h3", "color:#c8d8e8;font-size:1.05rem;font-weight:700;margin-bottom:.6rem;",
          "Yapay Zeka Kurumsal Aksiyon Raporu"),
        unsafe_allow_html=True)

    if "demo_llm_explanation"not in st.session_state:
        with st.spinner("Kurumsal aksiyon planı hazırlanıyor..."):
            try:
                _exp = generate_churn_explanation(
                    risk_score      = churn_prob,
                    abonelik_suresi = int(DEMO_SCENARIO_VALS["Abonelik_Suresi_Ay"]),
                    aylik_giris     = int(DEMO_SCENARIO_VALS["Aylik_Giris_Sayisi"]),
                    aktif_kullanici = int(DEMO_SCENARIO_VALS["Aktif_Kullanici_Sayisi"]),
                    destek_bileti   = int(DEMO_SCENARIO_VALS["Destek_Bileti_Sayisi"]),
                    dice_recipes    = demo_cf_list or None,
                )
            except Exception as _llm_err:
                _exp = f"LLM bağlantısı kurulamadı: {str(_llm_err)[:200]}"
        st.session_state["demo_llm_explanation"] = _exp

    explanation = st.session_state["demo_llm_explanation"]

    # LLM başlık kartı
    st.markdown(
        DIV(
            "display:flex;align-items:center;gap:.7rem;margin-bottom:1rem;"
            "padding:.75rem 1rem;background:#e8f0fe;"
            "border:1px solid #c2d4f0;border-radius:10px;",
            DIV("font-size:1.2rem;", ""),
            DIV("",
                H("p",
                  "color:#1e3a6e;font-size:.72rem;font-weight:700;"
                  "letter-spacing:1.2px;text-transform:uppercase;margin:0;",
                  "ChurnLens AI &nbsp;·&nbsp; Llama 3.2 via Ollama"),
                H("p", "color:#4a6090;font-size:.68rem;margin:.1rem 0 0;",
                  "A Şirketi — Kurumsal Kurtarma Aksiyon Raporu — Otomatik Üretim"),
            ),
        ),
        unsafe_allow_html=True)

    # LLM metnini render et (main() fonksiyonundakiyle aynı mantık)
    import html as _html
    import re   as _re
    _safe = _html.escape(explanation)
    _safe = _re.sub(r'^### (.+)$',
                    r'<h4 style="color:#1e293b;font-size:.98rem;font-weight:700;margin:1.1rem 0 .4rem;">\1</h4>',
                    _safe, flags=_re.MULTILINE)
    _safe = _re.sub(r'^## (.+)$',
                    r'<h3 style="color:#0f172a;font-size:1.05rem;font-weight:800;margin:1.3rem 0 .5rem;">\1</h3>',
                    _safe, flags=_re.MULTILINE)
    _safe = _re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', _safe)
    _safe = _safe.replace('\n', '<br>')
    st.markdown(
        f'<div style="background:#f8f9fa;border:1px solid #dee2e6;'
        f'border-left:4px solid #6600cc;border-radius:10px;'
        f'padding:20px 24px;margin-top:.4rem;font-family:Inter,sans-serif;'
        f'font-size:.88rem;line-height:1.75;color:#1e293b;">{_safe}</div>',
        unsafe_allow_html=True)

    # İndirme + Yenile
    _dl_col, _regen_col = st.columns([2, 1])
    with _dl_col:
        st.download_button(
            label="Aksiyon Planını İndir (.md)",
            data=explanation.encode("utf-8"),
            file_name="churnlens_A_sirketi_aksiyon_plani.md",
            mime="text/markdown",
            key="demo_llm_download_btn",
        )
    with _regen_col:
        if st.button("Raporu Yenile", key="demo_llm_regen_btn"):
            st.session_state.pop("demo_llm_explanation", None)
            st.rerun()

    # ── Footer ───────────────────────────────────────────────────────────────────
    st.markdown("<hr style='border:none;border-top:1px solid #1e2a40;margin:1.5rem 0;'>",
                unsafe_allow_html=True)
    st.markdown(
        DIV("color:#1e3050;font-size:.7rem;text-align:center;",
            "<strong style='color:#2a4060;'>ChurnLens v2.0</strong> · "
            "Risk analizi · İyileştirme hedefleri · AI açıklaması"),
        unsafe_allow_html=True)


# ── M6: Model Performansı Sayfası ──────────────────────────────────────────────

def _get_mock_test_data(pipeline, n=800, seed=42):
    """Gerçek X_test/y_test yoksa gerçekçi (AUC ≈ 0.82-0.88) mock test verisi üretir.

    Strateji — Data Leakage'i önlemek için iki aşamalı gürültü:
      1. Model olasılıklarına büyük Gaussian gürültüsü eklenerek y_prob_noisy elde edilir.
         Bu, modelin "mükemmel"göründüğü AUC 0.99+ durumunu kırar.
      2. Ground-truth etiketler, y_prob_noisy'e bağımsız kalibrasyon gürültüsü eklenerek
         belirlenir; böylece eşik 0.35'te bile gerçekçi miktarda FN kalır.
    """
    rng = np.random.default_rng(seed)
    ab  = rng.integers(1, 60, size=n).astype(float)
    gi  = rng.integers(0, 200, size=n).astype(float)
    ak  = rng.integers(1, 100, size=n).astype(float)
    db  = rng.integers(0, 30, size=n).astype(float)
    uc  = rng.uniform(100, 5000, size=n).round(2)
    X_mock = pd.DataFrame({
        "Abonelik_Suresi_Ay"    : ab,
        "Aylik_Giris_Sayisi"    : gi,
        "Aktif_Kullanici_Sayisi": ak,
        "Destek_Bileti_Sayisi"  : db,
        "Aylik_Ucret_Euro"      : uc,
    })
    # Ham model olasılıkları
    y_prob_raw = pipeline.predict_proba(X_mock)[:, 1]

    # ── Aşama 1: Tahmin olasılığına büyük gürültü ekle (AUC'yi kır) ─────────────
    # std=0.18 → ROC eğrisini gerçekçi bir «iyi model» bandına çeker (AUC ~0.83-0.87)
    noise_pred = rng.normal(0.0, 0.18, n)
    y_prob     = np.clip(y_prob_raw + noise_pred, 0.01, 0.99)

    # ── Aşama 2: Ground-truth etiket — bağımsız kalibrasyon gürültüsüyle ────────
    # y_prob_raw üzerinden etiket üretilir; ayrıca %12 oranında rastgele flip ile
    # FN'lerin (özellikle düşük threshold'da) sıfıra düşmesi engellenir.
    noise_label = rng.normal(0.0, 0.12, n)
    y_true_soft = y_prob_raw + noise_label
    y_true      = (y_true_soft >= 0.48).astype(int)

    # Ek: %12 oranında rastgele etiket flip → gerçekçi sınıf gürültüsü
    flip_mask   = rng.random(n) < 0.12
    y_true[flip_mask] = 1 - y_true[flip_mask]

    return y_prob, y_true


def render_model_info_page(pipeline, train_df) -> None:
    """Model Performansı — Threshold Optimizasyonu + Confusion Matrix + ROC/AUC"""

    # ── Geri Butonu ─────────────────────────────────────────────────────────────
    if st.button("Ana Sayfaya Dön", key="model_info_back_btn"):
        st.session_state.current_page = "main"
        st.rerun()

    st.markdown(
        page_header(
            "Model performansı",
            "Karar eşiği ve model metrikleri",
            (
                "Recall ve precision dengesini inceleyin; confusion matrix "
                "ve ROC/AUC görünümüyle model davranışını değerlendirin."
            ),
            meta="XGBoost · Sklearn Metrics · Plotly",
        ),
        unsafe_allow_html=True)

    # ── Mock test verisi hazırla ─────────────────────────────────────────────────
    with st.spinner("Test verisi hazırlanıyor..."):
        y_prob, y_true = _get_mock_test_data(pipeline)

    # ════════════════════════════════════════════════════════════════════════════
    # BÖLÜM A: İnteraktif Threshold Slider + Dinamik Metrikler
    # ════════════════════════════════════════════════════════════════════════════
    st.markdown(
        H("h3", "color:#c8d8e8;font-size:1.05rem;font-weight:700;margin:1.2rem 0 .3rem;",
          "Karar Eşiği (Threshold) — Recall Optimizasyonu"),
        unsafe_allow_html=True)
    st.markdown(
        DIV(
            "background:rgba(0,170,255,0.07);border:1px solid rgba(0,170,255,0.2);"
            "border-left:3px solid #00aaff;border-radius:8px;padding:.75rem 1.1rem;"
            "color:#a0c4e8;font-size:.82rem;margin-bottom:1rem;",
            "Eşiği <strong>düşürdükçe</strong> → Recall (Duyarlılık) artar, daha fazla churn vakası yakalanır. "
            "Eşiği <strong>yükseltirseniz</strong> → Precision artar ancak bazı churn vakalarını kaçırabilirsiniz. "
            "Churn tahmini için <strong>Recall önceliklidir</strong>."
        ),
        unsafe_allow_html=True)

    threshold = st.slider(
        "Kadar Eşiği (Threshold) — Recall Optimizasyonu",
        min_value=0.10, max_value=0.90, value=0.35, step=0.01,
        key="m6_threshold_slider",
        help="Düşük eşik = Yüksek Recall | Yüksek eşik = Yüksek Precision"
    )

    # Eşiğe göre tahminler
    y_pred = (y_prob >= threshold).astype(int)

    # ── Metrikler ────────────────────────────────────────────────────────────────
    from sklearn.metrics import (
        confusion_matrix, accuracy_score, precision_score,
        recall_score, fbeta_score, roc_curve, auc
    )
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    accuracy  = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, zero_division=0)
    recall    = recall_score(y_true, y_pred, zero_division=0)
    f2        = fbeta_score(y_true, y_pred, beta=2, zero_division=0)

    # ── Metrik Kartları ──────────────────────────────────────────────────────────
    mc1, mc2, mc3, mc4 = st.columns(4)
    with mc1:
        st.metric(
            label="Accuracy",
            value=f"{accuracy:.3f}",
            delta=f"{accuracy*100:.1f}%",
            help="Genel doğruluk oranı"
        )
    with mc2:
        st.metric(
            label="Precision",
            value=f"{precision:.3f}",
            delta=f"{precision*100:.1f}%",
            help="Churn dediğimizde ne kadar haklıyız"
        )
    with mc3:
        delta_recall = recall - 0.70  # 0.70 referans değeri
        st.metric(
            label="Recall (Duyarlılık)",
            value=f"{recall:.3f}",
            delta=f"+{delta_recall*100:.1f}pp"if delta_recall >= 0 else f"{delta_recall*100:.1f}pp",
            delta_color="normal"if delta_recall >= 0 else "inverse",
            help="Gerçek churner'ları yakalama oranı — Maximize edilmeli!"
        )
    with mc4:
        st.metric(
            label="F2-Score",
            value=f"{f2:.3f}",
            delta=f"Threshold: {threshold:.2f}",
            delta_color="off",
            help="Recall'u 2x ağırlıklandıran F-beta skoru"
        )

    st.markdown("<br>", unsafe_allow_html=True)

    # ── Confusion Matrix (go.Heatmap) + TP/TN/FP/FN detay ──────────────────────
    col_cm, col_detail = st.columns([3, 2], gap="large")

    with col_cm:
        # ── Heatmap veri matrisi (sol-üst=TN, sağ-üst=FP, sol-alt=FN, sağ-alt=TP)
        # Eksen: x → Tahmin (0=Kalmaz, 1=Churn) | y → Gerçek (0=Kalmaz, 1=Churn)
        # Not: go.Heatmap y=0 satırını alta koyar; autorange="reversed"ile düzeltilir.
        z_vals   = [[int(tn), int(fp)],
                    [int(fn), int(tp)]]

        # Hücre renk kodları (normalize 0-1)
        color_scale = [
            [0.00, "rgba(0,204,102,0.55)"],   # TN  → yeşil
            [0.33, "rgba(255,184,0,0.50)"],    # FP  → turuncu
            [0.66, "rgba(255,68,68,0.60)"],    # FN  → kırmızı
            [1.00, "rgba(0,170,255,0.55)"],    # TP  → mavi
        ]
        # Hücrelere sabit renk atamak için z değerlerini sıralı integer olarak ver
        z_color = [[0, 1], [2, 3]]   # TN=0, FP=1, FN=2, TP=3

        fig_cm = go.Figure()

        # ── Arka plan renk katmanı (go.Heatmap) ─────────────────────────────────
        fig_cm.add_trace(go.Heatmap(
            z=z_color,
            x=["Tahmin: Kalmaz", "Tahmin: Churn"],
            y=["Gerçek: Kalmaz", "Gerçek: Churn"],
            colorscale=color_scale,
            showscale=False,
            zmin=0, zmax=3,
            xgap=4, ygap=4,
            hoverinfo="skip",
        ))

        # ── Üç satırlı annotation'lar: Etiket | Sayı | Açıklama ─────────────────
        cell_meta = [
            # (x_idx, y_idx, etiket, sayı, açıklama, yazı rengi)
            (0, 0, "TN",  int(tn), "Doğru Negatif",  TEXT),
            (1, 0, "FP",  int(fp), "Yanlış Pozitif", TEXT),
            (0, 1, "FN",  int(fn), "Yanlış Negatif", TEXT),
            (1, 1, "TP",  int(tp), "Doğru Pozitif",  TEXT),
        ]
        x_labels = ["Tahmin: Kalmaz", "Tahmin: Churn"]
        y_labels = ["Gerçek: Kalmaz", "Gerçek: Churn"]

        for xi, yi, lbl, cnt, desc, clr in cell_meta:
            # Satır 1 — Etiket (TN / FP / FN / TP)
            fig_cm.add_annotation(
                x=x_labels[xi], y=y_labels[yi],
                text=f"<b>{lbl}</b>",
                showarrow=False, yshift=28,
                font=dict(size=18, color=clr, family="Inter"),
                align="center",
            )
            # Satır 2 — Sayı (büyük ve bold)
            fig_cm.add_annotation(
                x=x_labels[xi], y=y_labels[yi],
                text=f"<b>{cnt:,}</b>",
                showarrow=False, yshift=0,
                font=dict(size=26, color=clr, family="Inter"),
                align="center",
            )
            # Satır 3 — Açıklama (küçük, soluk)
            fig_cm.add_annotation(
                x=x_labels[xi], y=y_labels[yi],
                text=desc,
                showarrow=False, yshift=-30,
                font=dict(size=11, color=TEXT_MUTED, family="Inter"),
                align="center",
            )

        fig_cm.update_xaxes(
            side="top",
            showgrid=False, zeroline=False,
            tickfont=dict(color="#6b8099", size=12, family="Inter"),
            tickangle=0,
            fixedrange=True,
        )
        fig_cm.update_yaxes(
            showgrid=False, zeroline=False,
            tickfont=dict(color="#6b8099", size=12, family="Inter"),
            autorange="reversed",
            fixedrange=True,
        )
        fig_cm.update_layout(
            title=dict(
                text=f"Confusion Matrix  |  Threshold = <b>{threshold:.2f}</b>",
                font=dict(size=14, color="#c8d8e8", family="Inter"),
                x=0.03,
            ),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(13,26,46,0.95)",
            height=380,
            margin=dict(t=90, b=20, l=20, r=20),
            font=dict(family="Inter"),
        )
        style_plotly(fig_cm, height=380)
        st.plotly_chart(fig_cm, width="stretch", config={"displayModeBar": False})

    with col_detail:
        st.markdown(
            H("h4", "color:#c8d8e8;font-size:.92rem;font-weight:700;margin-bottom:1rem;",
              "Matris Detayları"),
            unsafe_allow_html=True)

        detail_items = [
            ("TN — Doğru Negatif",  tn,  "rgba(0,204,102,0.12)",  "#00cc66",
             "Churn etmeyecek dendi, etmedi "),
            ("FP — Yanlış Pozitif",  fp,  "rgba(255,184,0,0.12)",  "#ffb800",
             "Churn edecek dendi, etmedi "),
            ("FN — Yanlış Negatif",  fn,  "rgba(255,68,68,0.12)",  "#ff4444",
             "Churn etmeyecek dendi, etti  (kritik!)"),
            ("TP — Doğru Pozitif",   tp,  "rgba(0,170,255,0.12)",  "#00aaff",
             "Churn edecek dendi, etti "),
        ]
        for label, count, bg, border, note in detail_items:
            st.markdown(
                DIV(
                    f"background:{bg};border:1px solid {border};"
                    "border-radius:10px;padding:.7rem 1rem;margin-bottom:.6rem;",
                    DIV(
                        "display:flex;justify-content:space-between;align-items:center;",
                        SPAN(f"color:{border};font-size:.78rem;font-weight:700;", label),
                        SPAN(f"color:#e8f0fe;font-size:1.3rem;font-weight:800;", f"{count:,}")
                    ),
                    SPAN("color:#4a6080;font-size:.7rem;", note)
                ),
                unsafe_allow_html=True)

        # Recall odaklı uyarı
        if recall >= 0.80:
            st.markdown(
                DIV("background:rgba(0,204,102,0.1);border:1px solid #00cc66;"
                    "border-radius:8px;padding:.6rem .9rem;margin-top:.5rem;"
                    "color:#6ee8a8;font-size:.76rem;font-weight:600;",
                    f"Recall = {recall:.2%} — Hedef karşılandı!"),
                unsafe_allow_html=True)
        elif recall >= 0.65:
            st.markdown(
                DIV("background:rgba(255,184,0,0.1);border:1px solid #ffb800;"
                    "border-radius:8px;padding:.6rem .9rem;margin-top:.5rem;"
                    "color:#e8c46a;font-size:.76rem;font-weight:600;",
                    f"Recall = {recall:.2%} — Eşiği düşür!"),
                unsafe_allow_html=True)
        else:
            st.markdown(
                DIV("background:rgba(255,68,68,0.1);border:1px solid #ff4444;"
                    "border-radius:8px;padding:.6rem .9rem;margin-top:.5rem;"
                    "color:#ff8888;font-size:.76rem;font-weight:600;",
                    f"Recall = {recall:.2%} — Kritik düşük! Eşiği azalt."),
                unsafe_allow_html=True)

    st.markdown("<hr style='border:none;border-top:1px solid #1e2a40;margin:1.8rem 0;'>",
                unsafe_allow_html=True)

    # ════════════════════════════════════════════════════════════════════════════
    # BÖLÜM B: ROC / AUC Eğrisi
    # ════════════════════════════════════════════════════════════════════════════
    st.markdown(
        H("h3", "color:#c8d8e8;font-size:1.05rem;font-weight:700;margin-bottom:.8rem;",
          "ROC Eğrisi (AUC Skoru)"),
        unsafe_allow_html=True)

    fpr, tpr, thresholds_roc = roc_curve(y_true, y_prob)
    roc_auc = auc(fpr, tpr)

    # Seçili threshold'un ROC üzerindeki noktası
    closest_idx = int(np.argmin(np.abs(thresholds_roc - threshold)))
    sel_fpr = float(fpr[closest_idx])
    sel_tpr = float(tpr[closest_idx])

    col_roc, col_roc_info = st.columns([3, 1], gap="large")

    with col_roc:
        fig_roc = go.Figure()

        # Dolgu (area under curve)
        fig_roc.add_trace(go.Scatter(
            x=list(fpr) + [1, 0],
            y=list(tpr) + [0, 0],
            fill="toself",
            fillcolor="rgba(0,170,255,0.08)",
            line=dict(color="rgba(0,0,0,0)"),
            showlegend=False, hoverinfo="skip"
        ))

        # ROC eğrisi
        fig_roc.add_trace(go.Scatter(
            x=fpr, y=tpr,
            mode="lines",
            name=f"ROC Eğrisi (AUC = {roc_auc:.4f})",
            line=dict(color="#00aaff", width=2.5),
            hovertemplate="FPR: %{x:.3f}<br>TPR: %{y:.3f}<extra></extra>"
        ))

        # Rastgele sınıflandırıcı (diagonal)
        fig_roc.add_trace(go.Scatter(
            x=[0, 1], y=[0, 1],
            mode="lines",
            name="Rastgele Sınıflandırıcı",
            line=dict(color="#3a5070", width=1.5, dash="dash"),
            hoverinfo="skip"
        ))

        # Seçili threshold noktası
        fig_roc.add_trace(go.Scatter(
            x=[sel_fpr], y=[sel_tpr],
            mode="markers+text",
            name=f"Eşik = {threshold:.2f}",
            marker=dict(color="#ffb800", size=12, symbol="circle",
                        line=dict(color="#fff", width=2)),
            text=[f"  T={threshold:.2f}"],
            textposition="middle right",
            textfont=dict(color="#ffb800", size=11),
            hovertemplate=f"Threshold={threshold:.2f}<br>FPR={sel_fpr:.3f}<br>TPR={sel_tpr:.3f}<extra></extra>"
        ))

        # AUC annotation
        fig_roc.add_annotation(
            x=0.72, y=0.15,
            text=f"<b>AUC = {roc_auc:.4f}</b>",
            showarrow=False,
            font=dict(size=16, color="#00aaff", family="Inter"),
            bgcolor="rgba(0,170,255,0.12)",
            bordercolor="#00aaff",
            borderwidth=1,
            borderpad=8
        )

        fig_roc.update_layout(
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(13,26,46,0.9)",
            height=400,
            margin=dict(t=40, b=50, l=60, r=20),
            font=dict(family="Inter", color="#6b8099"),
            legend=dict(
                x=0.02, y=0.98,
                bgcolor="rgba(13,26,46,0.85)",
                bordercolor="#1e3a5f",
                borderwidth=1,
                font=dict(size=11, color="#a0b4c8")
            ),
            xaxis=dict(
                title="False Positive Rate (FPR)",
                range=[0, 1.02],
                gridcolor="rgba(30,58,95,0.4)",
                zeroline=False,
                tickfont=dict(color="#4a6080")
            ),
            yaxis=dict(
                title="True Positive Rate (TPR / Recall)",
                range=[0, 1.02],
                gridcolor="rgba(30,58,95,0.4)",
                zeroline=False,
                tickfont=dict(color="#4a6080")
            ),
        )
        style_plotly(fig_roc, height=400)
        st.plotly_chart(fig_roc, width="stretch", config={"displayModeBar": False})

    with col_roc_info:
        st.markdown("<br><br>", unsafe_allow_html=True)

        # AUC yorum kartları
        if roc_auc >= 0.90:
            auc_label, auc_color, auc_bg = "Mükemmel", "#00cc66", "rgba(0,204,102,0.12)"
            auc_icon = ""
        elif roc_auc >= 0.80:
            auc_label, auc_color, auc_bg = "İyi", "#00aaff", "rgba(0,170,255,0.12)"
            auc_icon = ""
        elif roc_auc >= 0.70:
            auc_label, auc_color, auc_bg = "Orta", "#ffb800", "rgba(255,184,0,0.12)"
            auc_icon = ""
        else:
            auc_label, auc_color, auc_bg = "Zayıf", "#ff4444", "rgba(255,68,68,0.12)"
            auc_icon = ""

        st.markdown(
            DIV(
                f"background:{auc_bg};border:1px solid {auc_color};"
                "border-radius:12px;padding:1.2rem 1.1rem;text-align:center;"
                "margin-bottom:.8rem;",
                DIV("font-size:2rem;margin-bottom:.4rem;", auc_icon),
                DIV(f"color:{auc_color};font-size:2rem;font-weight:800;",
                    f"{roc_auc:.4f}"),
                DIV(f"color:{auc_color};font-size:.72rem;font-weight:600;"
                    "text-transform:uppercase;letter-spacing:.8px;",
                    f"AUC — {auc_label}"),
            ),
            unsafe_allow_html=True)

        st.markdown(
            DIV(
                "background:#0d1a2e;border:1px solid #1e3a5f;border-radius:10px;"
                "padding:.9rem 1rem;",
                DIV("color:#6b8099;font-size:.68rem;font-weight:600;text-transform:uppercase;"
                    "letter-spacing:.8px;margin-bottom:.6rem;", "Seçili Eşik Noktası"),
                DIV("display:flex;justify-content:space-between;margin-bottom:.3rem;",
                    SPAN("color:#4a6080;font-size:.75rem;", "Threshold:"),
                    SPAN("color:#ffb800;font-size:.75rem;font-weight:700;", f"{threshold:.2f}")
                ),
                DIV("display:flex;justify-content:space-between;margin-bottom:.3rem;",
                    SPAN("color:#4a6080;font-size:.75rem;", "TPR (Recall):"),
                    SPAN("color:#00aaff;font-size:.75rem;font-weight:700;", f"{sel_tpr:.3f}")
                ),
                DIV("display:flex;justify-content:space-between;",
                    SPAN("color:#4a6080;font-size:.75rem;", "FPR:"),
                    SPAN("color:#ff4444;font-size:.75rem;font-weight:700;", f"{sel_fpr:.3f}")
                ),
            ),
            unsafe_allow_html=True)

        st.markdown(
            DIV(
                "background:rgba(0,170,255,0.06);border:1px solid rgba(0,170,255,0.15);"
                "border-radius:8px;padding:.75rem .9rem;margin-top:.7rem;"
                "color:#4a6080;font-size:.72rem;line-height:1.6;",
                "<strong style='color:#a0c4e8;'>AUC</strong>: Olasılık tahmininin kalitesini ölçer. "
                "1.0 = Mükemmel · 0.5 = Rastgele"
            ),
            unsafe_allow_html=True)

    # ── Footer ───────────────────────────────────────────────────────────────────
    st.markdown("<hr style='border:none;border-top:1px solid #1e2a40;margin:1.5rem 0;'>",
                unsafe_allow_html=True)
    st.markdown(
        DIV("color:#1e3050;font-size:.7rem;text-align:center;",
            "<strong style='color:#2a4060;'>ChurnLens v2.0</strong> · "
            "Sprint · XGBoost · Sklearn Metrics · Plotly · Streamlit"),
        unsafe_allow_html=True)


# ── M5: Toplu Müşteri Analizi — Tam Ekran Sayfa ─────────────────────────────────

def render_csv_page() -> None:
    """Toplu Müşteri Analizi — CSV yükleme, doğrulama ve tam ekran gösterim sayfası."""

    st.markdown(
        page_header(
            "Toplu analiz",
            "Müşteri verisi yükleme ve doğrulama",
            (
                "CSV dosyanızı yükleyin, kolonları otomatik doğrulayın ve "
                "müşteri risklerini tek tabloda önceliklendirin."
            ),
        ),
        unsafe_allow_html=True)

    # ── Bilgi Kutusu + Şablon İndirme Butonu ───────────────────────────────────
    info_col, dl_col = st.columns([3, 1], gap="large")

    with info_col:
        st.markdown(
            DIV(
                "background:rgba(255,184,0,0.07);border:1px solid rgba(255,184,0,0.25);"
                "border-left:4px solid #ffb800;border-radius:10px;"
                "padding:.9rem 1.2rem;color:#c8a84a;font-size:.84rem;line-height:1.7;",
                "CSV dosyanızdaki kolon adları şablonla "
                "<strong style='color:#ffe080;'>birebir</strong> eşleşmelidir. "
                "Sıra önemli değildir, ancak kolon <em>isimleri</em> aynı olmalıdır. "
                "Hazır şablonu indirip doldurmanız önerilir."
            ),
            unsafe_allow_html=True)

    with dl_col:
        st.markdown("<br>", unsafe_allow_html=True)
        template_df  = pd.DataFrame(columns=EXPECTED_CSV_COLS)
        csv_template = template_df.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="Örnek CSV Şablonunu İndir",
            data=csv_template,
            file_name="churnlens_musteri_sablonu.csv",
            mime="text/csv",
            key="csv_page_template_btn",
            help="Boş şablonu indirin, verilerinizi doldurun ve aşağıdan yükleyin.",
        )

    st.markdown("<hr style='border:none;border-top:1px solid #1e2a40;margin:1.4rem 0;'>",
                unsafe_allow_html=True)

    # ── Beklenen Kolon Tablosu ────────────────────────────────────────────────────
    with st.expander("Beklenen Kolon Listesi", expanded=False):
        schema_items = [
            ("Abonelik_Suresi_Ay",     "Tüm sayı",    "Ay cinsinden abonelik süresi (1-60)"),
            ("Aylik_Giris_Sayisi",     "Tüm sayı",    "Aylık sisteme giriş sayısı (0-200)"),
            ("Aktif_Kullanici_Sayisi", "Tüm sayı",    "Aktif kullanıcı sayısı (1-100)"),
            ("Destek_Bileti_Sayisi",   "Tüm sayı",    "Açık destek bileti sayısı (0-30)"),
            ("Aylik_Ucret_Euro",       "Ondalikli sayı", "Aylık abonelik ücreti (Euro)"),
        ]
        schema_rows = "".join(
            f"<tr style='border-bottom:1px solid #1e2a40;'>"
            f"<td style='padding:.45rem .8rem;color:#a0c4e8;font-family:monospace;font-size:.82rem;'>{col}</td>"
            f"<td style='padding:.45rem .8rem;color:#4a6080;font-size:.78rem;'>{dtype}</td>"
            f"<td style='padding:.45rem .8rem;color:#6b8099;font-size:.78rem;'>{note}</td>"
            f"</tr>"
            for col, dtype, note in schema_items
        )
        st.markdown(
            f"<table style='width:100%;border-collapse:collapse;background:#0d1a2e;'>"
            f"<thead><tr style='border-bottom:2px solid #1e3a5f;'>"
            f"<th style='padding:.45rem .8rem;color:#6b8099;font-size:.72rem;text-align:left;"
            f"text-transform:uppercase;letter-spacing:.8px;'>Kolon Adı</th>"
            f"<th style='padding:.45rem .8rem;color:#6b8099;font-size:.72rem;text-align:left;"
            f"text-transform:uppercase;letter-spacing:.8px;'>Tip</th>"
            f"<th style='padding:.45rem .8rem;color:#6b8099;font-size:.72rem;text-align:left;"
            f"text-transform:uppercase;letter-spacing:.8px;'>Açıklama</th>"
            f"</tr></thead><tbody>{schema_rows}</tbody></table>",
            unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # ── Dosya Yükleme ────────────────────────────────────────────────────────────────
    st.markdown(
        H("h3", "color:#c8d8e8;font-size:1rem;font-weight:700;margin-bottom:.7rem;",
          "CSV Dosyası Yükle"),
        unsafe_allow_html=True)

    uploaded_file = st.file_uploader(
        "CSV dosyasını buraya sürükleyin veya seçin",
        type=["csv"],
        key="csv_page_uploader",
        help="Yalnızca şablona uygun CSV dosyaları kabul edilir.",
    )

    # ── Doğrulama ve Gösterim ─────────────────────────────────────────────────────────
    if uploaded_file is not None:
        try:
            uploaded_df   = pd.read_csv(uploaded_file)
            uploaded_cols = set(uploaded_df.columns.tolist())
            expected_cols = set(EXPECTED_CSV_COLS)

            # ── KOLON DOĞRULAMA ───────────────────────────────────────────────────────
            if not expected_cols.issubset(uploaded_cols):
                missing     = expected_cols - uploaded_cols
                missing_str = ", ".join(f"<code style='background:rgba(255,68,68,0.15);"
                                        f"padding:.1rem .35rem;border-radius:4px;'>{c}</code>"
                                        for c in sorted(missing))
                st.markdown(
                    DIV(
                        "background:rgba(255,68,68,0.10);border:1px solid rgba(255,68,68,0.4);"
                        "border-left:4px solid #ff4444;border-radius:12px;"
                        "padding:1.1rem 1.4rem;margin-top:.8rem;"
                        "color:#ffaaaa;font-size:.84rem;line-height:1.8;",
                        "<strong style='font-size:.95rem;'> Hatali CSV Formati!</strong><br>"
                        "Yülediginiz dosyadaki sütun isimleri sistemle uyuşmamaktadir. "
                        "Lütfen örnek şablonu indirerek sütun adlarını değiştirmeden tekrar yükleyiniz.<br>"
                        f"<span style='color:#cc6666;font-size:.78rem;'>Eksik sütunlar: {missing_str}</span>"
                    ),
                    unsafe_allow_html=True)

            else:
                # ── FORMAT DOĞRU → İSTATISTIK + TAM EKRAN TABLO ──────────────────────
                row_count = len(uploaded_df)
                display_df = uploaded_df[EXPECTED_CSV_COLS].copy()

                # ── Özet metrik kartları ─────────────────────────────────────────────
                st.markdown(
                    DIV(
                        "background:rgba(0,204,102,0.08);border:1px solid rgba(0,204,102,0.3);"
                        "border-left:4px solid #00cc66;border-radius:12px;"
                        "padding:.9rem 1.3rem;margin-bottom:1.2rem;"
                        "display:flex;align-items:center;gap:1rem;flex-wrap:wrap;",
                        SPAN("font-size:1.6rem;", ""),
                        DIV("",
                            H("p", "color:#00cc66;font-size:.95rem;font-weight:700;margin:0;",
                              f" {row_count} müşteri verisi başarıyla yülendi"),
                            H("p", "color:#4a8060;font-size:.78rem;margin:.2rem 0 0;",
                              f"Kolon sayısı: {len(display_df.columns)} · "
                              f"Boş değer sayısı: {display_df.isnull().sum().sum()}"),
                        )
                    ),
                    unsafe_allow_html=True)

                sm1, sm2, sm3, sm4 = st.columns(4)
                with sm1:
                    st.metric("Toplam Müşteri", f"{row_count:,}")
                with sm2:
                    avg_ab = display_df["Abonelik_Suresi_Ay"].mean()
                    st.metric("Ort. Abonelik Süresi", f"{avg_ab:.1f} ay")
                with sm3:
                    avg_uc = display_df["Aylik_Ucret_Euro"].mean()
                    st.metric("Ort. Aylık Ücret", f"€{avg_uc:,.0f}")
                with sm4:
                    high_risk = (display_df["Destek_Bileti_Sayisi"] >= 15).sum()
                    st.metric("Yüksek Bilet", f"{high_risk} müşteri")

                st.markdown("<br>", unsafe_allow_html=True)

                # ── Tam Ekran Tablo ────────────────────────────────────────────────────
                st.markdown(
                    H("h4", "color:#c8d8e8;font-size:.92rem;font-weight:700;margin-bottom:.6rem;",
                      "Müşteri Veri Tablosu"),
                    unsafe_allow_html=True)

                display_df_renamed = display_df.rename(columns=FEATURE_LABELS)
                st.dataframe(display_df_renamed, width="stretch")

                # ── İndirme Butonu ──────────────────────────────────────────────────────
                st.download_button(
                    label="Dogrulanmis Veriyi İndir (.csv)",
                    data=display_df.to_csv(index=False).encode("utf-8"),
                    file_name="churnlens_dogrulanmis_musteri_verisi.csv",
                    mime="text/csv",
                    key="csv_page_download_validated",
                )

                st.markdown("<br>", unsafe_allow_html=True)

                # ══════════════════════════════════════════════════════════════════════
                # M5 — TOPLU RİSK TARAMASI (XGBoost)
                # ══════════════════════════════════════════════════════════════════════
                st.markdown(
                    H("h4", "color:#c8d8e8;font-size:.92rem;font-weight:700;margin-bottom:.5rem;",
                      "Toplu Risk Taraması"),
                    unsafe_allow_html=True)
                st.markdown(
                    DIV(
                        "background:rgba(0,170,255,0.06);border:1px solid rgba(0,170,255,0.2);"
                        "border-left:3px solid #00aaff;border-radius:8px;padding:.7rem 1.1rem;"
                        "color:#6b8099;font-size:.8rem;margin-bottom:.9rem;",
                        "XGBoost modeli tüm müşterileri tek seferde tarayarak "
                        "<strong style='color:#a0c4e8;'>Churn Olasılık Skoru</strong>'nu hesaplar. "
                        "Butona basıldığında sonuçlar tablonun altında görünür."
                    ),
                    unsafe_allow_html=True)

                if st.button("Toplu Risk Taramasını Başlat", type="primary",
                             key="csv_bulk_risk_btn"):
                    # ── Modeli al (zaten cache'lenmiş) ───────────────────────────────
                    try:
                        _bulk_pipeline, _ = load_or_train_model()

                        # ── Feature kolonlarını temizleyerek predict_proba ────────────
                        _score_df = display_df[FEATURE_COLS].copy()
                        _score_df = _replace_string_nans(_score_df, FEATURE_COLS)
                        for _col in FEATURE_COLS:
                            if _score_df[_col].isnull().any():
                                _fv = (_score_df[_col].dropna().mode().iloc[0]
                                       if _col in {"Aylik_Giris_Sayisi", "Aktif_Kullanici_Sayisi",
                                                   "Destek_Bileti_Sayisi", "Abonelik_Suresi_Ay"}
                                       else _score_df[_col].median())
                                _score_df[_col] = _score_df[_col].fillna(_fv)

                        _proba = _bulk_pipeline.predict_proba(_score_df)[:, 1]

                        # ── Risk skoru kolonunu orijinal df'e ekle ───────────────────
                        _result_df = display_df.copy()
                        _result_df["Risk Skoru (%)"] = (_proba * 100).round(1)
                        RISK_THRESHOLD = 50.0

                        # ── KPI Sayaçları ─────────────────────────────────────────────
                        _total    = len(_result_df)
                        _risky    = int((_result_df["Risk Skoru (%)"] > RISK_THRESHOLD).sum())
                        _safe     = _total - _risky

                        # ── KPI Kartları (st.columns + st.metric) ────────────────────
                        st.markdown(
                            H("h4", "color:#c8d8e8;font-size:.95rem;font-weight:700;"
                              "margin:1.4rem 0 .8rem;",
                              "Tarama Özeti"),
                            unsafe_allow_html=True)

                        _kpi1, _kpi2, _kpi3 = st.columns(3)
                        with _kpi1:
                            st.metric(
                                label="Toplam Müşteri",
                                value=f"{_total:,}",
                            )
                        with _kpi2:
                            st.metric(
                                label="Riskli Müşteri",
                                value=f"{_risky:,}",
                                delta=f"%{_risky/_total*100:.1f} risk oranı",
                                delta_color="inverse",
                            )
                        with _kpi3:
                            st.metric(
                                label="Güvenli Müşteri",
                                value=f"{_safe:,}",
                                delta=f"%{_safe/_total*100:.1f} güvenli oran",
                                delta_color="normal",
                            )

                        st.markdown("<br>", unsafe_allow_html=True)

                        # ── Renklendirilmiş Sonuç Tablosu ────────────────────────────
                        st.markdown(
                            H("h4", "color:#c8d8e8;font-size:.9rem;font-weight:700;"
                              "margin-bottom:.5rem;",
                              "Risk Skorlu Müşteri Tablosu"),
                            unsafe_allow_html=True)

                        _display_result = _result_df.rename(columns=FEATURE_LABELS)
                        _display_result = _display_result.rename(
                            columns={"Risk Skoru (%)": "Risk Skoru (%)"})

                        def _color_risk_rows(row):
                            risk_val = row.get("Risk Skoru (%)", 0)
                            if isinstance(risk_val, str):
                                try:
                                    risk_val = float(risk_val.replace("%", "").strip())
                                except:
                                    risk_val = 0.0
                            else:
                                try:
                                    risk_val = float(risk_val)
                                except:
                                    risk_val = 0.0
                                    
                            if risk_val > RISK_THRESHOLD:
                                return [
                                    "background-color: #fff5e7; color: #7a470f;"
                                ] * len(row)
                            else:
                                return [
                                    "background-color: #ecf6f1; color: #245f4b;"
                                ] * len(row)

                        _styled = (
                            _display_result.style
                            .apply(_color_risk_rows, axis=1)
                            .format({"Risk Skoru (%)": "{:.1f}%"})
                        )
                        st.dataframe(_styled, width="stretch", height=480)
                        # ── Risk Skorlu CSV İndirme ───────────────────────────────────
                        st.download_button(
                            label="Risk Skorlu Veriyi İndir (.csv)",
                            data=_result_df.to_csv(index=False).encode("utf-8"),
                            file_name="churnlens_risk_skorlu_musteri_verisi.csv",
                            mime="text/csv",
                            key="csv_page_download_risk_scored",
                        )

                        # ── Kurumsal Bilgi Notu ───────────────────────────────────────
                        st.markdown("<br>", unsafe_allow_html=True)
                        st.info(
                            " **Bilgi:** Toplu analiz tamamlandı. Yüksek riskli müşteriler tespit edildi. "
                            "Bu müşteriler için ayrıntılı iyileştirme hedefleri ve AI aksiyon planları "
                            "arka planda asenkron olarak oluşturulmaktadır. Tamamlandığında sistem "
                            "yöneticisine e-posta raporu olarak iletilecektir. Bireysel acil müdahale "
                            "için **'Manuel Analiz'** ekranını kullanabilirsiniz."
                        )

                    except Exception as _bulk_err:
                        st.error(
                            f"Toplu risk taraması sırasında hata oluştu: {str(_bulk_err)[:300]}"
                        )

        except Exception as csv_err:
            st.markdown(
                DIV(
                    "background:rgba(255,68,68,0.10);border:1px solid rgba(255,68,68,0.35);"
                    "border-left:4px solid #ff4444;border-radius:12px;"
                    "padding:1rem 1.3rem;margin-top:.8rem;color:#ffaaaa;font-size:.84rem;",
                    f"<strong>Dosya okunamadi:</strong> {str(csv_err)[:300]}"
                ),
                unsafe_allow_html=True)
    else:
        # Dosya henüz yülenmedi — placeholder
        st.markdown(
            DIV(
                "background:rgba(255,184,0,0.04);border:2px dashed rgba(255,184,0,0.2);"
                "border-radius:16px;padding:3rem;text-align:center;margin-top:1rem;",
                H("p", "font-size:3rem;margin:0 0 .8rem;", ""),
                H("p",
                  "color:#5a6a4a;font-size:.95rem;font-weight:600;margin:0 0 .35rem;",
                  "Henüz CSV dosyası yülenmedi"),
                H("p",
                  "color:#3a4a30;font-size:.78rem;margin:0;",
                  "Yukarıdaki alanı kullanarak şablona uygun CSV dosyanızı yükleyin."),
            ),
            unsafe_allow_html=True)

    # ── Footer ──────────────────────────────────────────────────────────────────
    st.markdown("<hr style='border:none;border-top:1px solid #1e2a40;margin:1.5rem 0;'>",
                unsafe_allow_html=True)
    st.markdown(
        DIV("color:#1e3050;font-size:.7rem;text-align:center;",
            "<strong style='color:#2a4060;'>ChurnLens v2.0</strong> · "
            "M5 CSV Analizi · Pandas · Streamlit"),
        unsafe_allow_html=True)


# ── Sidebar ─────────────────────────────────────────────────────────────────────

def build_sidebar():
    with st.sidebar:
        # ── Logo / Başlık ────────────────────────────────────────────────────────────
        st.markdown(
            DIV(f"color:{TEXT_MUTED};font-size:.69rem;font-weight:600;text-transform:uppercase;"
                "letter-spacing:1.4px;margin-bottom:.5rem;padding-bottom:.5rem;"
                f"border-bottom:1px solid {BORDER};", "ChurnLens"),
            unsafe_allow_html=True)
        st.markdown(
            DIV(f"color:{TEXT_MUTED};font-size:.77rem;margin-bottom:1.3rem;line-height:1.5;",
                "B2B SaaS Müşteri Kaybı<br>Önleme Motoru v2.0"),
            unsafe_allow_html=True)

        # ════════════════════════════════════════════════════════════════════════════
        # SAYFA NAVİGASYONU — st.radio ile tek, düzgün menü
        # current_page değeri bu seçime göre session_state'e yazılır.
        # ════════════════════════════════════════════════════════════════════════════
        st.markdown(
            DIV(f"color:{TEXT_MUTED};font-size:.69rem;font-weight:600;text-transform:uppercase;"
                "letter-spacing:1.4px;margin-bottom:.6rem;", "Sayfa Seç"),
            unsafe_allow_html=True)

        # Sayfa anahtarı → görünen etiket eşleştirmesi
        _PAGE_OPTIONS = {
            "main"       : "Bireysel Analiz",
            "demo"       : "Canlı Demo Senaryosu",
            "model_info" : "Model Performansı",
            "csv_upload" : "Toplu Müşteri Analizi",
        }
        _cur_page = st.session_state.get("current_page", "main")
        # Geçersiz bir sayfa key'i varsa ana sayfaya düş
        if _cur_page not in _PAGE_OPTIONS:
            _cur_page = "main"

        _selected_label = st.radio(
            label="Sayfa",
            options=list(_PAGE_OPTIONS.values()),
            index=list(_PAGE_OPTIONS.keys()).index(_cur_page),
            key="sidebar_nav_radio",
            label_visibility="collapsed",
        )

        # Seçilen etiketin anahtarını bul ve session_state'e yaz
        _new_page = next(k for k, v in _PAGE_OPTIONS.items() if v == _selected_label)
        if _new_page != _cur_page:
            st.session_state.current_page = _new_page
            # Demo sayfası tıklaması LLM önbelleğini temizlesin
            if _new_page != "demo":
                st.session_state.pop("demo_llm_explanation", None)
            st.rerun()

        st.markdown("<hr style='border:none;border-top:1px solid #1e2a40;margin:1.1rem 0;'>",
                    unsafe_allow_html=True)

        # ── Profil Girişi (yalnızca Bireysel Analiz sayfasında görünür) ────────────────
        st.markdown(
            DIV(f"color:{TEXT_MUTED};font-size:.69rem;font-weight:600;text-transform:uppercase;"
                "letter-spacing:1.4px;margin-bottom:.8rem;padding-bottom:.5rem;"
                f"border-bottom:1px solid {BORDER};", "Müşteri Profil Girişi"),
            unsafe_allow_html=True)

        # Slider'lar key= parametresiyle Streamlit widget state'ine bağlıdır.
        abonelik = st.slider("Abonelik Süresi (Ay)",   1,  60,  9, key="s_ab")
        giris    = st.slider("Aylık Giriş Sayısı",     0, 200, 62, key="s_gi")
        aktif    = st.slider("Aktif Kullanıcı Sayısı", 1, 100, 22, key="s_ak")
        bilet    = st.slider("Destek Bileti Sayısı",   0,  30, 28, key="s_db")
        ucret    = st.number_input(
            "Aylık Ücret (€)",
            min_value=100.0, max_value=5000.0,
            value=3427.35, step=50.0, format="%.2f", key="n_uc",
        )

        st.markdown("<hr style='border:none;border-top:1px solid #1e2a40;margin:1.2rem 0;'>",
                    unsafe_allow_html=True)
        btn = st.button("Müşteri Riskini Analiz Et", key="analyze_btn")

        st.markdown("<hr style='border:none;border-top:1px solid #1e2a40;margin:1.2rem 0;'>",
                    unsafe_allow_html=True)
        st.markdown(
            DIV("color:#1e3050;font-size:.68rem;text-align:center;",
                "XGBoost tabanlı karar desteği<br>2026 ChurnLens Analytics"),
            unsafe_allow_html=True)

    return {
        "Abonelik_Suresi_Ay"    : float(abonelik),
        "Aylik_Giris_Sayisi"    : float(giris),
        "Aktif_Kullanici_Sayisi": float(aktif),
        "Destek_Bileti_Sayisi"  : float(bilet),
        "Aylik_Ucret_Euro"      : float(ucret),
    }, btn


# ── Ana Uygulama ────────────────────────────────────────────────────────────────

def main():
    # ── Sayfa Durumu (Routing) ──────────────────────────────────────────────────
    if "current_page"not in st.session_state:
        st.session_state.current_page = "main"

    st.markdown(html_header(), unsafe_allow_html=True)
    input_vals, analyze_btn = build_sidebar()

    with st.spinner("Model yükleniyor..."):
        try:
            pipeline, model_status = load_or_train_model()
            train_df = load_train_data()
        except Exception as e:
            st.error(f"Model yüklenirken hata: {e}")
            st.code(traceback.format_exc())
            st.stop()

    # ── Sayfa Yönlendirme ─────────────────────────────────────────────────────
    # Her sayfa için ilgili render fonksiyonu çalışır ve return ile diğer
    # sayfaların üstlerine yazılması engellenir.
    if st.session_state.get("current_page", "main") == "demo":
        render_demo_page(pipeline, train_df)
        return

    if st.session_state.get("current_page", "main") == "model_info":
        render_model_info_page(pipeline, train_df)
        return

    if st.session_state.get("current_page", "main") == "csv_upload":
        render_csv_page()
        return

    # ════════════════════════════════════════════════════════════════════════════
    # ANA SAYFA — Manuel Risk Analizi (current_page == "main")
    # Aşağıdaki tüm kod aynen korunmaktadır; routing dışında hiçbir satıra
    # dokunulmamıştır.
    # ════════════════════════════════════════════════════════════════════════════
    if model_status == "trained":
        st.markdown(
            html_info_box(
                "Kayıtlı model bulunamadığı için yeni bir model hazırlandı. "
                "Analiz bu oturumda oluşturulan modelle devam ediyor.",
                WARNING,
                WARNING_TINT,
                WARNING,
            ),
            unsafe_allow_html=True,
        )

    query_df   = pd.DataFrame([input_vals])
    churn_prob = float(pipeline.predict_proba(query_df)[0, 1])
    pct        = churn_prob * 100

    profile = risk_profile(churn_prob)
    risk_level = profile["level"]
    risk_text = profile["label"].upper()
    risk_color = profile["color"]
    benchmarks = healthy_benchmarks(train_df)
    feature_importance = dict(
        zip(FEATURE_COLS, pipeline.named_steps["clf"].feature_importances_)
    )
    customer_reasons = build_customer_reasons(
        input_vals,
        benchmarks,
        feature_importance,
    )

    st.markdown(
        html_risk_overview(churn_prob, profile, customer_reasons),
        unsafe_allow_html=True,
    )

    # ── DiCE çıktıları session_state ile sekmeler arası paylaşılır ────────────────
    # Tab2 (DiCE) içinde hesaplanan cf_df, Tab3 (LLM) için de kullanılacak.
    # Her analiz tetiklendiğinde önceki LLM sonucu sıfırlanır.
    if analyze_btn:
        st.session_state.pop("llm_explanation", None)
        st.session_state.pop("llm_dice_outputs", None)

    tab1, tab2, tab3 = st.tabs([
        "Genel Bakış",
        "İyileştirme Planı",
        "AI Açıklaması",
    ])

    with tab1:
        st.markdown(
            H(
                "h3",
                "color:#dce7f6;font-size:1.05rem;font-weight:700;margin:.8rem 0 .35rem;",
                "Bu Sonucun Temel Nedenleri",
            ),
            unsafe_allow_html=True,
        )
        st.caption(
            "Aşağıdaki nedenler, bu müşterinin metriklerini düşük riskli müşteri "
            "grubunun medyan değerleriyle ve model önemleriyle karşılaştırır."
        )
        st.markdown(
            html_reason_cards(customer_reasons),
            unsafe_allow_html=True,
        )

        st.markdown(
            H(
                "h3",
                "color:#dce7f6;font-size:1.05rem;font-weight:700;margin:1rem 0 .35rem;",
                "Müşteri Metrikleri ve Sağlıklı Referans",
            ),
            unsafe_allow_html=True,
        )
        st.caption(
            "Referans değerler, eğitim verisindeki churn etmeyen müşterilerin medyanıdır."
        )
        st.markdown(
            html_metric_comparison_cards(input_vals, benchmarks),
            unsafe_allow_html=True,
        )
        st.markdown(
            html_info_box(
                "Bu açıklamalar karar desteği içindir. Karşılaştırmalar ilişkiyi "
                "gösterir; tek başına nedensellik kanıtlamaz.",
                INFO,
                INFO_TINT,
                INFO,
            ),
            unsafe_allow_html=True,
        )

    with tab2:
        st.markdown(
            H("h3", "color:#c8d8e8;font-size:1.05rem;font-weight:600;margin-bottom:.6rem;",
              "Riski Azaltmak İçin Önerilen Hedefler"),
            unsafe_allow_html=True)
        st.markdown(html_info_box(
            "<strong>Değiştirilemeyen alanlar:</strong> Abonelik süresi ve aylık ücret "
            "geçmişe ya da sözleşmeye bağlı olduğu için sabit tutulur. Plan yalnızca "
            "müşteri başarı ekibinin etkileyebileceği kullanım ve destek metriklerini değiştirir.",
            "#00aaff", "rgba(0,170,255,0.07)", "#a0c4e8"), unsafe_allow_html=True)

        if risk_level == "low":
            st.markdown(html_info_box(
                "Churn riski düşük olduğu için ek bir iyileştirme senaryosu gerekmiyor.",
                "#00cc66", "rgba(0,204,102,0.07)", "#6ee8a8"), unsafe_allow_html=True)
            # Düşük risk için LLM'e sade profil özeti gönderilecek
            if "llm_dice_outputs"not in st.session_state:
                st.session_state["llm_dice_outputs"] = {
                    "current"   : input_vals,
                    "cf_list"   : [],
                    "churn_prob": churn_prob,
                }
        else:
            with st.spinner("İyileştirme hedefleri hesaplanıyor..."):
                try:
                    explainer = build_dice_explainer(pipeline, train_df)
                    cf_result = explainer.generate_counterfactuals(
                        query_df.copy().reset_index(drop=True),
                        total_CFs=N_CFs, desired_class=0,
                        features_to_vary=FEATURES_TO_VARY, random_seed=RANDOM_STATE,
                    )
                    cf_df = (cf_result.cf_examples_list[0]
                             .final_cfs_df[FEATURE_COLS]
                             .reset_index(drop=True))
                    st.markdown(html_action_cards(query_df.iloc[0], cf_df),
                                unsafe_allow_html=True)
                    with st.expander("Teknik hedef değerleri", expanded=False):
                        st.dataframe(cf_df.rename(columns=FEATURE_LABELS).style.format(precision=1),
                                     width="stretch")
                    # Hedefleri LLM sekmesi için session_state'e kaydet
                    if "llm_dice_outputs"not in st.session_state:
                        st.session_state["llm_dice_outputs"] = {
                            "current"   : input_vals,
                            "cf_list"   : cf_df.to_dict(orient="records"),
                            "churn_prob": churn_prob,
                        }
                except Exception as e:
                    st.error(f"İyileştirme planı oluşturulamadı: {e}")
                    st.code(traceback.format_exc())
                    # Plan üretilemese bile LLM sekmesi temel bilgiyle çalışır
                    if "llm_dice_outputs"not in st.session_state:
                        st.session_state["llm_dice_outputs"] = {
                            "current"   : input_vals,
                            "cf_list"   : [],
                            "churn_prob": churn_prob,
                        }

    # ── TAB 3: AI Aksiyon Planı (LLM Entegrasyonu) ──────────────────────
    with tab3:
        # ── Başlık ve Açıklama ────────────────────────────────────────────────
        st.markdown(
            H("h3",
              "color:#c8d8e8;font-size:1.05rem;font-weight:600;margin-bottom:.3rem;",
              "Yapay Zeka Destekli Kurumsal Aksiyon Planı"),
            unsafe_allow_html=True)
        st.markdown(
            DIV(
                f"background:{INFO_TINT};border:1px solid {BORDER};"
                f"border-left:3px solid {INFO};"
                "border-radius:10px;padding:.85rem 1.2rem;margin-bottom:1.2rem;"
                f"color:{TEXT};font-size:.83rem;line-height:1.6;",
                "<strong>Ollama yerel modeli</strong>, müşteri risk profilini ve iyileştirme "
                "hedeflerini okuyarak Türkçe bir müşteri başarı planı üretir. Ollama servisi "
                "çalışmıyorsa analiz sonuçları kullanılmaya devam eder."
            ),
            unsafe_allow_html=True)

        # ── Risk Badge ────────────────────────────────────────────────────────
        badge_color = {"high": "#ff4444", "medium": "#ffb800", "low": "#00cc66"}.get(risk_level, "#00aaff")
        badge_bg    = {"high": "rgba(255,68,68,0.12)", "medium": "rgba(255,184,0,0.12)",
                       "low": "rgba(0,204,102,0.12)"}.get(risk_level, "rgba(0,170,255,0.12)")
        badge_label = {"high": "YÜKSEK RİSK", "medium": "ORTA RİSK",
                       "low": "DÜŞÜK RİSK"}.get(risk_level, risk_text)
        st.markdown(
            DIV(
                "display:flex;align-items:center;gap:1rem;margin-bottom:1.2rem;flex-wrap:wrap;",
                DIV(
                    f"background:{badge_bg};border:1px solid {badge_color};"
                    f"color:{badge_color};font-size:.78rem;font-weight:700;"
                    "padding:.35rem .9rem;border-radius:20px;letter-spacing:.5px;",
                    badge_label
                ),
                DIV(
                    "color:#4a6080;font-size:.78rem;",
                    f"Churn Olasılığı: <strong style='color:#a0b4c8;'>{pct:.1f}%</strong> &nbsp;·&nbsp; "
                    
                ),
            ),
            unsafe_allow_html=True)

        # ── LLM Tetikleyici Buton ────────────────────────────────────────────
        # Kullanıcı isteğe bağlı olarak planı yenileyebilir.
        llm_btn = st.button(
            "AI Aksiyon Planını Oluştur / Yenile",
            key="llm_generate_btn",
            help="Yerel yapay zeka modelini kullanarak kurumsal Türkçe aksiyon planı üretir."
        )

        if llm_btn or (analyze_btn and "llm_explanation"not in st.session_state):
            # ── İyileştirme hedeflerini session_state üzerinden al ─────────
            dice_outputs = st.session_state.get("llm_dice_outputs", {
                "current"   : input_vals,
                "cf_list"   : [],
                "churn_prob": churn_prob,
            })
            dice_recipes = dice_outputs.get("cf_list", [])

            # ── Spinner ile Ollama API çağrısı ───────────────────────────────
            with st.spinner("Yerel yapay zeka aksiyon planı oluşturuyor..."):
                try:
                    explanation = generate_churn_explanation(
                        risk_score      = churn_prob,
                        abonelik_suresi = int(input_vals["Abonelik_Suresi_Ay"]),
                        aylik_giris     = int(input_vals["Aylik_Giris_Sayisi"]),
                        aktif_kullanici = int(input_vals["Aktif_Kullanici_Sayisi"]),
                        destek_bileti   = int(input_vals["Destek_Bileti_Sayisi"]),
                        dice_recipes    = dice_recipes if dice_recipes else None,
                    )
                except Exception as _llm_err:
                    st.error(
                        "Ollama servisine bağlantı kurulamadı. "
                        "Lütfen arka planda Ollama'nın çalıştığından emin olun."
                    )
                    explanation = str(_llm_err)
            st.session_state["llm_explanation"] = explanation

        # ── LLM Çıktısını Render Et ──────────────────────────────────────────
        if "llm_explanation"in st.session_state:
            explanation = st.session_state["llm_explanation"]

            # ── Dış kart başlığı ───────────────────────────────────────────────
            st.markdown(
                DIV(
                    "display:flex;align-items:center;gap:.7rem;margin-bottom:1rem;"
                    "padding:.75rem 1rem;background:#e8f0fe;"
                    "border:1px solid #c2d4f0;border-radius:10px;",
                        DIV(
                        "",
                        H("p",
                          "color:#1e3a6e;font-size:.72rem;font-weight:700;"
                          "letter-spacing:1.2px;text-transform:uppercase;margin:0;",
                          "ChurnLens AI"),
                        H("p",
                          "color:#4a6090;font-size:.68rem;margin:.1rem 0 0;",
                          "Kurumsal Müşteri Başarı Aksiyon Raporu — Otomatik Üretim"),
                    ),
                ),
                unsafe_allow_html=True)

            # ── LLM metnini okunabilir beyaz/açık kart içinde render et ─────
            import html as _html
            safe_text = _html.escape(explanation)
            # Markdown başlıklarını HTML'e çevir
            import re as _re
            # ### Başlık 3
            safe_text = _re.sub(
                r'^### (.+)$',
                r'<h4 style="color:#1e293b;font-size:.98rem;font-weight:700;margin:1.1rem 0 .4rem;">\1</h4>',
                safe_text, flags=_re.MULTILINE
            )
            # ## Başlık 2
            safe_text = _re.sub(
                r'^## (.+)$',
                r'<h3 style="color:#0f172a;font-size:1.05rem;font-weight:800;margin:1.3rem 0 .5rem;">\1</h3>',
                safe_text, flags=_re.MULTILINE
            )
            # **Kalın**
            safe_text = _re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', safe_text)
            # Satır sonu
            safe_text = safe_text.replace('\n', '<br>')

            st.markdown(
                f''
                f'<div style="'
                f'background:#f8f9fa;'
                f'border:1px solid #dee2e6;'
                f'border-left:4px solid #0066cc;'
                f'border-radius:10px;'
                f'padding:20px 24px;'
                f'margin-top:.4rem;'
                f'font-family:Inter,sans-serif;'
                f'font-size:.88rem;'
                f'line-height:1.75;'
                f'color:#1e293b;'
                f'">'
                f'{safe_text}'
                f'</div>',
                unsafe_allow_html=True
            )

            # ── İndir Butonu ─────────────────────────────────────────────────
            st.download_button(
                label="Aksiyon Planını İndir (.md)",
                data=explanation.encode("utf-8"),
                file_name=f"churnlens_aksiyon_plani_{risk_level}.md",
                mime="text/markdown",
                key="llm_download_btn",
            )

        else:
            # Henüz plan üretilmedi — açıklayıcı placeholder
            st.markdown(
                DIV(
                    "background:rgba(0,170,255,0.04);border:1px dashed rgba(0,170,255,0.2);"
                    "border-radius:12px;padding:2.5rem;text-align:center;margin-top:.5rem;",
                    H("p",
                      "color:#3a5070;font-size:.9rem;font-weight:600;margin:0 0 .4rem;",
                      "AI Aksiyon Planı henüz oluşturulmadı"),
                    H("p",
                      "color:#2a3a50;font-size:.78rem;margin:0;",
                      "Yukarıdaki <strong style='color:#1e4060;'>\"AI Aksiyon Planını Oluştur\"</strong> "
                      "butonuna tıklayın."),
                ),
                unsafe_allow_html=True)

    st.markdown("<hr style='border:none;border-top:1px solid #1e2a40;margin:1.5rem 0;'>",
                unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown(DIV("color:#1e3050;font-size:.7rem;",
                        "<strong style='color:#2a4060;'>ChurnLens v2.0</strong> · B2B SaaS"),
                    unsafe_allow_html=True)
    with c2:
        st.markdown(DIV("color:#1e3050;font-size:.7rem;text-align:center;",
                        "XGBoost · Açıklanabilir analiz · Streamlit"),
                    unsafe_allow_html=True)
    with c3:
        st.markdown(DIV("color:#1e3050;font-size:.7rem;text-align:right;",
                        f"Model: <strong style='color:#2a4060;'>{os.path.basename(MODEL_PATH)}</strong>"),
                    unsafe_allow_html=True)


if __name__ == "__main__":
    main()
