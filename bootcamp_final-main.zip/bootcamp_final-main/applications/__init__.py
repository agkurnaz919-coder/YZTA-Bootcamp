"""Namespaced feature applications for the Financial Copilot platform."""
