#!/bin/sh
set -eu

PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
VENV_DIR="$PROJECT_DIR/.venv"
PYTHON="$VENV_DIR/bin/python"

if [ ! -x "$PYTHON" ]; then
    if command -v python3.13 >/dev/null 2>&1; then
        BOOTSTRAP_PYTHON=python3.13
    elif command -v python3 >/dev/null 2>&1; then
        BOOTSTRAP_PYTHON=python3
    else
        echo "Python 3.11 veya daha yeni bir sürüm bulunamadı." >&2
        exit 1
    fi
    "$BOOTSTRAP_PYTHON" -m venv "$VENV_DIR"
fi

if ! "$PYTHON" -c 'import importlib.util, sys; required=("streamlit","pandas","sklearn","xgboost","shap","plotly","openpyxl"); sys.exit(0 if all(importlib.util.find_spec(name) for name in required) else 1)'; then
    echo "Proje bağımlılıkları kuruluyor..."
    "$PYTHON" -m pip install -r "$PROJECT_DIR/requirements.txt"
fi

cd "$PROJECT_DIR"
exec "$PYTHON" -m streamlit run app.py "$@"
