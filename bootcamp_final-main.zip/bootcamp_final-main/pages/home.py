"""Landing page for the unified bootcamp application."""

import streamlit as st

from applications.ui_theme import apply_theme


apply_theme()

st.markdown(
    """
    <section class="ri-home-hero" aria-labelledby="home-hero-title">
      <div class="ri-home-hero__content">
        <div class="ri-home-hero__eyebrow">
          <span aria-hidden="true"></span>
          Financial Copilot · Açıklanabilir risk operasyon platformu
        </div>
        <h1 id="home-hero-title">
          Üç ayrı risk akışı.<br>
          <span>Tek, açıklanabilir</span> karar alanı.
        </h1>
        <p>Finansal işlem anomalilerini, KOBİ kredi riskini ve B2B SaaS
        müşteri kaybını aynı çalışma alanında analiz edin. Skorun yanında
        nedenleri, olası iyileştirmeleri ve işe hazır çıktıları da görün.</p>
        <div class="ri-home-hero__actions">
          <a class="ri-home-button ri-home-button--primary"
             href="#solutions-title">Çözümleri keşfet <span>↓</span></a>
          <a class="ri-home-button ri-home-button--secondary"
             href="#workflow-title">İş akışını gör</a>
        </div>
        <div class="ri-home-hero__proof" aria-label="Platform özellikleri">
          <span>Açıklanabilir modeller</span>
          <span>Yerel analiz</span>
          <span>Uygulanabilir öneriler</span>
        </div>
      </div>
      <div class="ri-risk-console" aria-label="Üç risk çözümünün özeti">
        <div class="ri-risk-console__header">
          <div>
            <span class="ri-risk-console__kicker">Risk çalışma alanı</span>
            <strong>Karar sinyalleri</strong>
          </div>
          <span class="ri-risk-console__status">
            <i aria-hidden="true"></i> 3 çözüm hazır
          </span>
        </div>
        <div class="ri-risk-console__body">
          <div class="ri-console-row">
            <span class="ri-console-row__index">01</span>
            <div>
              <strong>FinAnomaly</strong>
              <span>Şüpheli giderleri denetim sırasına alır</span>
            </div>
            <span class="ri-console-row__tag">Denetim</span>
          </div>
          <div class="ri-console-row">
            <span class="ri-console-row__index">02</span>
            <div>
              <strong>Kredibilite XAI</strong>
              <span>Kredi kararının nedenlerini görünür kılar</span>
            </div>
            <span class="ri-console-row__tag">XAI</span>
          </div>
          <div class="ri-console-row">
            <span class="ri-console-row__index">03</span>
            <div>
              <strong>ChurnLens</strong>
              <span>Kurtarılabilir müşterileri önceliklendirir</span>
            </div>
            <span class="ri-console-row__tag">Retention</span>
          </div>
        </div>
        <div class="ri-risk-console__footer">
          <span>Skor</span><i aria-hidden="true">→</i>
          <span>Neden</span><i aria-hidden="true">→</i>
          <span>Öneri</span><i aria-hidden="true">→</i>
          <span>Rapor</span>
        </div>
      </div>
    </section>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <section class="ri-home-section" aria-labelledby="solutions-title">
      <div class="ri-home-section__heading">
        <div>
          <div class="ri-home-section__eyebrow">Çözümünüzü seçin</div>
          <h2 id="solutions-title">Bugün hangi riski yönetmek istiyorsunuz?</h2>
        </div>
        <p>İhtiyacınıza uygun çalışma alanını açın, hazır demo verisiyle
        başlayın veya kendi verinizi analiz edin.</p>
      </div>
      <div class="ri-solution-grid">
        <a class="ri-solution-card" href="./finanomaly"
           aria-label="FinAnomaly çözümünü aç">
          <span class="ri-label">Gider Denetimi</span>
          <h3>FinAnomaly</h3>
          <strong class="ri-solution-card__promise">
            Şüpheli harcamaları denetim kuyruğuna dönüştürün.
          </strong>
          <p>CSV/XLSX gider verilerini hibrit anomali modeli ve finans
          kurallarıyla tarayın; her işlemin neden öne çıktığını görün.</p>
          <span class="ri-solution-card__outputs">
            Risk kuyruğu · Denetçi açıklaması · Raporlama
          </span>
          <span class="ri-solution-card__cta">
            FinAnomaly'yi aç <span aria-hidden="true">→</span>
          </span>
        </a>
        <a class="ri-solution-card" href="./kredibilite-xai"
           aria-label="Kredibilite XAI çözümünü aç">
          <span class="ri-label">Kredi Riski</span>
          <h3>Kredibilite XAI</h3>
          <strong class="ri-solution-card__promise">
            Kredi kararlarını açıklanabilir hale getirin.
          </strong>
          <p>KOBİ kredi riskini XGBoost ile skorlayın, SHAP ile kararın
          nedenini açıklayın ve iyileştirme senaryolarını değerlendirin.</p>
          <span class="ri-solution-card__outputs">
            Risk skoru · Karar nedeni · Aksiyon senaryosu
          </span>
          <span class="ri-solution-card__cta">
            Kredibilite XAI'ı aç <span aria-hidden="true">→</span>
          </span>
        </a>
        <a class="ri-solution-card" href="./churnlens"
           aria-label="ChurnLens çözümünü aç">
          <span class="ri-label">Müşteri Kaybı</span>
          <h3>ChurnLens</h3>
          <strong class="ri-solution-card__promise">
            Riskli müşterileri kaybetmeden önce görün.
          </strong>
          <p>B2B SaaS müşterilerinin churn olasılığını tahmin edin; nedenleri
          ve uygulanabilir kurtarma hedeflerini tek yerde inceleyin.</p>
          <span class="ri-solution-card__outputs">
            Churn olasılığı · Neden kartları · Kurtarma planı
          </span>
          <span class="ri-solution-card__cta">
            ChurnLens'i aç <span aria-hidden="true">→</span>
          </span>
        </a>
      </div>
    </section>
    <section class="ri-home-section ri-home-section--platform"
             aria-labelledby="platform-title">
      <div class="ri-home-section__heading ri-home-section__heading--centered">
        <div>
          <div class="ri-home-section__eyebrow">Ortak karar katmanı</div>
          <h2 id="platform-title">Bağımsız motorlar, ortak bir iş akışı</h2>
        </div>
        <p>Her çözüm kendi modelini ve veri sınırını korur; sonuçlar aynı sade
        karar dilinde sunulur.</p>
      </div>
      <div class="ri-platform-flow">
        <article class="ri-platform-stage">
          <span class="ri-platform-stage__number">01 · Girdi</span>
          <strong>İş verisi</strong>
          <p>CSV, XLSX, demo veri veya manuel profil</p>
        </article>
        <article class="ri-platform-stage ri-platform-stage--engines">
          <span class="ri-platform-stage__number">02 · Risk motorları</span>
          <strong>Doğru çözüm devrede</strong>
          <div class="ri-platform-stage__chips">
            <span>FinAnomaly</span><span>Kredibilite</span><span>ChurnLens</span>
          </div>
        </article>
        <article class="ri-platform-stage">
          <span class="ri-platform-stage__number">03 · Açıklama</span>
          <strong>Kararın arkasındaki neden</strong>
          <p>Finans kuralları, SHAP ve karşı-olgusal analiz</p>
        </article>
        <article class="ri-platform-stage">
          <span class="ri-platform-stage__number">04 · Çıktı</span>
          <strong>Aksiyona hazır sonuç</strong>
          <p>Öncelik, öneri, denetim izi ve rapor</p>
        </article>
      </div>
    </section>
    <section class="ri-home-section ri-home-section--workflow"
             aria-labelledby="workflow-title">
      <div class="ri-home-section__heading">
        <div>
          <div class="ri-home-section__eyebrow">Basit iş akışı</div>
          <h2 id="workflow-title">Veriden aksiyona, üç adımda</h2>
        </div>
        <p>Her çözüm aynı net akışı izler; model ayrıntıları karar sürecinin
        önüne geçmez.</p>
      </div>
      <div class="ri-workflow-grid">
        <article class="ri-workflow-step">
          <span class="ri-workflow-step__number">01</span>
          <h3>Veriyi ekleyin</h3>
          <p>Hazır demo verisini kullanın, dosya yükleyin veya profil
          bilgilerini girin.</p>
        </article>
        <article class="ri-workflow-step">
          <span class="ri-workflow-step__number">02</span>
          <h3>Riski anlayın</h3>
          <p>Skorun yanında kararı etkileyen sinyalleri ve açıklamaları
          birlikte inceleyin.</p>
        </article>
        <article class="ri-workflow-step">
          <span class="ri-workflow-step__number">03</span>
          <h3>Aksiyona geçin</h3>
          <p>Önerilen senaryoları değerlendirin, önceliklendirin ve sonuçları
          raporlayın.</p>
        </article>
      </div>
    </section>
    <section class="ri-home-section ri-home-section--roles"
             aria-labelledby="roles-title">
      <div class="ri-home-section__heading">
        <div>
          <div class="ri-home-section__eyebrow">Ekip bazlı değer</div>
          <h2 id="roles-title">Her ekip kendi sorusunun yanıtını görür</h2>
        </div>
        <p>Aynı platform; denetim, risk ve müşteri başarı ekiplerine farklı
        karar çıktıları sunar.</p>
      </div>
      <div class="ri-role-grid">
        <article class="ri-role-card">
          <span class="ri-role-card__icon" aria-hidden="true">01</span>
          <div>
            <span class="ri-role-card__label">Finans &amp; Denetim</span>
            <h3>Önce hangi işlemi incelemeliyim?</h3>
            <p>Risk kuyruğu, işlem gerekçeleri ve denetlenebilir raporlarla
            inceleme süresini doğru sinyallere ayırın.</p>
          </div>
        </article>
        <article class="ri-role-card">
          <span class="ri-role-card__icon" aria-hidden="true">02</span>
          <div>
            <span class="ri-role-card__label">Kredi &amp; Risk</span>
            <h3>Bu karar neden çıktı, ne değişebilir?</h3>
            <p>Risk skorunu etkileyen faktörleri ve sonucu iyileştirebilecek
            gerçekçi senaryoları birlikte değerlendirin.</p>
          </div>
        </article>
        <article class="ri-role-card">
          <span class="ri-role-card__icon" aria-hidden="true">03</span>
          <div>
            <span class="ri-role-card__label">Müşteri Başarısı</span>
            <h3>Kime, hangi aksiyonla ulaşmalıyım?</h3>
            <p>Riskli müşterileri sıralayın, temel nedenleri görün ve hedefli
            kurtarma planları oluşturun.</p>
          </div>
        </article>
      </div>
    </section>
    <section class="ri-trust-strip" aria-label="Platform avantajları">
      <div class="ri-trust-item">
        <span class="ri-trust-item__mark" aria-hidden="true"></span>
        <div>
          <strong>Yerel analiz</strong>
          <span>Temel risk motorları harici LLM servisine ihtiyaç duymaz.</span>
        </div>
      </div>
      <div class="ri-trust-item">
        <span class="ri-trust-item__mark" aria-hidden="true"></span>
        <div>
          <strong>Açıklanabilir sonuçlar</strong>
          <span>Skorun yanında kararın nedenlerini de görün.</span>
        </div>
      </div>
      <div class="ri-trust-item">
        <span class="ri-trust-item__mark" aria-hidden="true"></span>
        <div>
          <strong>İşe hazır çıktılar</strong>
          <span>Önerileri değerlendirin ve sonuçları dışa aktarın.</span>
        </div>
      </div>
    </section>
    <footer class="ri-home-footer">
      <strong>Financial Copilot</strong>
      <span>Risk sinyallerinden açıklanabilir kararlara.</span>
    </footer>
    """,
    unsafe_allow_html=True,
)

st.info(
    "Yukarıdaki kartlardan veya sol menüden bir çözüm seçin. İlk açılışta model hazırlığı birkaç saniye sürebilir.",
    icon="ℹ️",
)
