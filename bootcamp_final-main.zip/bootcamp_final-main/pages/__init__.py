"""Shared pages for the unified Streamlit application."""
